import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import { Mail, Check, Loader2 } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { t } = useTranslation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate submission
    setTimeout(() => {
      toast({
        title: "Success!",
        description: "You've been subscribed to our newsletter.",
      });
      setEmail("");
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <section className="py-16 relative overflow-hidden bg-gray-50">
      {/* Decorative elements - Italian flag-inspired */}
      <div className="absolute left-0 top-0 h-full w-2 bg-[#009246]"></div>
      <div className="absolute right-0 top-0 h-full w-2 bg-[#CE2B37]"></div>
      <div className="absolute inset-0 bg-opacity-5 bg-[url('/patterns/italy-pattern.svg')] opacity-10"></div>
      
      <div className="container mx-auto px-4 max-w-4xl relative z-10">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">
            {t('newsletter.title', 'Stay Updated')}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t('newsletter.description', 'Subscribe to our newsletter for the latest travel tips, destination guides, and exclusive offers')}
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-md border border-gray-100 max-w-xl mx-auto">
          <form className="flex flex-col md:flex-row gap-4" onSubmit={handleSubmit}>
            <div className="relative flex-1">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="email"
                placeholder={t('newsletter.emailPlaceholder', 'Your email address')}
                className="pl-10 py-6 flex-1 rounded-md border-gray-200 text-gray-800 focus-visible:ring-2 focus-visible:ring-[#009246] focus-visible:border-transparent"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <Button 
              type="submit"
              className="bg-[#CE2B37] hover:bg-[#B32733] text-white font-medium py-6 px-6 rounded-md transition-colors duration-300"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('newsletter.subscribing', 'Subscribing...')}</>
              ) : (
                t('newsletter.subscribeButton', 'Subscribe')
              )}
            </Button>
          </form>
          
          <div className="mt-4 flex items-center justify-center text-sm text-gray-500">
            <div className="flex items-center justify-center bg-green-50 p-1 rounded-full mr-2">
              <Check className="h-3 w-3 text-green-600" />
            </div>
            <span>{t('newsletter.privacyNote', 'We respect your privacy and will never share your information')}</span>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-8">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-[#009246] flex items-center justify-center text-white mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5z"></path><path d="m10 9 5 3-5 3z"></path></svg>
            </div>
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">Monthly Newsletter</p>
              <p className="text-xs text-gray-500">Exclusive travel guides</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-[#CE2B37] flex items-center justify-center text-white mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </div>
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">Destination Alerts</p>
              <p className="text-xs text-gray-500">Region-specific updates</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-[#f1f5f9] border border-gray-200 flex items-center justify-center text-[#1A3A5A] mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
            </div>
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">Community News</p>
              <p className="text-xs text-gray-500">Traveler stories & tips</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
