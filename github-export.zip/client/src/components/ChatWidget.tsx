import { useState, useEffect, useRef } from "react";
import { MessageCircle, X, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function ChatWidget() {
  const [isVisible, setIsVisible] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<{ text: string; isUser: boolean; time: string }[]>([
    {
      text: "Hi there! How can I help you with your Italian travel plans today?",
      isUser: false,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const userMessageTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Add user message
    setMessages([...messages, { text: message, isUser: true, time: userMessageTime }]);
    setMessage("");
    
    // Simulate typing indicator
    setIsTyping(true);
    
    // Simulate response after a delay
    setTimeout(() => {
      const responseTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      const responses = [
        "Thanks for your message! I'll get back to you as soon as possible.",
        "That's a great question about Italy. Let me find the best information for you.",
        "I'd be happy to help you plan your Italian adventure!",
        "The best time to visit that region is typically during spring or fall when there are fewer tourists.",
        "That's one of my favorite places in Italy! Let me share some local tips."
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      setMessages(prevMessages => [
        ...prevMessages, 
        { text: randomResponse, isUser: false, time: responseTime }
      ]);
      
      setIsTyping(false);
    }, 1500);
  };

  return (
    <>
      {/* Chat Button */}
      <div
        className={`fixed bottom-6 right-6 z-50 transition-opacity duration-300 ${
          isVisible && !isChatOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      >
        <button
          onClick={toggleChat}
          className="bg-[#CE2B37] hover:bg-[#CE2B37]/90 text-white flex items-center justify-center w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative"
          aria-label="Open Chat"
        >
          <MessageCircle className="w-6 h-6" />
          <div className="animate-ping absolute inset-0 rounded-full bg-[#CE2B37] opacity-25"></div>
        </button>
      </div>

      {/* Chat Window */}
      <div
        className={`fixed bottom-6 right-6 w-[350px] md:w-[380px] bg-white rounded-lg shadow-xl z-50 transition-all duration-500 ${
          isChatOpen
            ? "opacity-100 transform translate-y-0"
            : "opacity-0 transform translate-y-10 pointer-events-none"
        }`}
      >
        {/* Chat Header */}
        <div className="flex items-center justify-between bg-[#CE2B37] text-white p-4 rounded-t-lg">
          <div className="flex items-center">
            <div className="flex items-center justify-center bg-white p-1.5 rounded-full mr-3">
              <span className="font-['Cinzel'] text-xs font-bold tracking-tight text-[#CE2B37]">OIJ</span>
            </div>
            <div>
              <p className="font-semibold">Our Italian Journey</p>
              <p className="text-xs opacity-80">Usually replies within an hour</p>
            </div>
          </div>
          <button
            onClick={toggleChat}
            className="p-1 rounded-full hover:bg-[#CE2B37]/80 transition"
            aria-label="Close Chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="p-4 h-80 overflow-y-auto bg-gray-50">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`mb-4 flex ${msg.isUser ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-3 ${
                  msg.isUser
                    ? "bg-[#CE2B37] text-white rounded-br-none"
                    : "bg-white border border-gray-200 rounded-bl-none"
                }`}
              >
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.isUser ? "text-white/70" : "text-gray-500"}`}>
                  {msg.time}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start mb-4">
              <div className="bg-white border border-gray-200 rounded-lg rounded-bl-none p-3 max-w-[85%]">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-75"></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce delay-150"></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
          <div className="flex">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="min-h-[60px] max-h-36 flex-grow resize-none focus-visible:ring-[#CE2B37]"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <Button 
              type="submit" 
              disabled={!message.trim()}
              className="ml-2 bg-[#CE2B37] hover:bg-[#CE2B37]/90 rounded-full h-[60px] w-[60px] p-3"
              aria-label="Send Message"
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-2 text-center">
            Messages will be sent to our team and typically responded to within 24 hours.
          </p>
        </form>
      </div>
    </>
  );
}