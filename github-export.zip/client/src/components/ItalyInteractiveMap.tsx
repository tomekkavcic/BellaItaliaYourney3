import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { italyRegions, Region, getRegionById } from '@/data/italyRegions';
import { MapPin, Info, ZoomIn, ZoomOut } from 'lucide-react';

// Define place data structure
export interface Place {
  id: number;
  name: string;
  region: string;
  macroRegion: string; 
  x: number;
  y: number;
  slug: string;
}

interface ItalyMapProps {
  places?: Place[];
  activeRegion?: string;
  activeMacroRegion?: string;
  onRegionClick?: (regionId: string) => void;
  onPlaceClick?: (placeId: number) => void;
  showLabels?: boolean;
  showPlaces?: boolean;
  showMacroRegionsOnly?: boolean;
  width?: string | number;
  height?: string | number;
  interactive?: boolean;
}

// Region colors based on the Italian flag and designed for better contrast
const getRegionColor = (
  region: Region, 
  activeRegion: string, 
  hoveredRegion: string | null, 
  mode: 'fill' | 'stroke',
  showMacroRegionsOnly: boolean
) => {
  if (mode === 'fill') {
    // Region is active
    if (activeRegion === region.id) {
      return '#CE2B37'; // Italian flag red
    }
    
    // Region is hovered
    if (hoveredRegion === region.id) {
      return region.macro === 'north' 
        ? '#4DB16A' // Lighter green
        : region.macro === 'central' 
          ? '#E6E6E6' // Lighter white
          : '#E76F76'; // Lighter red
    }
    
    // Default color - base colors by macro region
    switch(region.macro) {
      case 'north':
        return showMacroRegionsOnly 
          ? '#009246' // Italian flag green, full opacity for macro
          : '#00924660'; // Italian flag green with transparency for detailed
      case 'central':
        return showMacroRegionsOnly 
          ? '#F8F9FA' // White, full opacity for macro
          : '#F8F9FA60'; // White with transparency for detailed
      case 'south':
        return showMacroRegionsOnly 
          ? '#CE2B37' // Italian flag red, full opacity for macro
          : '#CE2B3760'; // Italian flag red with transparency for detailed
      default:
        return '#F8F9FA60';
    }
  } else {
    // Stroke color
    if (activeRegion === region.id) {
      return '#111111'; // Darker for active
    }
    
    if (hoveredRegion === region.id) {
      return '#333333'; // Dark for hover
    }
    
    // Default color based on macro region
    switch(region.macro) {
      case 'north':
        return '#006328'; // Darker green border
      case 'central':
        return '#888888'; // Gray border
      case 'south':
        return '#A11E27'; // Darker red border
      default:
        return '#888888';
    }
  }
};

const ItalyInteractiveMap: React.FC<ItalyMapProps> = ({
  places = [],
  activeRegion = '',
  activeMacroRegion = '',
  onRegionClick = () => {},
  onPlaceClick = () => {},
  showLabels = true,
  showPlaces = true,
  showMacroRegionsOnly = false,
  width = '100%',
  height = 'auto',
  interactive = true
}) => {
  const { t, i18n } = useTranslation();
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [hoveredPlace, setHoveredPlace] = useState<number | null>(null);
  const [visibleRegions, setVisibleRegions] = useState<Region[]>(italyRegions);
  const [tooltipInfo, setTooltipInfo] = useState<{
    visible: boolean;
    text: string;
    x: number;
    y: number;
    type: 'region' | 'place';
    id: string | number;
  }>({
    visible: false,
    text: '',
    x: 0,
    y: 0,
    type: 'region',
    id: ''
  });
  
  // Zoom and Pan functionality
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);
  
  // Active region data
  const [activeRegionData, setActiveRegionData] = useState<Region | null>(null);
  
  // Update active region data
  useEffect(() => {
    if (activeRegion) {
      const region = getRegionById(activeRegion);
      setActiveRegionData(region || null);
    } else {
      setActiveRegionData(null);
    }
  }, [activeRegion]);
  
  // Reset zoom and pan when active region changes
  useEffect(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [activeRegion, showMacroRegionsOnly]);
  
  // Filter regions if showMacroRegionsOnly is true
  useEffect(() => {
    if (showMacroRegionsOnly) {
      // Group regions by macro and use one representative for each
      const north = italyRegions.find(r => r.id === 'lombardia') || italyRegions[0];
      const central = italyRegions.find(r => r.id === 'toscana') || italyRegions[8];
      const south = italyRegions.find(r => r.id === 'puglia') || italyRegions[14];
      
      setVisibleRegions([{
        ...north,
        id: 'north',
        name: t('regions.north'),
        nameEn: 'Northern Italy',
        nameSl: 'Severna Italija',
        path: "M40,70 L80,50 L150,40 L190,50 L215,90 L195,140 L150,160 L100,150 L60,120 Z",
        center: [120, 100]
      }, {
        ...central,
        id: 'central',
        name: t('regions.central'),
        nameEn: 'Central Italy',
        nameSl: 'Osrednja Italija',
        path: "M80,140 L120,160 L170,155 L210,170 L225,200 L200,230 L140,250 L90,230 L70,190 Z",
        center: [160, 200]
      }, {
        ...south,
        id: 'south',
        name: t('regions.south'),
        nameEn: 'Southern Italy',
        nameSl: 'Južna Italija',
        path: "M90,230 L140,250 L200,230 L240,250 L260,310 L210,350 L160,370 L120,330 L90,280 Z",
        center: [180, 300],
      }]);
    } else {
      setVisibleRegions(italyRegions);
    }
  }, [showMacroRegionsOnly, t]);
  
  // Filter places by active region if needed
  const filteredPlaces = activeRegion 
    ? places.filter(place => place.region === activeRegion)
    : activeMacroRegion
      ? places.filter(place => place.macroRegion === activeMacroRegion)
      : places;
  
  // Handle region mouse interactions
  const handleRegionMouseEnter = (region: Region) => {
    if (!interactive) return;
    
    setHoveredRegion(region.id);
    
    const regionName = i18n.language === 'sl' ? region.nameSl : region.nameEn;
    setTooltipInfo({
      visible: true,
      text: regionName,
      x: region.center[0],
      y: region.center[1] - 15,
      type: 'region',
      id: region.id
    });
  };
  
  const handleRegionMouseLeave = () => {
    if (!interactive) return;
    setHoveredRegion(null);
    setTooltipInfo({...tooltipInfo, visible: false});
  };
  
  // Handle place mouse interactions
  const handlePlaceMouseEnter = (place: Place) => {
    if (!interactive) return;
    
    setHoveredPlace(place.id);
    setTooltipInfo({
      visible: true,
      text: place.name,
      x: place.x,
      y: place.y - 12,
      type: 'place',
      id: place.id
    });
  };
  
  const handlePlaceMouseLeave = () => {
    if (!interactive) return;
    setHoveredPlace(null);
    setTooltipInfo({...tooltipInfo, visible: false});
  };
  
  // Zoom in and out handlers
  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.2, 2.5));
  };
  
  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.2, 0.8));
  };
  
  // Drag handlers for panning
  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!interactive || zoom <= 1) return;
    
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };
  
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!interactive || !isDragging) return;
    
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;
    
    setPan(prev => ({ 
      x: prev.x + dx / zoom, 
      y: prev.y + dy / zoom 
    }));
    
    setDragStart({ x: e.clientX, y: e.clientY });
  };
  
  const handleMouseUp = () => {
    if (!interactive) return;
    setIsDragging(false);
  };
  
  // Reset zoom and pan
  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };
  
  // Transform string for zooming and panning
  const transformString = `translate(${pan.x}, ${pan.y}) scale(${zoom})`;
  
  return (
    <div className="italy-map-container relative w-full overflow-hidden rounded-xl border border-gray-200 bg-[#E6F2FF]">
      <svg
        ref={svgRef}
        viewBox="0 0 300 400"
        style={{ width, height }}
        className="w-full h-auto"
        xmlns="http://www.w3.org/2000/svg"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Grid pattern for sea */}
        <defs>
          <pattern id="water" patternUnits="userSpaceOnUse" width="15" height="15">
            <rect width="15" height="15" fill="#E6F2FF" />
            <path d="M0 15 Q 7.5 7.5, 15 15" stroke="#4885ed20" strokeWidth="1.5" fill="none" />
          </pattern>
          
          {/* Soft shadow for regions */}
          <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="1" dy="1" stdDeviation="1" floodOpacity="0.3" />
          </filter>
        </defs>
        
        {/* Sea background */}
        <rect width="100%" height="100%" fill="url(#water)" />
        
        {/* Map container with transform for zoom and pan */}
        <g transform={transformString}>
          {/* Map regions */}
          {visibleRegions.map((region) => (
            <g key={region.id}>
              {/* Add subtle glow effect for active/hovered regions */}
              {(activeRegion === region.id || hoveredRegion === region.id) && (
                <path
                  d={region.path}
                  fill={getRegionColor(region, activeRegion, hoveredRegion, 'fill', showMacroRegionsOnly)}
                  filter="url(#shadow)"
                  opacity="0.6"
                />
              )}
              <path
                d={region.path}
                fill={getRegionColor(region, activeRegion, hoveredRegion, 'fill', showMacroRegionsOnly)}
                stroke={getRegionColor(region, activeRegion, hoveredRegion, 'stroke', showMacroRegionsOnly)}
                strokeWidth={activeRegion === region.id || hoveredRegion === region.id ? "1.5" : "1"}
                className={`transition-all duration-300 ${interactive ? 'cursor-pointer' : ''}`}
                opacity={
                  activeRegion && activeRegion !== region.id && hoveredRegion !== region.id
                    ? 0.7
                    : 1
                }
                onClick={() => interactive && onRegionClick(region.id)}
                onMouseEnter={() => handleRegionMouseEnter(region)}
                onMouseLeave={handleRegionMouseLeave}
              />
            </g>
          ))}
  
          {/* Region labels */}
          {showLabels && visibleRegions.map((region) => (
            <text
              key={`label-${region.id}`}
              x={region.center[0]}
              y={region.center[1]}
              textAnchor="middle"
              fill={
                activeRegion === region.id 
                  ? "#ffffff" 
                  : region.macro === 'central' 
                    ? "#333333" 
                    : "#ffffff"
              }
              fontSize={zoom < 1 ? "8" : "10"}
              fontWeight={activeRegion === region.id || hoveredRegion === region.id ? "bold" : "normal"}
              pointerEvents="none"
              opacity={activeRegion && activeRegion !== region.id ? 0.8 : 1}
              style={{ 
                textShadow: region.macro === 'central' 
                  ? '0 0 2px white, 0 0 2px white, 0 0 2px white, 0 0 2px white' 
                  : '0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black'
              }}
            >
              {i18n.language === 'sl' ? region.nameSl : region.nameEn}
            </text>
          ))}
  
          {/* Place markers */}
          {showPlaces && filteredPlaces.map((place) => (
            <g key={`place-${place.id}`} className="place-marker">
              {/* Drop shadow for markers */}
              <circle
                cx={place.x}
                cy={place.y}
                r={hoveredPlace === place.id ? 6 : 4}
                fill="#00000040"
                transform="translate(1,1)"
              />
              
              {/* Main marker circle */}
              <circle
                cx={place.x}
                cy={place.y}
                r={hoveredPlace === place.id ? 6 : 4}
                fill={hoveredPlace === place.id ? '#1A3A5A' : '#1A3A5A80'}
                stroke="#ffffff"
                strokeWidth="1.5"
                className={`transition-all duration-300 ${interactive ? 'cursor-pointer' : ''}`}
                onClick={() => interactive && onPlaceClick(place.id)}
                onMouseEnter={() => handlePlaceMouseEnter(place)}
                onMouseLeave={handlePlaceMouseLeave}
              />
              
              {/* Pin animation when hovered */}
              {hoveredPlace === place.id && (
                <>
                  <circle
                    cx={place.x}
                    cy={place.y}
                    r="10"
                    fill="#1A3A5A20"
                    className="animate-ping"
                  />
                  <circle
                    cx={place.x}
                    cy={place.y}
                    r="8"
                    fill="transparent"
                    stroke="#1A3A5A40"
                    strokeWidth="1"
                  />
                </>
              )}
            </g>
          ))}
  
          {/* Enhanced tooltip */}
          {tooltipInfo.visible && (
            <g className="region-tooltip">
              <rect
                x={tooltipInfo.x - 60}
                y={tooltipInfo.y - 22}
                width="120"
                height="22"
                rx="6"
                fill={tooltipInfo.type === 'region' ? '#1A3A5A' : '#CE2B37'}
                opacity="0.9"
                filter="url(#shadow)"
              />
              <text
                x={tooltipInfo.x}
                y={tooltipInfo.y - 7}
                textAnchor="middle"
                fill="#ffffff"
                fontSize="10"
                fontWeight="medium"
              >
                {tooltipInfo.text}
              </text>
            </g>
          )}
        </g>
      </svg>

      {/* Enhanced legend with active region info */}
      <div className="absolute bottom-3 left-3 bg-white/85 backdrop-blur-sm p-3 rounded-lg shadow-md text-xs max-w-[45%]">
        {activeRegionData ? (
          <div className="space-y-1.5">
            <h4 className="font-bold text-[#1A3A5A] text-sm">{i18n.language === 'sl' ? activeRegionData.nameSl : activeRegionData.nameEn}</h4>
            <div className="text-gray-700 space-y-0.5">
              <div className="flex items-center">
                <span className="font-medium mr-1">{t('map.capital')}:</span> {activeRegionData.capital}
              </div>
              <div className="flex items-center">
                <span className="font-medium mr-1">{t('map.area')}:</span> {activeRegionData.area.toLocaleString()} km²
              </div>
              <div className="flex items-center">
                <span className="font-medium mr-1">{t('map.population')}:</span> {activeRegionData.population.toLocaleString()}
              </div>
            </div>
            <p className="text-gray-600 text-[10px] mt-1">
              {i18n.language === 'sl' ? activeRegionData.descriptionSl : activeRegionData.descriptionEn}
            </p>
          </div>
        ) : (
          <div>
            <h4 className="font-bold text-[#1A3A5A] text-sm">{t('map.legendTitle', 'Italy Map')}</h4>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-[#009246] mr-1 rounded-sm"></div>
                <span>{t('regions.north')}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-[#F8F9FA] border border-gray-300 mr-1 rounded-sm"></div>
                <span>{t('regions.central')}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-[#CE2B37] mr-1 rounded-sm"></div>
                <span>{t('regions.south')}</span>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Zoom controls */}
      {interactive && zoom !== 1 && (
        <button 
          className="absolute top-3 right-3 bg-white/85 backdrop-blur-sm p-1.5 rounded-lg shadow-md text-[#1A3A5A] hover:bg-white"
          onClick={handleReset}
          title={t('map.resetZoom', 'Reset view')}
        >
          <Info size={16} />
        </button>
      )}
      
      {interactive && (
        <div className="absolute bottom-3 right-3 flex flex-col gap-1">
          <button 
            className="bg-white/85 backdrop-blur-sm p-1.5 rounded-lg shadow-md text-[#1A3A5A] hover:bg-white disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleZoomIn}
            disabled={zoom >= 2.5}
            title={t('map.zoomIn', 'Zoom in')}
          >
            <ZoomIn size={16} />
          </button>
          <button 
            className="bg-white/85 backdrop-blur-sm p-1.5 rounded-lg shadow-md text-[#1A3A5A] hover:bg-white disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleZoomOut}
            disabled={zoom <= 0.8}
            title={t('map.zoomOut', 'Zoom out')}
          >
            <ZoomOut size={16} />
          </button>
        </div>
      )}
    </div>
  );
};

export default ItalyInteractiveMap;