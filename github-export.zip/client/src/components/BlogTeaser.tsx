import { Link } from "wouter";
import { useTranslation } from "react-i18next";

export default function BlogTeaser() {
  const { t } = useTranslation();
  
  return (
    <section id="blog-section" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('blog.title', 'Travel Stories & Tips')}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">{t('blog.subtitle', 'Our latest adventures and insights from across beautiful Italy')}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <article className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative h-48">
              <img 
                src="https://images.unsplash.com/photo-1529154691717-3306083d869e?auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Italian coastal town" 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-0 right-0 bg-red-500 text-white px-3 py-1 m-2 text-sm font-medium rounded">
                {t('regions.south')}
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center text-sm text-gray-600 mb-3">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"></path>
                </svg>
                <span>June 12, 2023</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Hidden Gems Along the Amalfi Coast</h3>
              <p className="text-gray-600 mb-4">Beyond the popular spots, we discovered these local favorites that made our trip unforgettable.</p>
              <Link to="/blog/amalfi-coast">
                <button className="text-red-600 hover:text-red-700 font-medium flex items-center transition-colors">
                  {t('blog.readMore', 'Read Article')}
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                  </svg>
                </button>
              </Link>
            </div>
          </article>
          
          <article className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative h-48">
              <img 
                src="https://images.unsplash.com/photo-1498579485796-98be3abc076e?auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Italian food" 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-0 right-0 bg-green-600 text-white px-3 py-1 m-2 text-sm font-medium rounded">
                {t('regions.central')}
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center text-sm text-gray-600 mb-3">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"></path>
                </svg>
                <span>May 28, 2023</span>
              </div>
              <h3 className="text-xl font-bold mb-2">The Ultimate Guide to Authentic Italian Cuisine</h3>
              <p className="text-gray-600 mb-4">Regional specialties, cooking classes, and our favorite restaurants from north to south Italy.</p>
              <Link to="/blog/italian-cuisine">
                <button className="text-red-600 hover:text-red-700 font-medium flex items-center transition-colors">
                  {t('blog.readMore', 'Read Article')}
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                  </svg>
                </button>
              </Link>
            </div>
          </article>
          
          <article className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative h-48">
              <img 
                src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Train through Italy" 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-0 right-0 bg-white text-gray-800 px-3 py-1 m-2 text-sm font-medium rounded">
                {t('regions.north')}
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center text-sm text-gray-600 mb-3">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"></path>
                </svg>
                <span>April 15, 2023</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Navigating Italy by Train: A Complete Guide</h3>
              <p className="text-gray-600 mb-4">How we traveled through Italy efficiently using only trains and public transportation.</p>
              <Link to="/blog/italy-by-train">
                <button className="text-red-600 hover:text-red-700 font-medium flex items-center transition-colors">
                  {t('blog.readMore', 'Read Article')}
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                  </svg>
                </button>
              </Link>
            </div>
          </article>
        </div>
        
        <div className="text-center mt-12">
          <Link to="/blog">
            <button className="inline-block py-3 px-6 bg-gray-800 hover:bg-gray-900 text-white font-medium rounded-lg transition-colors">
              {t('blog.viewAll', 'View All Blog Posts')}
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
