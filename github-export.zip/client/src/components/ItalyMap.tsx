import React from "react";

interface Place {
  id: number;
  name: string;
  region: string;
  x: number;
  y: number;
}

interface ItalyMapProps {
  places: Place[];
  activeRegion: string;
  onRegionClick: (regionId: string) => void;
}

export default function ItalyMap({ activeRegion, onRegionClick }: ItalyMapProps) {
  // Create clickable overlays for each region
  const handleRegionClick = (region: string) => {
    onRegionClick(region);
  };
  
  return (
    <div className="flex justify-center overflow-hidden mb-6">
      <div className="relative w-full max-w-md mx-auto">
        {/* Map Image Container */}
        <div className="relative">
          {/* Italian flag map image */}
          <img 
            src="/assets/italy-flag-map.png" 
            alt="Italy map with flag colors" 
            className="w-full h-auto rounded-lg shadow-md" 
          />
          
          {/* Invisible clickable areas overlaid on regions */}
          {/* Northern Italy (Green) */}
          <div 
            className="absolute top-0 left-0 w-[50%] h-[25%] cursor-pointer opacity-0 hover:opacity-10 hover:bg-green-500" 
            onClick={() => handleRegionClick("north")}
            title="North Italy"
          />
          
          {/* Central Italy (White) */}
          <div 
            className="absolute top-[25%] left-[15%] w-[70%] h-[40%] cursor-pointer opacity-0 hover:opacity-10 hover:bg-gray-200" 
            onClick={() => handleRegionClick("central")}
            title="Central Italy"
          />
          
          {/* Southern Italy (Red) - Main peninsula */}
          <div 
            className="absolute top-[65%] right-[15%] w-[50%] h-[35%] cursor-pointer opacity-0 hover:opacity-10 hover:bg-red-500" 
            onClick={() => handleRegionClick("south")}
            title="South Italy: Mainland"
          />
          
          {/* Sicily (Red) */}
          <div 
            className="absolute bottom-[5%] left-[30%] w-[25%] h-[15%] cursor-pointer opacity-0 hover:opacity-10 hover:bg-red-500" 
            onClick={() => handleRegionClick("south")}
            title="South Italy: Sicily"
          />
          
          {/* Sardinia (White/Central on this map) */}
          <div 
            className="absolute top-[50%] left-0 w-[15%] h-[25%] cursor-pointer opacity-0 hover:opacity-10 hover:bg-gray-200" 
            onClick={() => handleRegionClick("central")}
            title="Central Italy: Sardinia"
          />
        </div>
      </div>
    </div>
  );
}