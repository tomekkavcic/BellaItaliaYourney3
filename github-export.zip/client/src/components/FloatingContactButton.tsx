import { useState, useEffect } from "react";
import { MessageCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function FloatingContactButton() {
  const [isVisible, setIsVisible] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const toggleVisibility = () => {
      // Show button when page is scrolled down past 300px
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const handleClick = () => {
    setLocation("/contact");
  };

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
    >
      <button
        onClick={handleClick}
        className="bg-[#CE2B37] hover:bg-[#CE2B37]/90 text-white flex items-center justify-center w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 relative"
        aria-label="Contact Us"
      >
        <MessageCircle className="w-6 h-6" />
        <div className="animate-ping absolute inset-0 rounded-full bg-[#CE2B37] opacity-25"></div>
      </button>
    </div>
  );
}