import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Popover } from '@/components/ui/popover';
import { PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';

const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();
  const [open, setOpen] = useState(false);
  
  const languages = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'sl', label: 'Slovenščina', flag: '🇸🇮' }
  ];
  
  const currentLanguage = languages.find(lang => lang.code === i18n.language) || languages[0];
  
  const handleLanguageChange = (langCode: string) => {
    i18n.changeLanguage(langCode);
    setOpen(false);
    
    // Save language preference to localStorage
    localStorage.setItem('i18nextLng', langCode);
  };
  
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="h-9 px-3 border-none hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <span className="mr-1">{currentLanguage.flag}</span>
          <span className="hidden md:inline">{currentLanguage.label}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-44 p-0" align="end">
        <div className="flex flex-col">
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleLanguageChange(language.code)}
              className={`flex items-center px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ${
                language.code === i18n.language ? 'bg-gray-100 dark:bg-gray-800 font-medium' : ''
              }`}
            >
              <span className="mr-2">{language.flag}</span>
              <span>{language.label}</span>
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default LanguageSwitcher;