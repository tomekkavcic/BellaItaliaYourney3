import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';

// Define the destination interface
interface Destination {
  id: number;
  title: string;
  slug: string;
  region: string;
  location: string;
  description: string;
  imageUrl: string;
  features: {
    localFood: boolean;
    localDrink: boolean;
    accommodation: boolean;
    mustSee: boolean;
    bestExperience: boolean;
  };
}

// Sample featured destinations
const featuredDestinations: Destination[] = [
  {
    id: 1,
    title: 'Venice',
    slug: 'venice',
    region: 'north',
    location: 'Veneto',
    description: 'The floating city with stunning canals and historic architecture.',
    imageUrl: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963',
    features: {
      localFood: true,
      localDrink: true,
      accommodation: true,
      mustSee: true,
      bestExperience: true
    }
  },
  {
    id: 2,
    title: 'Rome',
    slug: 'rome',
    region: 'central',
    location: 'Lazio',
    description: 'The Eternal City with ancient ruins, Vatican City, and vibrant street life.',
    imageUrl: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5',
    features: {
      localFood: true,
      localDrink: true,
      accommodation: true,
      mustSee: true,
      bestExperience: true
    }
  },
  {
    id: 3,
    title: 'Amalfi Coast',
    slug: 'amalfi-coast',
    region: 'south',
    location: 'Campania',
    description: 'Stunning coastal towns with dramatic cliffs and azure waters.',
    imageUrl: 'https://images.unsplash.com/photo-1533587851505-d119a4dd5fc9',
    features: {
      localFood: true,
      localDrink: true,
      accommodation: true,
      mustSee: true,
      bestExperience: true
    }
  }
];

const FeaturedDestinations: React.FC = () => {
  const { t } = useTranslation();
  
  return (
    <section className="featured-destinations py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{t('featured.title')}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{t('featured.subtitle')}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredDestinations.map((destination) => (
            <div key={destination.id} className="bg-white rounded-lg overflow-hidden shadow-md transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
              <div className="relative h-48 overflow-hidden">
                {/* Replace with next/image or proper image handling when available */}
                <img 
                  src={`${destination.imageUrl}?auto=format&fit=crop&w=600&h=400&q=80`}
                  alt={destination.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-0 right-0 bg-red-500 text-white px-3 py-1 m-2 text-sm font-medium rounded">
                  {t(`regions.${destination.region}`)}
                </div>
              </div>
              
              <div className="p-5">
                <h3 className="text-xl font-bold text-gray-800 mb-2">{destination.title}</h3>
                
                <div className="flex items-center text-gray-600 mb-3">
                  <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd"></path>
                  </svg>
                  <span className="text-sm">{destination.location}</span>
                </div>
                
                <p className="text-gray-600 mb-4">{destination.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex space-x-2">
                    {destination.features.localFood && (
                      <span className="w-6 h-6 flex items-center justify-center bg-green-100 text-green-800 rounded-full" title={t('features.localFood')}>
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path d="M3 3a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 13.846 4.632 15 6 15h10a1 1 0 000-2H6l.8-.8 1.4-5.6.464-1.864a1 1 0 00-.944-1.736H4.414a1 1 0 00-.894.553L2.342 7 2 3z"></path>
                          <path d="M15 8a1 1 0 10-2 0v4.697l-1.699 1.7a1 1 0 101.414 1.414l2-2a1 1 0 00.293-.707V8z"></path>
                        </svg>
                      </span>
                    )}
                    
                    {destination.features.localDrink && (
                      <span className="w-6 h-6 flex items-center justify-center bg-purple-100 text-purple-800 rounded-full" title={t('features.localDrink')}>
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path d="M10 2a1 1 0 00-1 1v1.323l3.954 3.954 2.046-.001-6-6zm9 13v-1a1 1 0 00-1-1h-6.586l-1-1h3.586a1 1 0 00.707-1.707l-1.121-1.121a1 1 0 00-.708-.293h-6.172a3 3 0 00-2.12.878L2.879 13.172a3 3 0 00-.879 2.12v1.708a1 1 0 001 1h3.718a3 3 0 002.12-.878l5.13-5.13 1.584 1.584a1 1 0 001.415 0l2.12-2.12a1 1 0 000-1.414L17.414 8.5a1 1 0 00-1.414 0L14.086 10.414 13.536 9.864l2.12-2.12-2.12-2.121L5.414 13.757a1.5 1.5 0 01-1.06.243h-2.5a1.5 1.5 0 00-1.5 1.5v1a1.5 1.5 0 001.5 1.5h16a1.5 1.5 0 001.5-1.5z"></path>
                        </svg>
                      </span>
                    )}
                    
                    {destination.features.accommodation && (
                      <span className="w-6 h-6 flex items-center justify-center bg-blue-100 text-blue-800 rounded-full" title={t('features.accommodation')}>
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z"></path>
                        </svg>
                      </span>
                    )}
                  </div>
                </div>
                
                <Link to={`/places/${destination.slug}`}>
                  <button className="block w-full text-center py-2 px-4 bg-red-600 hover:bg-red-700 text-white font-medium rounded transition-colors">
                    {t('featured.exploreButton')}
                  </button>
                </Link>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Link to="/places">
            <button className="inline-block py-3 px-6 bg-gray-800 hover:bg-gray-900 text-white font-medium rounded-lg transition-colors">
              {t('featured.viewAllButton')}
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedDestinations;