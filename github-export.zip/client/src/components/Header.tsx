import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'wouter';
import LanguageSwitcher from './LanguageSwitcher';
import { 
  Home, 
  MapPin, 
  Compass, 
  FileText, 
  Info, 
  Mail, 
  Menu, 
  X,
  ChevronDown,
  Search,
  Phone,
  Instagram,
  Heart,
  User
} from 'lucide-react';
import { getRegionsByMacro } from '@/data/italyRegions';

const Header: React.FC = () => {
  const { t } = useTranslation();
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [placesDropdownOpen, setPlacesDropdownOpen] = useState(false);
  const [tipsDropdownOpen, setTipsDropdownOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [, setNavigate] = useLocation();
  
  const placesDropdownRef = useRef<HTMLDivElement>(null);
  const tipsDropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  // Get regions data for dropdown
  const regionsByMacro = getRegionsByMacro();
  
  // Check if current location matches the given path
  const isActive = (path: string) => {
    if (path === '/') return location === path;
    return location.startsWith(path);
  };
  
  // Handle scroll event to change header background
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (placesDropdownRef.current && !placesDropdownRef.current.contains(event.target as Node)) {
        setPlacesDropdownOpen(false);
      }
      if (tipsDropdownRef.current && !tipsDropdownRef.current.contains(event.target as Node)) {
        setTipsDropdownOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  // Close mobile menu when location changes
  useEffect(() => {
    setIsMenuOpen(false);
    setSearchOpen(false);
  }, [location]);
  
  // Focus search input when search is opened
  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
    }
  }, [searchOpen]);
  
  // Handle search submission
  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (searchQuery.trim()) {
      setNavigate(`/places?search=${encodeURIComponent(searchQuery)}`);
      setSearchOpen(false);
    }
  };
  
  // Close search on escape key
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSearchOpen(false);
      }
    };
    
    document.addEventListener('keydown', handleEscKey);
    return () => document.removeEventListener('keydown', handleEscKey);
  }, []);
  
  return (
    <>
      <header 
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      >
        {/* Background with conditional styling */}
        <div className={`absolute inset-0 transition-opacity duration-300 ${
          isScrolled ? 'bg-white shadow-md opacity-100' : 'bg-black/40 backdrop-blur-sm opacity-90'
        }`}></div>
        
        {/* Top bar with contact info (visible only when scrolled) */}
        {isScrolled && (
          <div className="hidden lg:block bg-[#1A3A5A] text-white py-1 text-xs relative z-10">
            <div className="container mx-auto px-4 flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <a href="tel:+391234567890" className="flex items-center hover:text-gray-200 transition-colors">
                  <Phone size={12} className="mr-1" />
                  <span>+39 123 456 7890</span>
                </a>
                <a href="mailto:info@bellaitalia-journey.com" className="flex items-center hover:text-gray-200 transition-colors">
                  <Mail size={12} className="mr-1" />
                  <span>info@bellaitalia-journey.com</span>
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-gray-200 transition-colors">
                  <Instagram size={12} />
                </a>
                <a href="#" className="hover:text-gray-200 transition-colors">
                  <User size={12} />
                </a>
                <div className="h-4 border-l border-white/30 mx-1"></div>
                <LanguageSwitcher />
              </div>
            </div>
          </div>
        )}
        
        <div className="w-full h-1 flex relative z-10">
          <div className="w-1/3 bg-[#009246]"></div>
          <div className="w-1/3 bg-white"></div>
          <div className="w-1/3 bg-[#CE2B37]"></div>
        </div>
        
        <div className="container mx-auto px-4 py-3 relative z-10">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/">
              <div className="flex items-center cursor-pointer">
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-6 bg-[#009246] rounded-sm"></div>
                  <div className="w-2 h-6 bg-white rounded-sm border border-gray-300 shadow-sm"></div>
                  <div className="w-2 h-6 bg-[#CE2B37] rounded-sm"></div>
                </div>
                <div className={`ml-2 flex flex-col ${isScrolled ? 'text-[#1A3A5A]' : 'text-white'}`}>
                  <span className="font-bold text-xl font-serif tracking-tight leading-none">Bella Italia</span>
                  <span className="text-[10px] uppercase tracking-wider">Journey</span>
                </div>
              </div>
            </Link>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-3">
              <NavLink to="/" isActive={isActive('/')} isScrolled={isScrolled} icon={<Home size={16} />}>
                {t('nav.home')}
              </NavLink>
              
              {/* Places dropdown */}
              <div className="relative" ref={placesDropdownRef}>
                <div 
                  className={`
                    flex items-center gap-1 px-3 py-2 rounded-md cursor-pointer
                    ${isActive('/places') 
                      ? isScrolled ? 'text-[#CE2B37]' : 'text-white' 
                      : isScrolled ? 'text-gray-700 hover:text-[#CE2B37] hover:bg-gray-50' : 'text-white/90 hover:text-white hover:bg-white/10'
                    }
                    ${placesDropdownOpen && isScrolled ? 'bg-gray-50' : ''}
                    ${placesDropdownOpen && !isScrolled ? 'bg-white/10' : ''}
                  `}
                  onClick={() => {
                    setPlacesDropdownOpen(!placesDropdownOpen);
                    setTipsDropdownOpen(false);
                  }}
                >
                  <MapPin size={16} />
                  <span className="text-sm font-medium">{t('nav.places')}</span>
                  <ChevronDown 
                    size={14} 
                    className={`transition-transform duration-200 ${placesDropdownOpen ? 'rotate-180' : ''}`} 
                  />
                </div>
                
                {/* Dropdown menu */}
                {placesDropdownOpen && (
                  <div className="absolute top-full mt-1 left-0 z-10 bg-white rounded-lg shadow-lg overflow-hidden w-72 border border-gray-100">
                    <div className="py-2">
                      <Link to="/places">
                        <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 font-medium border-b border-gray-100">
                          {t('nav.allDestinations', 'All Destinations')}
                        </div>
                      </Link>
                      
                      <div className="grid grid-cols-3 gap-x-2 px-4 pt-2 pb-1">
                        <Link to="/places?region=north">
                          <div className="flex items-center justify-center px-2 py-1 text-xs bg-[#009246]/10 text-[#009246] rounded hover:bg-[#009246]/20 transition-colors font-medium">
                            {t('regions.north')}
                          </div>
                        </Link>
                        <Link to="/places?region=central">
                          <div className="flex items-center justify-center px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded hover:bg-gray-200 transition-colors font-medium">
                            {t('regions.central')}
                          </div>
                        </Link>
                        <Link to="/places?region=south">
                          <div className="flex items-center justify-center px-2 py-1 text-xs bg-[#CE2B37]/10 text-[#CE2B37] rounded hover:bg-[#CE2B37]/20 transition-colors font-medium">
                            {t('regions.south')}
                          </div>
                        </Link>
                      </div>
                      
                      {/* Northern Italy */}
                      <div className="flex items-center px-4 py-1.5 text-xs font-bold text-[#009246] uppercase tracking-wider mt-1">
                        <span className="w-2 h-2 rounded-full bg-[#009246] mr-1.5"></span>
                        {t('regions.north')}
                      </div>
                      <div className="grid grid-cols-2 gap-x-1 mb-1">
                        {regionsByMacro.north.map(region => (
                          <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                            <div className="block px-4 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                              {t(`regions.${region.id}`, region.nameEn)}
                            </div>
                          </Link>
                        ))}
                      </div>
                      
                      {/* Central Italy */}
                      <div className="flex items-center px-4 py-1.5 text-xs font-bold text-gray-600 uppercase tracking-wider mt-1">
                        <span className="w-2 h-2 rounded-full bg-gray-400 mr-1.5"></span>
                        {t('regions.central')}
                      </div>
                      <div className="grid grid-cols-2 gap-x-1 mb-1">
                        {regionsByMacro.central.map(region => (
                          <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                            <div className="block px-4 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                              {t(`regions.${region.id}`, region.nameEn)}
                            </div>
                          </Link>
                        ))}
                      </div>
                      
                      {/* Southern Italy */}
                      <div className="flex items-center px-4 py-1.5 text-xs font-bold text-[#CE2B37] uppercase tracking-wider mt-1">
                        <span className="w-2 h-2 rounded-full bg-[#CE2B37] mr-1.5"></span>
                        {t('regions.south')}
                      </div>
                      <div className="grid grid-cols-2 gap-x-1">
                        {regionsByMacro.south.map(region => (
                          <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                            <div className="block px-4 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                              {t(`regions.${region.id}`, region.nameEn)}
                            </div>
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Travel Tips dropdown */}
              <div className="relative" ref={tipsDropdownRef}>
                <div 
                  className={`
                    flex items-center gap-1 px-3 py-2 rounded-md cursor-pointer
                    ${isActive('/travel-tips') 
                      ? isScrolled ? 'text-[#CE2B37]' : 'text-white' 
                      : isScrolled ? 'text-gray-700 hover:text-[#CE2B37] hover:bg-gray-50' : 'text-white/90 hover:text-white hover:bg-white/10'
                    }
                    ${tipsDropdownOpen && isScrolled ? 'bg-gray-50' : ''}
                    ${tipsDropdownOpen && !isScrolled ? 'bg-white/10' : ''}
                  `}
                  onClick={() => {
                    setTipsDropdownOpen(!tipsDropdownOpen);
                    setPlacesDropdownOpen(false);
                  }}
                >
                  <Compass size={16} />
                  <span className="text-sm font-medium">{t('nav.travelTips')}</span>
                  <ChevronDown 
                    size={14} 
                    className={`transition-transform duration-200 ${tipsDropdownOpen ? 'rotate-180' : ''}`} 
                  />
                </div>
                
                {/* Dropdown menu */}
                {tipsDropdownOpen && (
                  <div className="absolute top-full mt-1 left-0 z-10 bg-white rounded-lg shadow-lg overflow-hidden w-60 border border-gray-100">
                    <div className="py-2">
                      <Link to="/travel-tips">
                        <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 font-medium border-b border-gray-100">
                          {t('nav.allTravelTips', 'All Travel Tips')}
                        </div>
                      </Link>
                      
                      <Link to="/travel-tips?category=food">
                        <div className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          <div className="w-8 h-8 bg-[#CE2B37]/10 rounded-full flex items-center justify-center mr-3">
                            <Heart size={16} className="text-[#CE2B37]" />
                          </div>
                          {t('travelTips.categories.food', 'Food & Wine')}
                        </div>
                      </Link>
                      
                      <Link to="/travel-tips?category=cultural">
                        <div className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          <div className="w-8 h-8 bg-[#1A3A5A]/10 rounded-full flex items-center justify-center mr-3">
                            <Info size={16} className="text-[#1A3A5A]" />
                          </div>
                          {t('travelTips.categories.cultural', 'Cultural Tips')}
                        </div>
                      </Link>
                      
                      <Link to="/travel-tips?category=outdoor">
                        <div className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          <div className="w-8 h-8 bg-[#009246]/10 rounded-full flex items-center justify-center mr-3">
                            <Compass size={16} className="text-[#009246]" />
                          </div>
                          {t('travelTips.categories.outdoor', 'Outdoor Activities')}
                        </div>
                      </Link>
                      
                      <Link to="/travel-tips?category=practical">
                        <div className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                            <FileText size={16} className="text-gray-600" />
                          </div>
                          {t('travelTips.categories.practical', 'Practical Information')}
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
              
              <NavLink to="/blog" isActive={isActive('/blog')} isScrolled={isScrolled} icon={<FileText size={16} />}>
                {t('nav.blog')}
              </NavLink>
              <NavLink to="/about" isActive={isActive('/about')} isScrolled={isScrolled} icon={<Info size={16} />}>
                {t('nav.about')}
              </NavLink>
              <NavLink to="/contact" isActive={isActive('/contact')} isScrolled={isScrolled} icon={<Mail size={16} />}>
                {t('nav.contact')}
              </NavLink>
              
              {/* Search Button */}
              <button
                onClick={() => setSearchOpen(true)}
                className={`ml-1 p-2 rounded-full flex items-center justify-center transition-colors ${
                  isScrolled 
                    ? 'hover:bg-gray-100 text-gray-700' 
                    : 'hover:bg-white/10 text-white'
                }`}
                aria-label="Search"
              >
                <Search size={18} />
              </button>
              
              {/* Language Switcher (visible only when not scrolled on desktop) */}
              {!isScrolled && (
                <div className="ml-1 lg:ml-2 md:block lg:hidden">
                  <LanguageSwitcher />
                </div>
              )}
            </nav>
            
            {/* Mobile Menu Button */}
            <div className="flex md:hidden items-center">
              {/* Search button on mobile */}
              <button
                onClick={() => setSearchOpen(true)}
                className={`p-2 rounded-md ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}
                aria-label="Search"
              >
                <Search size={20} />
              </button>
              
              <button 
                className={`p-2 rounded-md focus:outline-none ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                aria-label="Toggle menu"
              >
                {isMenuOpen ? (
                  <X size={24} />
                ) : (
                  <Menu size={24} />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>
      
      {/* Search Overlay */}
      <div 
        className={`fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] transition-opacity duration-300 ${
          searchOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="container mx-auto h-full flex flex-col">
          <div className="flex justify-end p-4">
            <button 
              onClick={() => setSearchOpen(false)}
              className="text-white p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="flex-1 flex items-center justify-center px-4">
            <div className="w-full max-w-2xl">
              <h2 className="text-white text-2xl md:text-3xl mb-6 text-center font-serif">
                {t('search.title', 'Search Destinations')}
              </h2>
              <form onSubmit={handleSearch} className="relative">
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('search.placeholder', 'Enter destination, region or keyword...')}
                  className="w-full py-4 px-6 pl-12 text-lg rounded-lg bg-white/10 text-white placeholder-white/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/30"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
                <button
                  type="submit"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-[#CE2B37] text-white px-4 py-2 rounded-md hover:bg-[#CE2B37]/90 transition-colors"
                >
                  {t('search.button', 'Search')}
                </button>
              </form>
              
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <span className="text-white/70 text-sm">{t('search.popular', 'Popular:')}</span>
                <button 
                  onClick={() => {
                    setSearchQuery('Rome');
                    handleSearch();
                  }}
                  className="text-sm text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  Rome
                </button>
                <button 
                  onClick={() => {
                    setSearchQuery('Venice');
                    handleSearch();
                  }}
                  className="text-sm text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  Venice
                </button>
                <button 
                  onClick={() => {
                    setSearchQuery('Florence');
                    handleSearch();
                  }}
                  className="text-sm text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  Florence
                </button>
                <button 
                  onClick={() => {
                    setSearchQuery('Tuscany');
                    handleSearch();
                  }}
                  className="text-sm text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  Tuscany
                </button>
                <button 
                  onClick={() => {
                    setSearchQuery('Amalfi Coast');
                    handleSearch();
                  }}
                  className="text-sm text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  Amalfi Coast
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={`md:hidden fixed inset-0 z-50 bg-black bg-opacity-50 transition-opacity duration-300 ${
          isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsMenuOpen(false)}
      >
        <div 
          className={`fixed inset-y-0 right-0 max-w-xs w-full bg-white shadow-xl transform transition-transform duration-300 ease-in-out ${
            isMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-6 bg-[#009246] rounded-sm"></div>
              <div className="w-2 h-6 bg-white rounded-sm border border-gray-300"></div>
              <div className="w-2 h-6 bg-[#CE2B37] rounded-sm"></div>
              <div className="ml-2 flex flex-col text-[#1A3A5A]">
                <span className="font-bold text-lg leading-none">Bella Italia</span>
                <span className="text-xs uppercase tracking-wider">Journey</span>
              </div>
            </div>
            <button 
              className="p-2 rounded-md hover:bg-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              <X size={20} className="text-gray-500" />
            </button>
          </div>
          
          <div className="p-4 bg-[#1A3A5A]/5 border-b flex items-center">
            <LanguageSwitcher />
            <div className="ml-auto text-sm flex items-center text-gray-600">
              <Phone size={14} className="mr-1.5" />
              <a href="tel:+391234567890">+39 123 456 7890</a>
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-160px)]">
            <div className="py-2">
              <MobileNavLink to="/" isActive={isActive('/')} onClick={() => setIsMenuOpen(false)} icon={<Home size={18} />}>
                {t('nav.home')}
              </MobileNavLink>
              <MobileNavLink to="/places" isActive={isActive('/places')} onClick={() => setIsMenuOpen(false)} icon={<MapPin size={18} />}>
                {t('nav.places')}
              </MobileNavLink>
              <MobileNavLink to="/travel-tips" isActive={isActive('/travel-tips')} onClick={() => setIsMenuOpen(false)} icon={<Compass size={18} />}>
                {t('nav.travelTips')}
              </MobileNavLink>
              <MobileNavLink to="/blog" isActive={isActive('/blog')} onClick={() => setIsMenuOpen(false)} icon={<FileText size={18} />}>
                {t('nav.blog')}
              </MobileNavLink>
              <MobileNavLink to="/about" isActive={isActive('/about')} onClick={() => setIsMenuOpen(false)} icon={<Info size={18} />}>
                {t('nav.about')}
              </MobileNavLink>
              <MobileNavLink to="/contact" isActive={isActive('/contact')} onClick={() => setIsMenuOpen(false)} icon={<Mail size={18} />}>
                {t('nav.contact')}
              </MobileNavLink>
            </div>
            
            {/* Italy regions accordion */}
            <div className="mt-2 border-t pt-4 pb-20">
              <div className="px-4 mb-2">
                <h3 className="text-sm font-bold text-[#1A3A5A] flex items-center">
                  <MapPin size={14} className="mr-1.5" />
                  {t('nav.exploreRegions', 'Explore Regions')}
                </h3>
              </div>
              
              {/* Northern Italy */}
              <div className="px-4 py-2 bg-[#009246]/5 border-y flex items-center">
                <span className="w-2 h-2 bg-[#009246] rounded-full mr-2"></span>
                <span className="text-xs font-bold text-[#009246] uppercase tracking-wider">
                  {t('regions.north')}
                </span>
              </div>
              <div className="py-1">
                {regionsByMacro.north.slice(0, 5).map(region => (
                  <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                    <div className="block px-6 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                      {t(`regions.${region.id}`, region.nameEn)}
                    </div>
                  </Link>
                ))}
                <Link to="/places?region=north">
                  <div className="block px-6 py-1.5 text-sm text-[#CE2B37] hover:bg-gray-50 flex items-center">
                    {t('nav.viewAllRegions', 'View all regions')}
                    <ChevronDown size={14} className="ml-1" />
                  </div>
                </Link>
              </div>
              
              {/* Central Italy */}
              <div className="px-4 py-2 bg-gray-50 border-y flex items-center">
                <span className="w-2 h-2 bg-gray-500 rounded-full mr-2"></span>
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  {t('regions.central')}
                </span>
              </div>
              <div className="py-1">
                {regionsByMacro.central.slice(0, 4).map(region => (
                  <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                    <div className="block px-6 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                      {t(`regions.${region.id}`, region.nameEn)}
                    </div>
                  </Link>
                ))}
                <Link to="/places?region=central">
                  <div className="block px-6 py-1.5 text-sm text-[#CE2B37] hover:bg-gray-50 flex items-center">
                    {t('nav.viewAllRegions', 'View all regions')}
                    <ChevronDown size={14} className="ml-1" />
                  </div>
                </Link>
              </div>
              
              {/* Southern Italy */}
              <div className="px-4 py-2 bg-[#CE2B37]/5 border-y flex items-center">
                <span className="w-2 h-2 bg-[#CE2B37] rounded-full mr-2"></span>
                <span className="text-xs font-bold text-[#CE2B37] uppercase tracking-wider">
                  {t('regions.south')}
                </span>
              </div>
              <div className="py-1">
                {regionsByMacro.south.slice(0, 4).map(region => (
                  <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                    <div className="block px-6 py-1.5 text-sm text-gray-700 hover:bg-gray-50">
                      {t(`regions.${region.id}`, region.nameEn)}
                    </div>
                  </Link>
                ))}
                <Link to="/places?region=south">
                  <div className="block px-6 py-1.5 text-sm text-[#CE2B37] hover:bg-gray-50 flex items-center">
                    {t('nav.viewAllRegions', 'View all regions')}
                    <ChevronDown size={14} className="ml-1" />
                  </div>
                </Link>
              </div>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-white">
            <Link to="/contact">
              <button className="w-full bg-[#CE2B37] text-white py-2.5 rounded-lg font-medium flex items-center justify-center">
                <Heart size={16} className="mr-2" />
                {t('nav.getInTouch', 'Get in Touch')}
              </button>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

// Desktop navigation link
interface NavLinkProps {
  to: string;
  isActive: boolean;
  isScrolled: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, isActive, isScrolled, icon, children }) => (
  <Link to={to}>
    <div className={`
      relative flex items-center gap-1 px-3 py-2 rounded-md transition-colors duration-200
      ${isActive 
        ? isScrolled 
          ? 'text-[#CE2B37] bg-gray-50 font-medium' 
          : 'text-white bg-white/20 font-medium' 
        : isScrolled 
          ? 'text-gray-700 hover:text-[#CE2B37] hover:bg-gray-50' 
          : 'text-white hover:text-white hover:bg-white/20'
      }
    `}>
      {icon}
      <span className="text-sm">{children}</span>
      {isActive && (
        <span className={`absolute bottom-0 left-0 w-full h-0.5 ${isScrolled ? 'bg-[#CE2B37]' : 'bg-white'}`} />
      )}
    </div>
  </Link>
);

// Mobile navigation link
interface MobileNavLinkProps {
  to: string;
  isActive: boolean;
  onClick: () => void;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, isActive, onClick, icon, children }) => (
  <Link to={to}>
    <div 
      className={`flex items-center gap-3 px-4 py-3 cursor-pointer ${
        isActive 
          ? 'bg-[#CE2B37]/5 text-[#CE2B37] font-medium'
          : 'text-gray-700 hover:bg-gray-50'
      }`}
      onClick={onClick}
    >
      <div className={`${isActive ? 'text-[#CE2B37]' : 'text-gray-500'} w-6 flex items-center justify-center`}>
        {icon}
      </div>
      <span className="text-sm">{children}</span>
    </div>
  </Link>
);

export default Header;