import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import { getRegionsByMacro } from '@/data/italyRegions';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube, 
  Heart, 
  ExternalLink, 
  Clock
} from 'lucide-react';

const Footer: React.FC = () => {
  const { t, i18n } = useTranslation();
  const currentYear = new Date().getFullYear();
  const regionsByMacro = getRegionsByMacro();
  
  return (
    <footer className="bg-[#1A3A5A] text-white">
      {/* Italian flag-inspired strips */}
      <div className="w-full h-2 flex">
        <div className="w-1/3 bg-[#009246]"></div>
        <div className="w-1/3 bg-white"></div>
        <div className="w-1/3 bg-[#CE2B37]"></div>
      </div>
      
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* About Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center mb-4">
              <div className="flex items-center space-x-1 mr-2">
                <div className="w-2 h-6 bg-[#009246] rounded-sm"></div>
                <div className="w-2 h-6 bg-white rounded-sm shadow-sm"></div>
                <div className="w-2 h-6 bg-[#CE2B37] rounded-sm"></div>
              </div>
              <h3 className="font-bold text-xl font-serif">Bella Italia <span className="text-sm font-normal">Journey</span></h3>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              {t('footer.aboutText', 'Experience the authentic Italy with us. We curate unique travel experiences that showcase the rich culture, stunning landscapes, and culinary delights of this beautiful Mediterranean country.')}
            </p>
            
            <div className="flex space-x-3 mb-8">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" 
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#CE2B37]/80 text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" 
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#CE2B37]/80 text-white transition-colors">
                <Twitter size={18} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" 
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#CE2B37]/80 text-white transition-colors">
                <Instagram size={18} />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" 
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#CE2B37]/80 text-white transition-colors">
                <Youtube size={18} />
              </a>
            </div>
            
            <div className="bg-white/10 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Clock size={16} className="text-[#009246] mr-2" />
                <h4 className="font-medium">{t('footer.operatingHours', 'Travel Office Hours')}</h4>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-300">
                <div>{t('footer.mondayFriday', 'Monday-Friday')}:</div>
                <div>9:00 - 18:00</div>
                <div>{t('footer.saturday', 'Saturday')}:</div>
                <div>10:00 - 15:00</div>
                <div>{t('footer.sunday', 'Sunday')}:</div>
                <div>{t('footer.closed', 'Closed')}</div>
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-5 flex items-center">
              <span className="w-8 h-0.5 bg-[#CE2B37] mr-2"></span>
              {t('footer.quickLinks', 'Quick Links')}
            </h3>
            <ul className="space-y-3">
              <li>
                <Link to="/">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-[#009246] rounded-full mr-2"></span>
                    {t('nav.home')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/places">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mr-2"></span>
                    {t('nav.places')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/travel-tips">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-[#CE2B37] rounded-full mr-2"></span>
                    {t('nav.travelTips')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/blog">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-[#009246] rounded-full mr-2"></span>
                    {t('nav.blog')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/about">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-white rounded-full mr-2"></span>
                    {t('nav.about')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/contact">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center">
                    <span className="w-1.5 h-1.5 bg-[#CE2B37] rounded-full mr-2"></span>
                    {t('nav.contact')}
                  </div>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Regions */}
          <div>
            <h3 className="text-lg font-semibold mb-5 flex items-center">
              <span className="w-8 h-0.5 bg-white mr-2"></span>
              {t('footer.regions', 'Regions')}
            </h3>
            <ul className="space-y-3">
              {/* North, Central, South */}
              <li>
                <Link to="/places?region=north">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center font-medium">
                    <span className="w-2 h-2 bg-[#009246] rounded-full mr-2"></span>
                    {t('regions.north')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/places?region=central">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center font-medium">
                    <span className="w-2 h-2 bg-white rounded-full mr-2"></span>
                    {t('regions.central')}
                  </div>
                </Link>
              </li>
              <li>
                <Link to="/places?region=south">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center font-medium">
                    <span className="w-2 h-2 bg-[#CE2B37] rounded-full mr-2"></span>
                    {t('regions.south')}
                  </div>
                </Link>
              </li>
              
              {/* Popular Regions */}
              <li className="pt-2">
                <h4 className="text-xs uppercase text-gray-400 mb-2">{t('footer.popularRegions', 'Popular Regions')}</h4>
                <div className="grid grid-cols-1 gap-2">
                  {[...regionsByMacro.north, ...regionsByMacro.central, ...regionsByMacro.south]
                    .slice(0, 5)
                    .map(region => (
                      <Link key={region.id} to={`/places?detailed_region=${region.id}`}>
                        <div className="text-sm text-gray-300 hover:text-white transition-colors cursor-pointer pl-3 border-l border-gray-700 hover:border-gray-500">
                          {i18n.language === 'sl' ? region.nameSl : region.nameEn}
                        </div>
                      </Link>
                    ))
                  }
                  <Link to="/places">
                    <div className="text-sm text-[#CE2B37] hover:text-[#CE2B37]/80 transition-colors cursor-pointer pl-3 border-l border-gray-700 hover:border-gray-500 flex items-center mt-1">
                      {t('footer.viewAllRegions', 'View all regions')}
                      <ExternalLink size={12} className="ml-1" />
                    </div>
                  </Link>
                </div>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-5 flex items-center">
              <span className="w-8 h-0.5 bg-[#CE2B37] mr-2"></span>
              {t('footer.contactUs', 'Contact Us')}
            </h3>
            <div className="space-y-4">
              <p className="flex items-start">
                <MapPin className="w-5 h-5 text-gray-300 mr-3 mt-1 flex-shrink-0" />
                <span className="text-gray-300">
                  Via del Corso 123<br />
                  00186 Roma, Italy
                </span>
              </p>
              <p className="flex items-center">
                <Phone className="w-5 h-5 text-gray-300 mr-3 flex-shrink-0" />
                <span className="text-gray-300">+39 123 456 7890</span>
              </p>
              <p className="flex items-center">
                <Mail className="w-5 h-5 text-gray-300 mr-3 flex-shrink-0" />
                <span className="text-gray-300">info@bellaitalia-journey.com</span>
              </p>
              
              <div className="pt-4">
                <Link to="/contact">
                  <button className="bg-white/10 hover:bg-[#CE2B37] text-white px-5 py-2 rounded-md text-sm transition-colors flex items-center">
                    {t('footer.sendMessage', 'Send us a message')}
                    <Heart size={14} className="ml-2" />
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm mb-4 md:mb-0">
            © {currentYear} Bella Italia Journey. {t('footer.allRightsReserved', 'All rights reserved.')}
          </p>
          <div className="flex flex-wrap gap-6">
            <Link to="/privacy-policy">
              <div className="text-gray-300 hover:text-white text-sm transition-colors cursor-pointer">
                {t('footer.privacyPolicy', 'Privacy Policy')}
              </div>
            </Link>
            <Link to="/terms">
              <div className="text-gray-300 hover:text-white text-sm transition-colors cursor-pointer">
                {t('footer.terms', 'Terms & Conditions')}
              </div>
            </Link>
            <Link to="/sitemap">
              <div className="text-gray-300 hover:text-white text-sm transition-colors cursor-pointer">
                {t('footer.sitemap', 'Sitemap')}
              </div>
            </Link>
            <Link to="/faq">
              <div className="text-gray-300 hover:text-white text-sm transition-colors cursor-pointer">
                {t('footer.faq', 'FAQ')}
              </div>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;