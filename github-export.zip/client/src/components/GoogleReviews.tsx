import { useState } from "react";
import { Star, StarHalf } from "lucide-react";
import { useTranslation } from "react-i18next";

type Review = {
  id: number;
  author: string;
  rating: number;
  date: string;
  content: string;
  avatar: string;
};

export default function GoogleReviews() {
  const { t } = useTranslation();
  const [reviews] = useState<Review[]>([
    {
      id: 1,
      author: "Sophia Martinez",
      rating: 5,
      date: "2 months ago",
      content: "This blog has been invaluable for planning our trip to Tuscany. The local food and wine recommendations were spot on! We discovered amazing family-run restaurants we would have never found otherwise.",
      avatar: "https://randomuser.me/api/portraits/women/45.jpg"
    },
    {
      id: 2,
      author: "Michael Johnson",
      rating: 5,
      date: "1 month ago",
      content: "The detailed guides about traveling between regions saved us so much time and stress. Their accommodation tips helped us find a charming apartment in Rome with an amazing view of the city.",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      id: 3,
      author: "Emma Wilson",
      rating: 4.5,
      date: "3 months ago",
      content: "I followed their 'must-see attractions' recommendations for Venice and discovered some hidden gems away from the tourist crowds. Their blog posts are both informative and entertaining.",
      avatar: "https://randomuser.me/api/portraits/women/63.jpg"
    },
    {
      id: 4,
      author: "Robert Thompson",
      rating: 5,
      date: "2 weeks ago",
      content: "The 'local drink' section for each region was particularly helpful. We tried Aperol Spritz in Venice and limoncello on the Amalfi Coast based on their recommendations. Excellent travel blog!",
      avatar: "https://randomuser.me/api/portraits/men/78.jpg"
    }
  ]);

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-yellow-400 text-yellow-400 w-5 h-5" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-yellow-400 text-yellow-400 w-5 h-5" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-yellow-400 w-5 h-5 opacity-40" />);
    }
    
    return stars;
  };
  
  const calculateAverageRating = () => {
    const sum = reviews.reduce((total, review) => total + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('reviews.title', 'Traveler Reviews')}</h2>
          <div className="flex items-center justify-center mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="24" height="24" className="mr-2">
              <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
              <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
              <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
              <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
            </svg>
            <span className="text-lg font-medium">Google Reviews</span>
          </div>
          <div className="flex items-center justify-center mb-4">
            <div className="flex mr-2">
              {renderStars(parseFloat(calculateAverageRating()))}
            </div>
            <span className="text-2xl font-bold">{calculateAverageRating()}</span>
            <span className="text-gray-500 ml-1">/ 5</span>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">{t('reviews.subtitle', 'Based on reviews from travelers who followed our recommendations')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((review) => (
            <div key={review.id} className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-start mb-4">
                <img src={review.avatar} alt={review.author} className="w-12 h-12 rounded-full mr-4" />
                <div>
                  <h3 className="font-bold text-gray-800">{review.author}</h3>
                  <div className="flex items-center mb-1">
                    <div className="flex mr-2">
                      {renderStars(review.rating)}
                    </div>
                    <span className="text-sm text-gray-500">{review.date}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">{review.content}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <a 
            href="https://g.page/r/example-review-link" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-flex items-center text-red-600 hover:text-red-700 font-medium transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="20" height="20" className="mr-2">
              <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
              <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
              <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
              <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
            </svg>
            {t('reviews.writeReview', 'Write a review on Google')}
          </a>
        </div>
      </div>
    </section>
  );
}