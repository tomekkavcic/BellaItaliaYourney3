import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import { Search, Map, MapPin, ChevronRight } from 'lucide-react';
import { getRegionsByMacro } from '@/data/italyRegions';

const Hero: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [, setLocation] = useLocation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  
  const regionsByMacro = getRegionsByMacro();
  
  // Array of hero background images
  const heroImages = [
    'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=1920&h=1080&q=80', // Cinque Terre
    'https://images.unsplash.com/photo-1534445867742-43195f401b6c?auto=format&fit=crop&w=1920&h=1080&q=80', // Venice
    'https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?auto=format&fit=crop&w=1920&h=1080&q=80', // Rome
    'https://images.unsplash.com/photo-1499678329028-101435549a4e?auto=format&fit=crop&w=1920&h=1080&q=80', // Florence
    'https://images.unsplash.com/photo-1533676802871-eca1ae998cd5?auto=format&fit=crop&w=1920&h=1080&q=80', // Amalfi Coast
  ];
  
  // Image caption information
  const imageLocations = [
    { name: 'Cinque Terre', region: 'Liguria' },
    { name: 'Venice', region: 'Veneto' },
    { name: 'Rome', region: 'Lazio' },
    { name: 'Florence', region: 'Tuscany' },
    { name: 'Amalfi Coast', region: 'Campania' },
  ];
  
  // Automatic slideshow for hero images
  useEffect(() => {
    const interval = setInterval(() => {
      setIsImageLoaded(false);
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % heroImages.length);
    }, 8000);
    
    return () => clearInterval(interval);
  }, [heroImages.length]);
  
  // Handle image load completed
  const handleImageLoaded = () => {
    setIsImageLoaded(true);
  };
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/places?search=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  return (
    <div className="hero-section relative h-screen min-h-[600px] max-h-[800px] flex items-center overflow-hidden">
      {/* Hero background with overlay */}
      {heroImages.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000 ${
            currentImageIndex === index ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ 
            backgroundImage: `url(${image})`,
          }}
        >
          {/* Preload the next image */}
          {index === (currentImageIndex + 1) % heroImages.length && (
            <img 
              src={heroImages[(currentImageIndex + 1) % heroImages.length]} 
              className="hidden"
              onLoad={handleImageLoaded}
              alt="preload"
            />
          )}
          
          {/* Dark gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70"></div>
        </div>
      ))}
      
      {/* Image location badge */}
      <div className={`absolute bottom-24 left-6 md:left-12 bg-black/30 backdrop-blur-md text-white px-3 py-1.5 rounded-full 
        flex items-center transition-opacity duration-700 ${isImageLoaded ? 'opacity-100' : 'opacity-0'}`}>
        <MapPin size={14} className="mr-1 text-[#CE2B37]" />
        <span className="text-xs font-medium">
          {imageLocations[currentImageIndex].name}, {t(`regions.${imageLocations[currentImageIndex].region.toLowerCase()}`, imageLocations[currentImageIndex].region)}
        </span>
      </div>

      {/* Italian flag-inspired strips */}
      <div className="absolute bottom-0 left-0 w-full h-4 flex">
        <div className="w-1/3 bg-[#009246]"></div>
        <div className="w-1/3 bg-white"></div>
        <div className="w-1/3 bg-[#CE2B37]"></div>
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            {t('hero.title')}
          </h1>
          
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto drop-shadow-md">
            {t('hero.subtitle')}
          </p>
          
          <div className="max-w-xl mx-auto">
            <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-2">
              <div className="relative flex-grow">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('hero.searchPlaceholder')}
                  className="w-full px-4 py-4 pl-12 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#CE2B37] shadow-lg"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              </div>
              <button 
                type="submit"
                className="px-6 py-4 bg-[#CE2B37] hover:bg-[#CE2B37]/90 text-white font-medium rounded-lg transition-colors shadow-lg flex items-center justify-center"
              >
                {t('hero.searchButton')}
              </button>
            </form>
          </div>

          <div className="mt-12 space-y-6">
            <h3 className="text-white text-xl font-semibold drop-shadow-md flex items-center justify-center">
              <Map size={20} className="mr-2" />
              {t('hero.popularRegions')}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
              {/* North Italy */}
              <div className="flex flex-col">
                <button 
                  onClick={() => setLocation('/places?region=north')}
                  className="px-5 py-2.5 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors border border-white/20 backdrop-blur-sm shadow-lg flex items-center justify-center mb-2"
                >
                  <span className="font-medium">{t('regions.north')}</span>
                  <ChevronRight size={16} className="ml-1" />
                </button>
                <div className="space-y-1 px-1">
                  {regionsByMacro.north.slice(0, 3).map(region => (
                    <button 
                      key={region.id}
                      onClick={() => setLocation(`/places?detailed_region=${region.id}`)}
                      className="w-full text-sm text-white/80 hover:text-white py-1 text-left transition-colors flex items-center"
                    >
                      <span className="h-1 w-1 bg-[#009246] rounded-full mr-2"></span>
                      {i18n.language === 'sl' ? region.nameSl : region.nameEn}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Central Italy */}
              <div className="flex flex-col">
                <button 
                  onClick={() => setLocation('/places?region=central')}
                  className="px-5 py-2.5 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors border border-white/20 backdrop-blur-sm shadow-lg flex items-center justify-center mb-2"
                >
                  <span className="font-medium">{t('regions.central')}</span>
                  <ChevronRight size={16} className="ml-1" />
                </button>
                <div className="space-y-1 px-1">
                  {regionsByMacro.central.slice(0, 3).map(region => (
                    <button 
                      key={region.id}
                      onClick={() => setLocation(`/places?detailed_region=${region.id}`)}
                      className="w-full text-sm text-white/80 hover:text-white py-1 text-left transition-colors flex items-center"
                    >
                      <span className="h-1 w-1 bg-white rounded-full mr-2"></span>
                      {i18n.language === 'sl' ? region.nameSl : region.nameEn}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* South Italy */}
              <div className="flex flex-col">
                <button 
                  onClick={() => setLocation('/places?region=south')}
                  className="px-5 py-2.5 bg-white/20 hover:bg-white/30 text-white rounded-lg transition-colors border border-white/20 backdrop-blur-sm shadow-lg flex items-center justify-center mb-2"
                >
                  <span className="font-medium">{t('regions.south')}</span>
                  <ChevronRight size={16} className="ml-1" />
                </button>
                <div className="space-y-1 px-1">
                  {regionsByMacro.south.slice(0, 3).map(region => (
                    <button 
                      key={region.id}
                      onClick={() => setLocation(`/places?detailed_region=${region.id}`)}
                      className="w-full text-sm text-white/80 hover:text-white py-1 text-left transition-colors flex items-center"
                    >
                      <span className="h-1 w-1 bg-[#CE2B37] rounded-full mr-2"></span>
                      {i18n.language === 'sl' ? region.nameSl : region.nameEn}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;