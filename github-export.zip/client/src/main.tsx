import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./lib/i18n"; // Import i18n configuration

document.documentElement.style.setProperty('--primary', '#2c3e50');
document.documentElement.style.setProperty('--secondary', '#e67e22');
document.documentElement.style.setProperty('--accent', '#d35400');

createRoot(document.getElementById("root")!).render(<App />);
