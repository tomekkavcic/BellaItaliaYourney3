// Places coordinates for SVG map
export const mapPlaces = [
  {
    id: 1,
    name: "Rome",
    region: "central",
    x: 210,
    y: 195
  },
  {
    id: 2,
    name: "Florence",
    region: "central",
    x: 165,
    y: 150
  },
  {
    id: 3,
    name: "Venice",
    region: "north",
    x: 230,
    y: 105
  },
  {
    id: 4,
    name: "Amalfi Coast",
    region: "south",
    x: 230,
    y: 230
  },
  {
    id: 5,
    name: "Milan",
    region: "north",
    x: 145,
    y: 100
  },
  {
    id: 6,
    name: "Sicily",
    region: "south",
    x: 205,
    y: 335
  },
  {
    id: 7,
    name: "Lake Como",
    region: "north",
    x: 135,
    y: 85
  },
  {
    id: 8,
    name: "Cinque Terre",
    region: "north",
    x: 130,
    y: 130
  },
  {
    id: 9,
    name: "Naples",
    region: "south",
    x: 225,
    y: 210
  }
];