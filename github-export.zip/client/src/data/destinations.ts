export interface Destination {
  id: number;
  title: string;
  titleEn: string;
  titleSl: string;
  slug: string;
  region: string; // Region ID (valle-d-aosta, piemonte, etc.)
  macroRegion: "north" | "central" | "south"; // Macro region
  location: string;
  description: string;
  descriptionEn: string;
  descriptionSl: string;
  imageUrl: string;
  rating: number;
  lat: number;
  lng: number;
  x: number; // X coordinate on the map
  y: number; // Y coordinate on the map
  features: {
    localFood: {
      title: string;
      titleEn: string;
      titleSl: string;
      description: string;
      descriptionEn: string;
      descriptionSl: string;
    };
    localDrink: {
      title: string;
      titleEn: string;
      titleSl: string;
      description: string;
      descriptionEn: string;
      descriptionSl: string;
    };
    accommodation: {
      title: string;
      titleEn: string;
      titleSl: string;
      description: string;
      descriptionEn: string;
      descriptionSl: string;
    };
    mustSee: {
      title: string;
      titleEn: string;
      titleSl: string;
      description: string;
      descriptionEn: string;
      descriptionSl: string;
    };
    bestExperience: {
      title: string;
      titleEn: string;
      titleSl: string;
      description: string;
      descriptionEn: string;
      descriptionSl: string;
    };
  };
}

export const destinations: Destination[] = [
  // NORTHERN ITALY
  {
    id: 1,
    title: "Venice",
    titleEn: "Venice",
    titleSl: "Benetke",
    slug: "venice",
    region: "veneto",
    macroRegion: "north",
    location: "Veneto",
    description: "A city built on water, known for its canals, gondolas, and unique architecture.",
    descriptionEn: "A city built on water, known for its canals, gondolas, and unique architecture.",
    descriptionSl: "Mesto, zgrajeno na vodi, znano po svojih kanalih, gondolah in edinstveni arhitekturi.",
    imageUrl: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1530&q=80",
    rating: 4.8,
    lat: 45.4408,
    lng: 12.3155,
    x: 145,
    y: 115,
    features: {
      localFood: {
        title: "Risotto al nero di seppia",
        titleEn: "Squid Ink Risotto",
        titleSl: "Rižota s sipino črno barvo",
        description: "Black risotto made with cuttlefish ink, a Venetian specialty.",
        descriptionEn: "Black risotto made with cuttlefish ink, a Venetian specialty.",
        descriptionSl: "Črna rižota, narejena s sipino črno barvo, beneška specialiteta."
      },
      localDrink: {
        title: "Spritz",
        titleEn: "Spritz",
        titleSl: "Spritz",
        description: "A wine-based cocktail with Aperol or Campari, popular in Venice.",
        descriptionEn: "A wine-based cocktail with Aperol or Campari, popular in Venice.",
        descriptionSl: "Koktajl na osnovi vina z Aperolom ali Camparijem, priljubljen v Benetkah."
      },
      accommodation: {
        title: "Canal-side Hotels",
        titleEn: "Canal-side Hotels",
        titleSl: "Hoteli ob kanalu",
        description: "Stay in historic buildings overlooking the scenic canals.",
        descriptionEn: "Stay in historic buildings overlooking the scenic canals.",
        descriptionSl: "Bivanje v zgodovinskih stavbah s pogledom na slikovite kanale."
      },
      mustSee: {
        title: "St. Mark's Square",
        titleEn: "St. Mark's Square",
        titleSl: "Trg svetega Marka",
        description: "The main public square with stunning basilica and bell tower.",
        descriptionEn: "The main public square with stunning basilica and bell tower.",
        descriptionSl: "Glavni javni trg z osupljivo baziliko in zvonikom."
      },
      bestExperience: {
        title: "Gondola Ride",
        titleEn: "Gondola Ride",
        titleSl: "Vožnja z gondolo",
        description: "Experience Venice from the water on a traditional gondola.",
        descriptionEn: "Experience Venice from the water on a traditional gondola.",
        descriptionSl: "Doživite Benetke z vode na tradicionalni gondoli."
      }
    }
  },
  {
    id: 2,
    title: "Milan",
    titleEn: "Milan",
    titleSl: "Milano",
    slug: "milan",
    region: "lombardia",
    macroRegion: "north",
    location: "Lombardy",
    description: "Italy's design and fashion capital with modern architecture and historic sites.",
    descriptionEn: "Italy's design and fashion capital with modern architecture and historic sites.",
    descriptionSl: "Italijanska prestolnica oblikovanja in mode s sodobno arhitekturo in zgodovinskimi znamenitostmi.",
    imageUrl: "https://images.unsplash.com/photo-1512248270121-c6e9b931ae3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.5,
    lat: 45.4642,
    lng: 9.1900,
    x: 95,
    y: 105,
    features: {
      localFood: {
        title: "Risotto alla Milanese",
        titleEn: "Milanese Risotto",
        titleSl: "Milanska rižota",
        description: "Saffron-infused risotto, traditionally served with osso buco.",
        descriptionEn: "Saffron-infused risotto, traditionally served with osso buco.",
        descriptionSl: "Rižota z žafranom, tradicionalno postrežena z osso buco."
      },
      localDrink: {
        title: "Campari",
        titleEn: "Campari",
        titleSl: "Campari",
        description: "The iconic red bitter aperitif created in Milan in 1860.",
        descriptionEn: "The iconic red bitter aperitif created in Milan in 1860.",
        descriptionSl: "Ikonični rdeči grenki aperitiv, ustvarjen v Milanu leta 1860."
      },
      accommodation: {
        title: "Design Hotels",
        titleEn: "Design Hotels",
        titleSl: "Dizajnerski hoteli",
        description: "Stay in stylish accommodations showcasing Italian design.",
        descriptionEn: "Stay in stylish accommodations showcasing Italian design.",
        descriptionSl: "Bivanje v elegantnih nastanitvah, ki predstavljajo italijanski dizajn."
      },
      mustSee: {
        title: "Milan Cathedral (Duomo)",
        titleEn: "Milan Cathedral (Duomo)",
        titleSl: "Milanska katedrala (Duomo)",
        description: "The magnificent Gothic cathedral with rooftop terraces.",
        descriptionEn: "The magnificent Gothic cathedral with rooftop terraces.",
        descriptionSl: "Veličastna gotska katedrala s terasami na strehi."
      },
      bestExperience: {
        title: "Fashion District Shopping",
        titleEn: "Fashion District Shopping",
        titleSl: "Nakupovanje v modni četrti",
        description: "Explore the Quadrilatero della Moda for luxury shopping.",
        descriptionEn: "Explore the Quadrilatero della Moda for luxury shopping.",
        descriptionSl: "Raziskovanje Quadrilatero della Moda za luksuzno nakupovanje."
      }
    }
  },
  {
    id: 3,
    title: "Lake Como",
    titleEn: "Lake Como",
    titleSl: "Komsko jezero",
    slug: "lake-como",
    region: "lombardia",
    macroRegion: "north",
    location: "Lombardy",
    description: "A stunning alpine lake surrounded by mountains and elegant villas.",
    descriptionEn: "A stunning alpine lake surrounded by mountains and elegant villas.",
    descriptionSl: "Osupljivo alpsko jezero, obdano z gorami in elegantnimi vilami.",
    imageUrl: "https://images.unsplash.com/photo-1583426446105-a664f6c2d008?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.7,
    lat: 45.9584,
    lng: 9.2645,
    x: 105,
    y: 95,
    features: {
      localFood: {
        title: "Missoltini",
        titleEn: "Missoltini",
        titleSl: "Missoltini",
        description: "Sun-dried lake fish, a traditional delicacy of Lake Como.",
        descriptionEn: "Sun-dried lake fish, a traditional delicacy of Lake Como.",
        descriptionSl: "Na soncu posušene jezerske ribe, tradicionalna specialiteta Komskega jezera."
      },
      localDrink: {
        title: "Vino della Casa",
        titleEn: "House Wine",
        titleSl: "Hišno vino",
        description: "Local wines from the surrounding hillsides.",
        descriptionEn: "Local wines from the surrounding hillsides.",
        descriptionSl: "Lokalna vina z okoliških gričev."
      },
      accommodation: {
        title: "Lakeside Villas",
        titleEn: "Lakeside Villas",
        titleSl: "Vile ob jezeru",
        description: "Stay in historic villas with views of the lake and mountains.",
        descriptionEn: "Stay in historic villas with views of the lake and mountains.",
        descriptionSl: "Bivanje v zgodovinskih vilah s pogledi na jezero in gore."
      },
      mustSee: {
        title: "Villa del Balbianello",
        titleEn: "Villa del Balbianello",
        titleSl: "Vila del Balbianello",
        description: "Elegant villa with terraced gardens featured in many films.",
        descriptionEn: "Elegant villa with terraced gardens featured in many films.",
        descriptionSl: "Elegantna vila s terasastimi vrtovi, ki se pojavlja v številnih filmih."
      },
      bestExperience: {
        title: "Lake Cruise",
        titleEn: "Lake Cruise",
        titleSl: "Križarjenje po jezeru",
        description: "Take a boat tour to see the beautiful lakeside towns and villas.",
        descriptionEn: "Take a boat tour to see the beautiful lakeside towns and villas.",
        descriptionSl: "Vzemite čolnarski izlet, da si ogledate lepa objezerska mesta in vile."
      }
    }
  },
  
  // CENTRAL ITALY
  {
    id: 4,
    title: "Florence",
    titleEn: "Florence",
    titleSl: "Firence",
    slug: "florence",
    region: "toscana",
    macroRegion: "central",
    location: "Tuscany",
    description: "The birthplace of the Renaissance with world-class art and architecture.",
    descriptionEn: "The birthplace of the Renaissance with world-class art and architecture.",
    descriptionSl: "Rojstni kraj renesanse s svetovno znano umetnostjo in arhitekturo.",
    imageUrl: "https://images.unsplash.com/photo-1476362555312-ab9e108a0b7e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.9,
    lat: 43.7696,
    lng: 11.2558,
    x: 120,
    y: 160,
    features: {
      localFood: {
        title: "Bistecca alla Fiorentina",
        titleEn: "Florentine Steak",
        titleSl: "Florentinski zrezek",
        description: "Thick T-bone steak grilled over chestnut wood embers.",
        descriptionEn: "Thick T-bone steak grilled over chestnut wood embers.",
        descriptionSl: "Debel zrezek T-bone, pečen na žaru nad žerjavico iz kostanjevega lesa."
      },
      localDrink: {
        title: "Chianti Classico",
        titleEn: "Chianti Classico",
        titleSl: "Chianti Classico",
        description: "The famous red wine from the surrounding Tuscan hills.",
        descriptionEn: "The famous red wine from the surrounding Tuscan hills.",
        descriptionSl: "Slavno rdeče vino z okoliških toskanskih gričev."
      },
      accommodation: {
        title: "Historic Palazzos",
        titleEn: "Historic Palazzos",
        titleSl: "Zgodovinske palače",
        description: "Stay in converted historic buildings in the city center.",
        descriptionEn: "Stay in converted historic buildings in the city center.",
        descriptionSl: "Bivanje v prenovljenih zgodovinskih stavbah v središču mesta."
      },
      mustSee: {
        title: "Uffizi Gallery",
        titleEn: "Uffizi Gallery",
        titleSl: "Galerija Uffizi",
        description: "One of the world's greatest art museums with Renaissance masterpieces.",
        descriptionEn: "One of the world's greatest art museums with Renaissance masterpieces.",
        descriptionSl: "Eden največjih umetniških muzejev na svetu z renesančnimi mojstrovinami."
      },
      bestExperience: {
        title: "Sunset at Piazzale Michelangelo",
        titleEn: "Sunset at Piazzale Michelangelo",
        titleSl: "Sončni zahod na Piazzale Michelangelo",
        description: "Watch the sun set over Florence from this panoramic viewpoint.",
        descriptionEn: "Watch the sun set over Florence from this panoramic viewpoint.",
        descriptionSl: "Opazujte sončni zahod nad Firencami s te panoramske razgledne točke."
      }
    }
  },
  {
    id: 5,
    title: "Rome",
    titleEn: "Rome",
    titleSl: "Rim",
    slug: "rome",
    region: "lazio",
    macroRegion: "central",
    location: "Lazio",
    description: "The Eternal City with ancient ruins, Vatican City, and vibrant street life.",
    descriptionEn: "The Eternal City with ancient ruins, Vatican City, and vibrant street life.",
    descriptionSl: "Večno mesto z antičnimi ruševinami, Vatikanom in živahnim uličnim življenjem.",
    imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1596&q=80",
    rating: 4.8,
    lat: 41.9028,
    lng: 12.4964,
    x: 140,
    y: 215,
    features: {
      localFood: {
        title: "Cacio e Pepe",
        titleEn: "Cacio e Pepe",
        titleSl: "Cacio e Pepe",
        description: "Simple yet delicious pasta with cheese and black pepper.",
        descriptionEn: "Simple yet delicious pasta with cheese and black pepper.",
        descriptionSl: "Preprosta, a okusna testenina s sirom in črnim poprom."
      },
      localDrink: {
        title: "Frascati",
        titleEn: "Frascati",
        titleSl: "Frascati",
        description: "White wine from the nearby hills, a traditional Roman choice.",
        descriptionEn: "White wine from the nearby hills, a traditional Roman choice.",
        descriptionSl: "Belo vino z bližnjih gričev, tradicionalna rimska izbira."
      },
      accommodation: {
        title: "Boutique Hotels in Centro Storico",
        titleEn: "Boutique Hotels in Centro Storico",
        titleSl: "Butični hoteli v Centro Storico",
        description: "Stay in charming hotels in the historic center.",
        descriptionEn: "Stay in charming hotels in the historic center.",
        descriptionSl: "Bivanje v očarljivih hotelih v zgodovinskem središču."
      },
      mustSee: {
        title: "Colosseum",
        titleEn: "Colosseum",
        titleSl: "Kolosej",
        description: "The iconic amphitheater of ancient Rome.",
        descriptionEn: "The iconic amphitheater of ancient Rome.",
        descriptionSl: "Ikonični amfiteater antičnega Rima."
      },
      bestExperience: {
        title: "Evening Passeggiata",
        titleEn: "Evening Passeggiata",
        titleSl: "Večerni sprehod",
        description: "Join locals for the traditional evening stroll through piazzas.",
        descriptionEn: "Join locals for the traditional evening stroll through piazzas.",
        descriptionSl: "Pridružite se domačinom pri tradicionalnem večernem sprehodu po trgih."
      }
    }
  },
  
  // SOUTHERN ITALY
  {
    id: 6,
    title: "Amalfi Coast",
    titleEn: "Amalfi Coast",
    titleSl: "Amalfijska obala",
    slug: "amalfi-coast",
    region: "campania",
    macroRegion: "south",
    location: "Campania",
    description: "Dramatic coastline with colorful cliffside villages and crystal waters.",
    descriptionEn: "Dramatic coastline with colorful cliffside villages and crystal waters.",
    descriptionSl: "Dramatična obala z barvitimi vasmi na pečinah in kristalnimi vodami.",
    imageUrl: "https://images.unsplash.com/photo-1612698093158-e07ac200d44e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.9,
    lat: 40.6340,
    lng: 14.6027,
    x: 180,
    y: 235,
    features: {
      localFood: {
        title: "Scialatielli ai frutti di mare",
        titleEn: "Seafood Pasta",
        titleSl: "Testenine z morskimi sadeži",
        description: "Fresh local pasta with seafood from the Mediterranean.",
        descriptionEn: "Fresh local pasta with seafood from the Mediterranean.",
        descriptionSl: "Sveže lokalne testenine z morskimi sadeži iz Sredozemlja."
      },
      localDrink: {
        title: "Limoncello",
        titleEn: "Limoncello",
        titleSl: "Limoncello",
        description: "Sweet lemon liqueur made from the region's famous lemons.",
        descriptionEn: "Sweet lemon liqueur made from the region's famous lemons.",
        descriptionSl: "Sladek limonin liker, narejen iz znamenitih limon te regije."
      },
      accommodation: {
        title: "Cliffside Hotels",
        titleEn: "Cliffside Hotels",
        titleSl: "Hoteli na pečinah",
        description: "Stay in rooms with breathtaking views of the Mediterranean.",
        descriptionEn: "Stay in rooms with breathtaking views of the Mediterranean.",
        descriptionSl: "Bivanje v sobah z osupljivimi razgledi na Sredozemlje."
      },
      mustSee: {
        title: "Positano",
        titleEn: "Positano",
        titleSl: "Positano",
        description: "The most iconic colorful village cascading down to the sea.",
        descriptionEn: "The most iconic colorful village cascading down to the sea.",
        descriptionSl: "Najbolj ikonična barvita vas, ki se spušča proti morju."
      },
      bestExperience: {
        title: "Boat Trip",
        titleEn: "Boat Trip",
        titleSl: "Izlet s čolnom",
        description: "See the coast from the water for the most breathtaking views.",
        descriptionEn: "See the coast from the water for the most breathtaking views.",
        descriptionSl: "Oglejte si obalo z vode za najbolj osupljive razglede."
      }
    }
  },
  {
    id: 7,
    title: "Matera",
    titleEn: "Matera",
    titleSl: "Matera",
    slug: "matera",
    region: "basilicata",
    macroRegion: "south",
    location: "Basilicata",
    description: "Ancient city with cave dwellings (Sassi) and unique stone architecture.",
    descriptionEn: "Ancient city with cave dwellings (Sassi) and unique stone architecture.",
    descriptionSl: "Starodavno mesto z jamskimi bivališči (Sassi) in edinstveno kamnito arhitekturo.",
    imageUrl: "https://images.unsplash.com/photo-1560860446-c821e910a0a7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.7,
    lat: 40.6667,
    lng: 16.6000,
    x: 190,
    y: 270,
    features: {
      localFood: {
        title: "Crapiata",
        titleEn: "Crapiata",
        titleSl: "Crapiata",
        description: "Traditional legume and grain soup with ancient origins.",
        descriptionEn: "Traditional legume and grain soup with ancient origins.",
        descriptionSl: "Tradicionalna juha iz stročnic in žit s starodavnim izvorom."
      },
      localDrink: {
        title: "Aglianico del Vulture",
        titleEn: "Aglianico del Vulture",
        titleSl: "Aglianico del Vulture",
        description: "Rich red wine from the Basilicata region.",
        descriptionEn: "Rich red wine from the Basilicata region.",
        descriptionSl: "Bogato rdeče vino iz regije Basilicata."
      },
      accommodation: {
        title: "Cave Hotels",
        titleEn: "Cave Hotels",
        titleSl: "Jamski hoteli",
        description: "Stay in unique hotels carved into the ancient stone.",
        descriptionEn: "Stay in unique hotels carved into the ancient stone.",
        descriptionSl: "Bivanje v edinstvenih hotelih, izklesanih v starodavni kamen."
      },
      mustSee: {
        title: "Sassi di Matera",
        titleEn: "Sassi di Matera",
        titleSl: "Sassi di Matera",
        description: "The ancient cave dwellings that form the historic center.",
        descriptionEn: "The ancient cave dwellings that form the historic center.",
        descriptionSl: "Starodavna jamska bivališča, ki tvorijo zgodovinsko središče."
      },
      bestExperience: {
        title: "Sunset Viewpoints",
        titleEn: "Sunset Viewpoints",
        titleSl: "Razgledne točke za sončni zahod",
        description: "Watch the golden light illuminate the stone city at sunset.",
        descriptionEn: "Watch the golden light illuminate the stone city at sunset.",
        descriptionSl: "Opazujte, kako zlata svetloba osvetli kamnito mesto ob sončnem zahodu."
      }
    }
  },
  {
    id: 8,
    title: "Palermo",
    titleEn: "Palermo",
    titleSl: "Palermo",
    slug: "palermo",
    region: "sicilia",
    macroRegion: "south",
    location: "Sicily",
    description: "Sicily's vibrant capital with Arab-Norman architecture and street food.",
    descriptionEn: "Sicily's vibrant capital with Arab-Norman architecture and street food.",
    descriptionSl: "Živahna prestolnica Sicilije z arabsko-normansko arhitekturo in ulično hrano.",
    imageUrl: "https://images.unsplash.com/photo-1539037116277-4db20889f98d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    rating: 4.6,
    lat: 38.1157,
    lng: 13.3615,
    x: 160,
    y: 360,
    features: {
      localFood: {
        title: "Arancini",
        titleEn: "Arancini",
        titleSl: "Arancini",
        description: "Fried rice balls stuffed with ragù, peas, and cheese.",
        descriptionEn: "Fried rice balls stuffed with ragù, peas, and cheese.",
        descriptionSl: "Ocvrte riževe kroglice, polnjene z ragùjem, grahom in sirom."
      },
      localDrink: {
        title: "Marsala",
        titleEn: "Marsala",
        titleSl: "Marsala",
        description: "Fortified wine produced in the region since the 1700s.",
        descriptionEn: "Fortified wine produced in the region since the 1700s.",
        descriptionSl: "Utrjeno vino, ki se v regiji proizvaja od 18. stoletja."
      },
      accommodation: {
        title: "Historic Palaces",
        titleEn: "Historic Palaces",
        titleSl: "Zgodovinske palače",
        description: "Stay in converted palaces with Sicilian baroque details.",
        descriptionEn: "Stay in converted palaces with Sicilian baroque details.",
        descriptionSl: "Bivanje v prenovljenih palačah s sicilijanskimi baročnimi detajli."
      },
      mustSee: {
        title: "Cattedrale di Palermo",
        titleEn: "Palermo Cathedral",
        titleSl: "Palermska katedrala",
        description: "Magnificent cathedral blending multiple architectural styles.",
        descriptionEn: "Magnificent cathedral blending multiple architectural styles.",
        descriptionSl: "Veličastna katedrala, ki združuje več arhitekturnih slogov."
      },
      bestExperience: {
        title: "Street Food Tour",
        titleEn: "Street Food Tour",
        titleSl: "Tura ulične hrane",
        description: "Explore the markets and try Palermo's famous street foods.",
        descriptionEn: "Explore the markets and try Palermo's famous street foods.",
        descriptionSl: "Raziščite tržnice in poskusite znamenito palermsko ulično hrano."
      }
    }
  }
];

// Filter destinations by region
export function getDestinationsByRegion(regionId: string) {
  return destinations.filter(dest => dest.region === regionId);
}

// Filter destinations by macro region (north, central, south)
export function getDestinationsByMacroRegion(macroRegion: string) {
  return destinations.filter(dest => dest.macroRegion === macroRegion);
}

// Get a specific destination by ID
export function getDestinationById(id: number) {
  return destinations.find(dest => dest.id === id);
}

// Get a specific destination by slug
export function getDestinationBySlug(slug: string) {
  return destinations.find(dest => dest.slug === slug);
}

// Get featured destinations (top rated)
export function getFeaturedDestinations(limit = 4) {
  return [...destinations]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit);
}