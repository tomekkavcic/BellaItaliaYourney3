import { useTranslation } from 'react-i18next';

export interface Region {
  id: string;
  name: string;
  nameEn: string;
  nameSl: string;
  macro: "north" | "central" | "south";
  description: string;
  descriptionEn: string;
  descriptionSl: string;
  capital: string;
  population: number;
  area: number;
  path: string;
  center: [number, number]; // [x, y] coordinates for labels and tooltips
  color: string;
}

// These are simplified SVG paths - in a real implementation, you would use more detailed paths
export const italyRegions: Region[] = [
  // Northern Italy
  {
    id: "valle-d-aosta",
    name: "Valle d'Aosta",
    nameEn: "Aosta Valley",
    nameSl: "Dolina Aoste",
    macro: "north",
    description: "Italy's smallest region located in the Alps, known for mountains and ski resorts.",
    descriptionEn: "Italy's smallest region located in the Alps, known for mountains and ski resorts.",
    descriptionSl: "Najmanjša italijanska regija v Alpah, znana po gorah in smučiščih.",
    capital: "Aosta",
    population: 125034,
    area: 3263,
    path: "M50,80 L40,90 L45,100 L60,105 L70,95 L65,80 Z",
    center: [55, 90],
    color: "#D98F6A"
  },
  {
    id: "piemonte",
    name: "Piemonte",
    nameEn: "Piedmont",
    nameSl: "Piemont",
    macro: "north",
    description: "Region of mountains and hills known for fine wines and truffles.",
    descriptionEn: "Region of mountains and hills known for fine wines and truffles.",
    descriptionSl: "Regija gora in gričev, znana po finih vinih in tartufih.",
    capital: "Turin",
    population: 4341375,
    area: 25402,
    path: "M50,80 L65,80 L70,95 L80,105 L75,120 L85,135 L80,150 L65,150 L55,135 L45,120 L40,90 Z",
    center: [60, 110],
    color: "#D98F6A"
  },
  {
    id: "liguria",
    name: "Liguria",
    nameEn: "Liguria",
    nameSl: "Ligurija",
    macro: "north",
    description: "Coastal region with beautiful villages, home to the Italian Riviera.",
    descriptionEn: "Coastal region with beautiful villages, home to the Italian Riviera.",
    descriptionSl: "Obalna regija z lepimi vasmi, dom italijanske riviere.",
    capital: "Genoa",
    population: 1543127,
    area: 5422,
    path: "M65,150 L80,150 L85,135 L100,140 L110,150 L100,160 L80,165 L65,160 Z",
    center: [85, 150],
    color: "#D98F6A"
  },
  {
    id: "lombardia",
    name: "Lombardia",
    nameEn: "Lombardy",
    nameSl: "Lombardija",
    macro: "north",
    description: "Italy's most populous region, economic powerhouse with Milan as its capital.",
    descriptionEn: "Italy's most populous region, economic powerhouse with Milan as its capital.",
    descriptionSl: "Najbolj poseljena italijanska regija, gospodarsko središče z Milanom kot glavnim mestom.",
    capital: "Milan",
    population: 10027602,
    area: 23844,
    path: "M70,95 L60,105 L80,105 L90,95 L105,90 L120,95 L125,110 L120,125 L100,140 L85,135 L75,120 L80,105 Z",
    center: [95, 110],
    color: "#D98F6A"
  },
  {
    id: "trentino-alto-adige",
    name: "Trentino-Alto Adige",
    nameEn: "Trentino-South Tyrol",
    nameSl: "Trentinsko-Južna Tirolska",
    macro: "north",
    description: "Alpine region with strong Austrian influences and spectacular Dolomites mountains.",
    descriptionEn: "Alpine region with strong Austrian influences and spectacular Dolomites mountains.",
    descriptionSl: "Alpska regija z močnimi avstrijskimi vplivi in spektakularnimi Dolomiti.",
    capital: "Trento",
    population: 1078069,
    area: 13607,
    path: "M120,80 L130,70 L145,75 L155,85 L150,100 L130,110 L120,95 L105,90 L110,80 Z",
    center: [130, 85],
    color: "#F3DE8A"
  },
  {
    id: "veneto",
    name: "Veneto",
    nameEn: "Veneto",
    nameSl: "Benečija",
    macro: "north",
    description: "Northeastern region with Venice as its jewel, rich in art and architecture.",
    descriptionEn: "Northeastern region with Venice as its jewel, rich in art and architecture.",
    descriptionSl: "Severovzhodna regija z Benetkami kot draguljem, bogata z umetnostjo in arhitekturo.",
    capital: "Venice",
    population: 4907704,
    area: 18345,
    path: "M120,95 L130,110 L150,100 L155,85 L170,90 L185,100 L175,115 L160,120 L145,130 L130,125 L125,110 Z",
    center: [145, 105],
    color: "#F3DE8A"
  },
  {
    id: "friuli-venezia-giulia",
    name: "Friuli-Venezia Giulia",
    nameEn: "Friuli-Venezia Giulia",
    nameSl: "Furlanija-Julijska krajina",
    macro: "north",
    description: "Northeastern border region with diverse cultural influences and beautiful landscapes.",
    descriptionEn: "Northeastern border region with diverse cultural influences and beautiful landscapes.",
    descriptionSl: "Severovzhodna mejna regija z raznolikimi kulturnimi vplivi in lepimi pokrajinami.",
    capital: "Trieste",
    population: 1211357,
    area: 7924,
    path: "M155,85 L170,90 L185,100 L200,95 L195,80 L180,75 L165,80 Z",
    center: [180, 85],
    color: "#BBE1C3"
  },
  {
    id: "emilia-romagna",
    name: "Emilia-Romagna",
    nameEn: "Emilia-Romagna",
    nameSl: "Emilija-Romanja",
    macro: "north",
    description: "Food haven of Italy, home to Parmesan cheese, prosciutto, and Bolognese sauce.",
    descriptionEn: "Food haven of Italy, home to Parmesan cheese, prosciutto, and Bolognese sauce.",
    descriptionSl: "Kulinarični raj Italije, dom parmezana, pršuta in bolonjske omake.",
    capital: "Bologna",
    population: 4464119,
    area: 22453,
    path: "M100,140 L120,125 L130,125 L145,130 L160,120 L175,115 L180,130 L170,145 L155,150 L140,145 L120,155 L110,150 Z",
    center: [140, 135],
    color: "#F3DE8A"
  },
  
  // Central Italy
  {
    id: "toscana",
    name: "Toscana",
    nameEn: "Tuscany",
    nameSl: "Toskana",
    macro: "central",
    description: "Renaissance heartland with Florence as its capital, known for art, wine, and landscapes.",
    descriptionEn: "Renaissance heartland with Florence as its capital, known for art, wine, and landscapes.",
    descriptionSl: "Renesančno središče s Firencami kot glavnim mestom, znano po umetnosti, vinu in pokrajinah.",
    capital: "Florence",
    population: 3692555,
    area: 22987,
    path: "M80,165 L100,160 L110,150 L120,155 L140,145 L155,150 L160,165 L150,180 L130,195 L110,190 L95,175 L85,170 Z",
    center: [120, 165],
    color: "#BBE1C3"
  },
  {
    id: "umbria",
    name: "Umbria",
    nameEn: "Umbria",
    nameSl: "Umbrija",
    macro: "central",
    description: "Green heart of Italy with medieval hill towns and spiritual significance.",
    descriptionEn: "Green heart of Italy with medieval hill towns and spiritual significance.",
    descriptionSl: "Zeleno srce Italije s srednjeveškimi hribovskimi mesti in duhovnim pomenom.",
    capital: "Perugia",
    population: 882015,
    area: 8464,
    path: "M150,180 L160,165 L170,170 L180,180 L175,195 L160,200 L150,195 Z",
    center: [165, 185],
    color: "#BBE1C3"
  },
  {
    id: "marche",
    name: "Marche",
    nameEn: "Marche",
    nameSl: "Marke",
    macro: "central",
    description: "Eastern region with beautiful beaches and historic towns along the Adriatic coast.",
    descriptionEn: "Eastern region with beautiful beaches and historic towns along the Adriatic coast.",
    descriptionSl: "Vzhodna regija z lepimi plažami in zgodovinskimi mesti ob Jadranski obali.",
    capital: "Ancona",
    population: 1525271,
    area: 9401,
    path: "M155,150 L170,145 L180,130 L190,135 L195,150 L190,165 L180,180 L170,170 L160,165 Z",
    center: [175, 155],
    color: "#F3DE8A"
  },
  {
    id: "lazio",
    name: "Lazio",
    nameEn: "Lazio",
    nameSl: "Lacij",
    macro: "central",
    description: "Central region containing Rome, the eternal city and Italy's capital.",
    descriptionEn: "Central region containing Rome, the eternal city and Italy's capital.",
    descriptionSl: "Osrednja regija, ki vsebuje Rim, večno mesto in glavno mesto Italije.",
    capital: "Rome",
    population: 5755700,
    area: 17242,
    path: "M130,195 L150,195 L160,200 L170,210 L160,230 L145,245 L125,240 L115,220 L110,190 Z",
    center: [140, 215],
    color: "#F8C37D"
  },
  
  // Southern Italy
  {
    id: "abruzzo",
    name: "Abruzzo",
    nameEn: "Abruzzo",
    nameSl: "Abruci",
    macro: "south",
    description: "Wild mountain region with national parks and medieval hill towns.",
    descriptionEn: "Wild mountain region with national parks and medieval hill towns.",
    descriptionSl: "Divja gorska regija z nacionalnimi parki in srednjeveškimi hribovskimi mesti.",
    capital: "L'Aquila",
    population: 1293941,
    area: 10831,
    path: "M175,195 L190,165 L195,150 L210,155 L215,170 L210,185 L195,195 L185,205 L170,210 L160,200 Z",
    center: [185, 180],
    color: "#BBE1C3"
  },
  {
    id: "molise",
    name: "Molise",
    nameEn: "Molise",
    nameSl: "Molize",
    macro: "south",
    description: "One of Italy's newest and least known regions with unspoiled landscapes.",
    descriptionEn: "One of Italy's newest and least known regions with unspoiled landscapes.",
    descriptionSl: "Ena najnovejših in najmanj znanih italijanskih regij z neokrnjenimi pokrajinami.",
    capital: "Campobasso",
    population: 305617,
    area: 4461,
    path: "M195,195 L210,185 L215,170 L225,175 L230,185 L225,195 L215,200 L205,205 Z",
    center: [210, 190],
    color: "#BBE1C3"
  },
  {
    id: "campania",
    name: "Campania",
    nameEn: "Campania",
    nameSl: "Kampanija",
    macro: "south",
    description: "Southwestern region with Naples, Pompeii, and the Amalfi Coast.",
    descriptionEn: "Southwestern region with Naples, Pompeii, and the Amalfi Coast.",
    descriptionSl: "Jugozahodna regija z Neapljem, Pompeji in Amalfijsko obalo.",
    capital: "Naples",
    population: 5712143,
    area: 13671,
    path: "M145,245 L160,230 L170,210 L185,205 L205,205 L215,215 L210,230 L190,245 L175,250 L160,245 Z",
    center: [180, 225],
    color: "#BBE1C3"
  },
  {
    id: "puglia",
    name: "Puglia",
    nameEn: "Apulia",
    nameSl: "Apulija",
    macro: "south",
    description: "The heel of Italy's boot with beautiful beaches, olive groves, and unique architecture.",
    descriptionEn: "The heel of Italy's boot with beautiful beaches, olive groves, and unique architecture.",
    descriptionSl: "Peta italijanskega škornja z lepimi plažami, nasadi oljk in edinstveno arhitekturo.",
    capital: "Bari",
    population: 3953305,
    area: 19540,
    path: "M215,200 L225,195 L230,185 L245,190 L255,205 L250,225 L240,245 L225,265 L210,270 L200,255 L190,245 L210,230 L215,215 Z",
    center: [230, 230],
    color: "#BBE1C3"
  },
  {
    id: "basilicata",
    name: "Basilicata",
    nameEn: "Basilicata",
    nameSl: "Bazilikata",
    macro: "south",
    description: "Mountainous southern region with ancient towns and dramatic landscapes.",
    descriptionEn: "Mountainous southern region with ancient towns and dramatic landscapes.",
    descriptionSl: "Gorska južna regija s starodavnimi mesti in dramatičnimi pokrajinami.",
    capital: "Potenza",
    population: 562869,
    area: 10073,
    path: "M175,250 L190,245 L200,255 L210,270 L205,285 L195,290 L185,280 L180,265 Z",
    center: [190, 265],
    color: "#BBE1C3"
  },
  {
    id: "calabria",
    name: "Calabria",
    nameEn: "Calabria",
    nameSl: "Kalabrija",
    macro: "south",
    description: "The toe of Italy's boot with beautiful coastlines and spicy cuisine.",
    descriptionEn: "The toe of Italy's boot with beautiful coastlines and spicy cuisine.",
    descriptionSl: "Prst italijanskega škornja z lepimi obalami in pikantno kulinariko.",
    capital: "Catanzaro",
    population: 1894110,
    area: 15222,
    path: "M185,280 L195,290 L205,285 L210,300 L205,320 L190,335 L180,325 L175,305 L180,290 Z",
    center: [190, 310],
    color: "#BBE1C3"
  },
  
  // Islands
  {
    id: "sicilia",
    name: "Sicilia",
    nameEn: "Sicily",
    nameSl: "Sicilija",
    macro: "south",
    description: "The largest Mediterranean island with rich history, cuisine, and Mount Etna.",
    descriptionEn: "The largest Mediterranean island with rich history, cuisine, and Mount Etna.",
    descriptionSl: "Največji sredozemski otok z bogato zgodovino, kulinariko in goro Etna.",
    capital: "Palermo",
    population: 4875290,
    area: 25832,
    path: "M140,350 L160,340 L185,345 L210,360 L205,380 L180,390 L155,385 L140,370 Z",
    center: [175, 365],
    color: "#F8C37D"
  },
  {
    id: "sardegna",
    name: "Sardegna",
    nameEn: "Sardinia",
    nameSl: "Sardinija",
    macro: "south",
    description: "Large island with pristine beaches, ancient nuragic ruins, and unique traditions.",
    descriptionEn: "Large island with pristine beaches, ancient nuragic ruins, and unique traditions.",
    descriptionSl: "Velik otok z nedotaknjenimi plažami, starodavnimi nuragičnimi ruševinami in edinstvenimi tradicijami.",
    capital: "Cagliari",
    population: 1611261,
    area: 24100,
    path: "M50,250 L70,240 L90,245 L100,265 L90,290 L70,295 L50,285 L40,270 Z",
    center: [70, 265],
    color: "#BBE1C3"
  }
];

// Group regions by macro-region (North, Central, South)
export function getRegionsByMacro() {
  const northRegions = italyRegions.filter(region => region.macro === "north");
  const centralRegions = italyRegions.filter(region => region.macro === "central");
  const southRegions = italyRegions.filter(region => region.macro === "south");
  
  return {
    north: northRegions,
    central: centralRegions,
    south: southRegions
  };
}

// Get a specific region by ID
export function getRegionById(id: string): Region | undefined {
  return italyRegions.find(region => region.id === id);
}

// Get the macro-region (North, Central, South) for a specific region ID
export function getMacroRegionForRegion(regionId: string): string {
  const region = getRegionById(regionId);
  return region ? region.macro : "";
}

// Custom hook to get region names in the current language
export function useRegionNames() {
  const { i18n } = useTranslation();
  
  return italyRegions.map(region => ({
    id: region.id,
    name: i18n.language === 'sl' ? region.nameSl : region.nameEn,
    macro: region.macro
  }));
}