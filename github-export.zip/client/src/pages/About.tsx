import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Newsletter from "@/components/Newsletter";

export default function About() {
  const { t } = useTranslation();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-28 pb-12">
        {/* Hero Section - white background */}
        <section className="bg-white py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto text-center">
              <h1 className="font-['Cinzel'] text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-[#009246]">
                {t('about.title')}
              </h1>
              <p className="text-lg md:text-xl mb-8 text-gray-700 max-w-3xl mx-auto">
                {t('about.subtitle')}
              </p>
            </div>
            <div className="aspect-video max-w-4xl mx-auto rounded-lg overflow-hidden shadow-lg mt-8 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-1">
              <div className="w-full h-full bg-[url('/images/italian-countryside.jpg')] bg-cover bg-center rounded-lg"></div>
            </div>
          </div>
        </section>

        {/* Our Story Section - mild green background */}
        <section className="bg-[#009246]/10 py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-8 md:p-12">
                <h2 className="font-['Cinzel'] text-3xl font-bold mb-6 text-gray-800">{t('about.ourStory')}</h2>
                <div className="prose prose-lg max-w-none text-gray-700">
                  <p>
                    What began as a simple vacation to Rome in 2018 quickly transformed into a love affair with Italy that has spanned multiple trips, countless plates of pasta, and an ever-growing appreciation for the rich culture and history that makes Italy so special.
                  </p>
                  <p>
                    We are Marco and Sofia, a couple with a shared passion for authentic travel experiences. After our first trip together to Italy, we found ourselves constantly planning our return, eager to explore more regions, discover hidden gems, and immerse ourselves deeper into the Italian way of life.
                  </p>
                  <p>
                    In 2020, during a time when travel was restricted, we decided to create this website as a way to document our previous adventures and plan future ones. What started as a personal travel journal has evolved into a resource we hope helps others discover the beauty of Italy beyond the typical tourist experience.
                  </p>
                  <p>
                    Today, we continue to explore Italy region by region, sharing our experiences, recommendations, and the lessons we've learned along the way. From navigating the winding roads of Tuscany to finding the perfect gelato in Sicily, our journey continues with each visit.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Approach Section - mild red background */}
        <section className="bg-[#CE2B37]/10 py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="font-['Cinzel'] text-3xl font-bold mb-8 text-center text-gray-800">{t('about.approachTitle')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-[#009246]/10 rounded-full flex items-center justify-center">
                    <span className="text-[#009246] text-2xl">🏠</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{t('about.localExperience')}</h3>
                  <p className="text-gray-700">
                    {t('about.localExperienceText')}
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-white rounded-full flex items-center justify-center">
                    <span className="text-gray-800 text-2xl">🗺️</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{t('about.slowTravel')}</h3>
                  <p className="text-gray-700">
                    {t('about.slowTravelText')}
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-[#CE2B37]/10 rounded-full flex items-center justify-center">
                    <span className="text-[#CE2B37] text-2xl">👨‍🍳</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{t('about.culinaryFocus')}</h3>
                  <p className="text-gray-700">
                    {t('about.culinaryFocusText')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our 5 Pillars Section - white background */}
        <section className="bg-white py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-8 md:p-12">
                <h2 className="font-['Cinzel'] text-3xl font-bold mb-6 text-center text-gray-800">{t('about.pillarsTitle')}</h2>
                <p className="text-center text-gray-700 mb-8">{t('about.pillarsDescription')}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="col-span-1 md:col-span-3 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-0.5 rounded-lg">
                    <div className="bg-white p-6 rounded-lg h-full">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-[#009246]/10 rounded-full flex items-center justify-center mr-4">
                          <span className="text-[#009246] text-2xl">🍷</span>
                        </div>
                        <h3 className="text-xl font-semibold">Local Drink</h3>
                      </div>
                      <p className="text-gray-700">
                        Each Italian region boasts unique wines and spirits that tell a story of local tradition. We guide you to the perfect Barolo in Piedmont, the refreshing Aperol Spritz in Veneto, and family-run wineries throughout the country where you can experience centuries of craftsmanship.
                      </p>
                    </div>
                  </div>
                  
                  <div className="col-span-1 md:col-span-3 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-0.5 rounded-lg">
                    <div className="bg-white p-6 rounded-lg h-full">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mr-4 border border-gray-200">
                          <span className="text-gray-800 text-2xl">🍝</span>
                        </div>
                        <h3 className="text-xl font-semibold">Local Food</h3>
                      </div>
                      <p className="text-gray-700">
                        Italian cuisine varies dramatically from region to region. We dive deep into traditional dishes you might miss on typical tourist menus, from the hearty ossobuco of Milan to the delicate seafood of Sicily. We help you understand what's truly local and where to find it.
                      </p>
                    </div>
                  </div>
                  
                  <div className="col-span-1 md:col-span-3 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-0.5 rounded-lg">
                    <div className="bg-white p-6 rounded-lg h-full">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-[#CE2B37]/10 rounded-full flex items-center justify-center mr-4">
                          <span className="text-[#CE2B37] text-2xl">🏨</span>
                        </div>
                        <h3 className="text-xl font-semibold">Accommodation</h3>
                      </div>
                      <p className="text-gray-700">
                        Where you stay shapes your experience. We highlight unique accommodations that offer authentic Italian hospitality, from family-run agriturismi in Tuscany to historic apartments in Venice. We focus on places that connect you to the local culture.
                      </p>
                    </div>
                  </div>
                  
                  <div className="col-span-1 md:col-span-3 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-0.5 rounded-lg">
                    <div className="bg-white p-6 rounded-lg h-full">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mr-4 border border-gray-200">
                          <span className="text-gray-800 text-2xl">🏛️</span>
                        </div>
                        <h3 className="text-xl font-semibold">Must-See Attractions</h3>
                      </div>
                      <p className="text-gray-700">
                        Beyond the famous landmarks, we uncover hidden gems and lesser-known spots that capture the essence of each region. Our recommendations include off-the-beaten-path museums, viewpoints, historic sites, and natural wonders that shouldn't be missed.
                      </p>
                    </div>
                  </div>
                  
                  <div className="col-span-1 md:col-span-3 bg-gradient-to-r from-[#009246] via-white to-[#CE2B37] p-0.5 rounded-lg">
                    <div className="bg-white p-6 rounded-lg h-full">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-[#009246]/10 rounded-full flex items-center justify-center mr-4">
                          <span className="text-[#009246] text-2xl">✨</span>
                        </div>
                        <h3 className="text-xl font-semibold">Best Experience</h3>
                      </div>
                      <p className="text-gray-700">
                        In each location, we highlight one standout experience that captures its true spirit—whether it's a cooking class with a local nonna, a sunset boat ride along the Amalfi Coast, or a private tour of an ancient olive grove. These moments often become the memories that last a lifetime.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 text-center">
                  <p className="italic text-gray-800">
                    {t('about.quote')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section - mild green background */}
        <section className="bg-[#009246]/10 py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto bg-gradient-to-r from-[#009246] to-[#009246]/80 rounded-lg shadow-lg overflow-hidden">
              <div className="p-8 md:p-12 text-white">
                <h2 className="font-['Cinzel'] text-3xl font-bold mb-6">{t('footer.connect')}</h2>
                <p className="mb-8 text-white/90 text-lg">
                  {t('contact.subtitle')}
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/contact">
                    <Button className="bg-white text-[#009246] hover:bg-gray-100">
                      {t('contact.title')}
                    </Button>
                  </Link>
                  <Link href="/blog">
                    <Button className="bg-[#CE2B37] hover:bg-[#CE2B37]/90">
                      {t('blog.readArticle')}
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
}