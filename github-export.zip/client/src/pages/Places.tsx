import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Newsletter from "@/components/Newsletter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import ItalyMap from "../components/ItalyMap";
import { mapPlaces } from "../data/mapData";
import { useTranslation } from "react-i18next";

// Region categories
const getRegions = (t: any) => [
  {
    id: "all",
    label: t('regions.all')
  },
  {
    id: "north",
    label: t('regions.north')
  },
  {
    id: "central",
    label: t('regions.central')
  },
  {
    id: "south",
    label: t('regions.south')
  }
];

// Italian map regions with their positions on the map (based on the actual regions image)
const italianRegions = [
  {
    name: "Piemonte",
    area: "north",
    position: { top: '20%', left: '10%', width: '14%', height: '14%' }
  },
  {
    name: "Valle d'Aosta",
    area: "north",
    position: { top: '8%', left: '7%', width: '7%', height: '7%' }
  },
  {
    name: "Lombardia",
    area: "north",
    position: { top: '12%', left: '22%', width: '15%', height: '12%' }
  },
  {
    name: "Trentino-Alto Adige",
    area: "north",
    children: [
      { name: "Bolzano", position: { top: '2%', left: '32%', width: '8%', height: '8%' } },
      { name: "Trento", position: { top: '10%', left: '32%', width: '8%', height: '8%' } }
    ],
    position: { top: '3%', left: '32%', width: '10%', height: '14%' }
  },
  {
    name: "Veneto",
    area: "north",
    position: { top: '14%', left: '42%', width: '14%', height: '11%' }
  },
  {
    name: "Friuli-Venezia Giulia",
    area: "north",
    position: { top: '7%', left: '54%', width: '12%', height: '10%' }
  },
  {
    name: "Liguria",
    area: "north",
    position: { top: '26%', left: '15%', width: '9%', height: '8%' }
  },
  {
    name: "Emilia-Romagna",
    area: "north",
    position: { top: '23%', left: '33%', width: '20%', height: '10%' }
  },
  {
    name: "Toscana",
    area: "central",
    position: { top: '32%', left: '25%', width: '15%', height: '12%' }
  },
  {
    name: "Umbria",
    area: "central",
    position: { top: '38%', left: '37%', width: '8%', height: '8%' }
  },
  {
    name: "Marche",
    area: "central",
    position: { top: '32%', left: '43%', width: '10%', height: '10%' }
  },
  {
    name: "Lazio",
    area: "central",
    position: { top: '44%', left: '32%', width: '13%', height: '10%' }
  },
  {
    name: "Abruzzo",
    area: "central",
    position: { top: '42%', left: '46%', width: '11%', height: '9%' }
  },
  {
    name: "Molise",
    area: "south",
    position: { top: '48%', left: '49%', width: '9%', height: '7%' }
  },
  {
    name: "Campania",
    area: "south",
    position: { top: '52%', left: '41%', width: '12%', height: '10%' }
  },
  {
    name: "Puglia",
    area: "south",
    position: { top: '54%', left: '57%', width: '15%', height: '16%' }
  },
  {
    name: "Basilicata",
    area: "south",
    position: { top: '59%', left: '48%', width: '10%', height: '9%' }
  },
  {
    name: "Calabria",
    area: "south",
    position: { top: '67%', left: '50%', width: '10%', height: '17%' }
  },
  {
    name: "Sicilia",
    area: "south",
    position: { top: '82%', left: '36%', width: '18%', height: '12%' }
  },
  {
    name: "Sardegna",
    area: "south",
    position: { top: '48%', left: '7%', width: '12%', height: '22%' }
  }
];

// Places data
const places = [
  {
    id: 1,
    name: "Rome",
    region: "central",
    description: "The Eternal City where we spent a week exploring ancient ruins, Renaissance art, and enjoying delicious Roman cuisine.",
    imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1096&q=80",
    visited: "April 2024",
    highlights: ["Colosseum", "Vatican Museums", "Trastevere", "Roman Forum"],
    rating: 5
  },
  {
    id: 2,
    name: "Florence",
    region: "central",
    description: "The cradle of the Renaissance where we immersed ourselves in art, architecture, and Tuscan flavors for five unforgettable days.",
    imageUrl: "https://images.unsplash.com/photo-1543429257-3eb0b65d9c98?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    visited: "April 2024",
    highlights: ["Uffizi Gallery", "Duomo", "Ponte Vecchio", "Boboli Gardens"],
    rating: 5
  },
  {
    id: 3,
    name: "Venice",
    region: "north",
    description: "A magical floating city where we got lost in narrow alleyways, cruised the canals, and experienced the unique Venetian atmosphere.",
    imageUrl: "https://images.unsplash.com/photo-1514890547357-a9ee288728e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    visited: "May 2024",
    highlights: ["Grand Canal", "St. Mark's Square", "Murano Island", "Rialto Bridge"],
    rating: 4
  },
  {
    id: 4,
    name: "Amalfi Coast",
    region: "south",
    description: "A breathtaking coastline where we drove along winding roads, relaxed on stunning beaches, and enjoyed coastal village life.",
    imageUrl: "https://images.unsplash.com/photo-1612698093158-e07ac200d44e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    visited: "June 2024",
    highlights: ["Positano", "Ravello", "Path of the Gods Hike", "Boat Tour"],
    rating: 5
  },
  {
    id: 5,
    name: "Milan",
    region: "north",
    description: "Italy's fashion and design capital where we explored modern architecture, shopped in elegant boutiques, and saw Leonardo's Last Supper.",
    imageUrl: "https://images.unsplash.com/photo-1610016302534-6f67f1c968d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1075&q=80",
    visited: "May 2024",
    highlights: ["Duomo di Milano", "Galleria Vittorio Emanuele II", "Brera District", "Sforza Castle"],
    rating: 4
  },
  {
    id: 6,
    name: "Sicily",
    region: "south",
    description: "The Mediterranean's largest island where we experienced diverse cultures, ancient sites, and incredible seafood during our two-week stay.",
    imageUrl: "https://images.unsplash.com/photo-1596627118111-5f32af0f269f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    visited: "July 2024",
    highlights: ["Valley of the Temples", "Mount Etna", "Taormina", "Palermo Markets"],
    rating: 5
  },
  {
    id: 7,
    name: "Lake Como",
    region: "north",
    description: "A stunning alpine lake where we took ferry rides between charming villages, hiked in the mountains, and relaxed in elegant villas.",
    imageUrl: "https://images.unsplash.com/photo-1583426573939-97d09302d76a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    visited: "August 2024",
    highlights: ["Bellagio", "Villa del Balbianello", "Varenna", "Boat Tour"],
    rating: 5
  },
  {
    id: 8,
    name: "Cinque Terre",
    region: "north",
    description: "Five colorful fishing villages perched on cliffs where we hiked coastal trails, swam in crystal-clear waters, and enjoyed seafood pasta.",
    imageUrl: "https://images.unsplash.com/photo-1538156021790-808a5a11550e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=732&q=80",
    visited: "June 2024",
    highlights: ["Vernazza", "Coastal Trail", "Monterosso Beach", "Manarola Sunset"],
    rating: 5
  },
  {
    id: 9,
    name: "Naples",
    region: "south",
    description: "The birthplace of pizza where we experienced the vibrant street life, explored archaeological treasures, and took day trips to nearby sites.",
    imageUrl: "https://images.unsplash.com/photo-1513638000976-02a2923d3abd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
    visited: "September 2024",
    highlights: ["Pizza Margherita", "National Archaeological Museum", "Pompeii", "Spaccanapoli"],
    rating: 4
  }
];

// Helper function for star ratings
const RatingStars = ({ rating }: { rating: number }) => {
  return (
    <div className="flex items-center">
      {[...Array(5)].map((_, i) => (
        <svg
          key={i}
          className={`w-5 h-5 ${
            i < rating ? "text-yellow-400" : "text-gray-300"
          }`}
          fill="currentColor"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
};

export default function Places() {
  const [activeRegion, setActiveRegion] = useState("all");
  const { t } = useTranslation();
  
  // Get translated regions
  const regions = getRegions(t);
  
  // Filter places based on active region
  const filteredPlaces = activeRegion === "all" 
    ? places 
    : places.filter(place => place.region === activeRegion);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero section */}
        <div className="bg-gradient-to-r from-[#009246]/10 via-white to-[#CE2B37]/10 py-12 mb-8">
          <div className="container mx-auto px-4">
            <h1 className="font-['Cinzel'] text-4xl md:text-5xl font-bold text-center text-gray-900 mb-4">
              {t('places.title')}
            </h1>
            <p className="font-['Montserrat'] text-lg text-center text-gray-700 max-w-3xl mx-auto mb-8">
              {t('places.description')}
            </p>
          </div>
        </div>
        
        {/* Interactive Map section - white background */}
        <section className="bg-white py-8 mb-16">
          <div className="container mx-auto px-4">
            <div className="rounded-lg p-6 md:p-8 border border-gray-200">
              <h2 className="font-['Cinzel'] text-2xl font-bold text-center text-gray-900 mb-3">
                {t('places.mapTitle')}
              </h2>
              <p className="text-center text-gray-700 mb-8">
                {t('places.mapDescription')}
              </p>
              
              <div className="mb-8">
                {/* SVG-based Italy Map */}
                <ItalyMap 
                  places={mapPlaces} 
                  activeRegion={activeRegion} 
                  onRegionClick={setActiveRegion} 
                />
              </div>
              
              {/* Legend - Italian Flag Colors */}
              <div className="flex flex-wrap justify-center gap-6 mb-8">
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-green-600 rounded-sm mr-2"></div>
                  <span className="text-sm">{t('regions.north')}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-white rounded-sm mr-2 border border-gray-500"></div>
                  <span className="text-sm">{t('regions.central')}</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-red-600 rounded-sm mr-2"></div>
                  <span className="text-sm">{t('regions.south')}</span>
                </div>
              </div>
              
              {/* Region filter */}
              <div className="flex justify-center">
                <Tabs value={activeRegion} onValueChange={setActiveRegion} className="w-auto">
                  <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
                    {regions.map((region) => (
                      <TabsTrigger 
                        key={region.id} 
                        value={region.id}
                        className="font-['Montserrat'] text-sm"
                      >
                        {region.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>
            </div>
          </div>
        </section>
        
        {/* Places info display based on filter - mild green background */}
        <section className="bg-[#009246]/10 py-8 mb-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredPlaces.map(place => (
                <div key={place.id} className="bg-white rounded-lg overflow-hidden shadow-md border border-gray-200 p-4 flex flex-col md:flex-row gap-4">
                  <div 
                    className="h-32 md:w-1/3 bg-cover bg-center rounded-lg flex-shrink-0"
                    style={{ backgroundImage: `url(${place.imageUrl})` }}
                  ></div>
                  
                  <div className="flex-grow">
                    <div className="flex justify-between items-start">
                      <h3 className="font-['Cinzel'] text-xl font-bold text-gray-900">
                        {place.name}
                      </h3>
                      <Badge className={`
                        ${place.region === 'north' ? 'bg-green-100 text-green-700 border border-green-600' : ''}
                        ${place.region === 'central' ? 'bg-gray-50 text-gray-700 border border-gray-400' : ''}
                        ${place.region === 'south' ? 'bg-red-100 text-red-700 border border-red-600' : ''}
                      `}>
                        {regions.find(r => r.id === place.region)?.label || ""}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center mt-1 mb-2">
                      <RatingStars rating={place.rating} />
                      <span className="text-xs text-gray-500 ml-2">{t('places.visited')} {place.visited}</span>
                    </div>
                    
                    <div className="text-sm mb-3">
                      <span className="font-medium">{t('places.highlights')}: </span>
                      {place.highlights.join(", ")}
                    </div>
                    
                    <Link href={`/blog?search=${place.name}`}>
                      <Button variant="outline" size="sm" className="text-[#CE2B37] border-[#CE2B37] hover:bg-[#CE2B37]/10 w-full mt-auto">
                        {t('places.readBlogPosts')}
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Travel stats section - mild red background */}
        <section className="bg-[#CE2B37]/10 py-8 mb-16">
          <div className="container mx-auto px-4">
            <div className="rounded-lg p-8 border border-gray-200 bg-white">
              <h2 className="font-['Cinzel'] text-2xl font-bold text-center text-gray-900 mb-6">
                {t('places.statsTitle')}
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center p-4 bg-white rounded-lg shadow border border-gray-100">
                  <div className="text-4xl font-bold text-[#009246] mb-2">{places.length}</div>
                  <div className="text-gray-700">{t('places.placesVisited')}</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow border border-gray-100">
                  <div className="text-4xl font-bold text-[#009246] mb-2">3</div>
                  <div className="text-gray-700">{t('places.regionsExplored')}</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow border border-gray-100">
                  <div className="text-4xl font-bold text-[#009246] mb-2">42</div>
                  <div className="text-gray-700">{t('places.daysInItaly')}</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow border border-gray-100">
                  <div className="text-4xl font-bold text-[#009246] mb-2">18</div>
                  <div className="text-gray-700">{t('places.pastaDishesTried')}</div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA section - back to white */}
        <section className="bg-white py-8 mb-16">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-[#009246] to-[#009246]/80 rounded-lg p-8 text-white text-center">
              <h2 className="font-['Cinzel'] text-3xl font-bold mb-4">
                {t('places.ctaTitle')}
              </h2>
              <p className="max-w-3xl mx-auto mb-6 text-white/90">
                {t('places.ctaDescription')}
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link href="/travel-tips">
                  <Button className="bg-white text-[#009246] hover:bg-gray-100">
                    {t('nav.travelTips')}
                  </Button>
                </Link>
                <Link href="/blog">
                  <Button className="bg-[#CE2B37] hover:bg-[#CE2B37]/90">
                    {t('places.readBlogPosts')}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
}