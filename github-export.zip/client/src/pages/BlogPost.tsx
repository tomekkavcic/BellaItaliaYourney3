import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Newsletter from "@/components/Newsletter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";

// Sample blog post data (in a real app, this would come from an API or database)
const blogPosts = [
  {
    id: 1,
    title: "A Week in Rome: Our Complete Itinerary",
    excerpt: "Discover how we explored the Eternal City in just seven days, from hidden local spots to iconic landmarks.",
    imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1096&q=80",
    date: "March 10, 2025",
    category: "cities",
    readTime: "8 min read",
    featured: true,
    author: {
      name: "Marco Rossi",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80",
      bio: "Travel writer and photographer living in Florence. Passionate about Italian history, art, and cuisine."
    },
    content: [
      {
        type: "paragraph",
        text: "Rome wasn't built in a day, and it certainly can't be fully experienced in one either. But with careful planning, seven days in the Eternal City can give you a deep taste of its rich history, vibrant culture, and incredible cuisine."
      },
      {
        type: "paragraph",
        text: "Our journey through Rome began on a sunny Monday morning in early spring – the perfect time to visit before the summer tourist crowds arrive and temperatures soar. We checked into our small, family-run hotel in the Monti neighborhood, an area that balances central location with local character."
      },
      {
        type: "heading",
        text: "Day 1: Ancient Rome"
      },
      {
        type: "paragraph",
        text: "We dedicated our first full day to exploring Ancient Rome. After an early breakfast of cornetto and cappuccino at a nearby café, we headed straight to the Colosseum. Pro tip: book your tickets online in advance and arrive 30 minutes before your scheduled entry time."
      },
      {
        type: "image",
        url: "https://images.unsplash.com/photo-1555992828-35627f3b373f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
        caption: "The Colosseum - still magnificent after nearly 2,000 years"
      },
      {
        type: "paragraph",
        text: "The scale and engineering of the Colosseum are truly awe-inspiring, especially when you consider it was built nearly 2,000 years ago. We spent about two hours exploring with an audio guide before moving on to the Roman Forum and Palatine Hill (included in the same ticket)."
      },
      {
        type: "paragraph",
        text: "Walking among the ruins of the Forum—once the center of Roman public life—gives you a visceral connection to the ancient world. We brought a detailed guidebook which helped bring the scattered columns and foundations to life."
      },
      {
        type: "paragraph",
        text: "For lunch, we avoided the tourist traps near the major sites and walked about 10 minutes to a small trattoria our hotel had recommended. Here we had our first authentic Roman pasta—cacio e pepe (cheese and pepper) for me and amatriciana (tomato and guanciale) for my partner."
      },
      {
        type: "heading",
        text: "Day 2: Vatican City"
      },
      {
        type: "paragraph",
        text: "Our second day was dedicated to Vatican City. Again, advance tickets are essential here, and we opted for an early morning slot at the Vatican Museums to beat the crowds."
      },
      {
        type: "paragraph",
        text: "The museums are overwhelming in the best possible way—room after room of masterpieces that would be the centerpiece of any other collection in the world. The Raphael Rooms were a particular highlight before reaching the famous Sistine Chapel."
      },
      {
        type: "image",
        url: "https://images.unsplash.com/photo-1569416078500-3857b00616f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
        caption: "St. Peter's Square - the heart of Vatican City"
      },
      {
        type: "paragraph",
        text: "Seeing Michelangelo's ceiling in person is an experience that simply cannot be replicated in books or photos. The scale, detail, and artistry are breathtaking. Remember that photography is not permitted in the Sistine Chapel, and it's a place of reverence, so quiet is respected."
      },
      {
        type: "paragraph",
        text: "After the museums, we visited St. Peter's Basilica—the largest church in the world and a masterpiece of Renaissance architecture. The dome, designed by Michelangelo, is particularly impressive, and if you're up for it, you can climb to the top for panoramic views of Rome."
      },
      {
        type: "heading",
        text: "Day 3: Exploring Trastevere and Beyond"
      },
      {
        type: "paragraph",
        text: "On our third day, we crossed the Tiber River to explore the charming neighborhood of Trastevere. This area feels like a different world from the monumental center of Rome—narrow cobblestone streets, ivy-covered buildings, and a more local atmosphere."
      },
      {
        type: "paragraph",
        text: "We spent the morning wandering without a specific agenda, discovering small churches, artisan shops, and picturesque squares. The Basilica of Santa Maria in Trastevere, with its stunning mosaics, was a highlight."
      },
      {
        type: "paragraph",
        text: "For lunch, we found a small outdoor restaurant in a quiet piazza and enjoyed a leisurely meal of traditional Roman dishes while watching local life unfold around us."
      },
      {
        type: "paragraph",
        text: "In the afternoon, we climbed the Janiculum Hill (Gianicolo) for some of the best views over Rome's rooftops and domes. This spot is somewhat off the typical tourist path but offers a spectacular panorama of the city."
      },
      {
        type: "heading",
        text: "Remaining Days: Finding Our Rhythm"
      },
      {
        type: "paragraph",
        text: "For the rest of our week, we found a comfortable rhythm, balancing scheduled visits to major sites with free time for spontaneous exploration."
      },
      {
        type: "paragraph",
        text: "We visited the Pantheon (still featuring the world's largest unreinforced concrete dome after nearly 2,000 years), tossed coins in the Trevi Fountain, and sat on the Spanish Steps watching the world go by."
      },
      {
        type: "image",
        url: "https://images.unsplash.com/photo-1529154166925-574a0236a4f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1176&q=80",
        caption: "The iconic Trevi Fountain - don't forget to toss a coin to ensure your return to Rome"
      },
      {
        type: "paragraph",
        text: "We dedicated half a day to the Borghese Gallery (reservation required), which houses an incredible collection of sculptures by Bernini and paintings by Caravaggio, among others. The surrounding Borghese Gardens offered a peaceful retreat from the urban bustle."
      },
      {
        type: "heading",
        text: "Food Highlights"
      },
      {
        type: "paragraph",
        text: "No account of a week in Rome would be complete without mentioning the food in more detail. Beyond the pasta classics mentioned earlier, we enjoyed sublime supplì (fried rice balls with mozzarella), crispy thin-crust Roman pizza, and the most transcendent gelato of our lives."
      },
      {
        type: "paragraph",
        text: "We discovered that eating where the locals eat is always the best policy. Look for restaurants filled with Italians, not tourists, and don't be afraid to venture down side streets away from major attractions."
      },
      {
        type: "paragraph",
        text: "A personal favorite discovery was the Jewish-Roman cuisine in the historic Jewish Ghetto area, especially the fried artichokes (carciofi alla giudia) when they were in season."
      },
      {
        type: "heading",
        text: "Practical Tips"
      },
      {
        type: "paragraph",
        text: "• Book major attractions in advance to save time and avoid disappointment."
      },
      {
        type: "paragraph",
        text: "• Consider getting the Roma Pass if you plan to visit multiple paid attractions."
      },
      {
        type: "paragraph",
        text: "• Wear comfortable shoes – Rome is best explored on foot, and you'll be walking on cobblestones."
      },
      {
        type: "paragraph",
        text: "• Learn a few basic Italian phrases – even simple greetings are appreciated."
      },
      {
        type: "paragraph",
        text: "• Take breaks during the day – the Roman tradition of a coffee break or afternoon rest makes sense in this busy city."
      },
      {
        type: "heading",
        text: "Final Thoughts"
      },
      {
        type: "paragraph",
        text: "Seven days in Rome gave us a wonderful introduction to this magnificent city, but we left feeling there was still so much more to discover. Perhaps that's the magic of Rome – it reveals itself in layers, always leaving you wanting to return."
      },
      {
        type: "paragraph",
        text: "As the saying goes, 'Roma, non basta una vita' – for Rome, one lifetime is not enough. But one week? It's a perfect start to what will hopefully be a lifelong love affair with the Eternal City."
      }
    ],
    relatedPosts: [4, 2, 3]
  },
  {
    id: 4,
    title: "Amalfi Coast Road Trip: A 5-Day Adventure",
    excerpt: "Our unforgettable journey along Italy's most scenic coastline, with stops in Positano, Ravello, and hidden beaches.",
    imageUrl: "https://images.unsplash.com/photo-1612698093158-e07ac200d44e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "February 8, 2025",
    category: "travel",
    readTime: "9 min read",
    featured: true
  },
  {
    id: 2,
    title: "Tuscan Vineyard Tour: Wine Tasting in Chianti",
    excerpt: "Our journey through the rolling hills of Chianti, sampling world-class wines and meeting passionate winemakers.",
    imageUrl: "https://images.unsplash.com/photo-1566559532512-004a6df74db5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1169&q=80",
    date: "March 2, 2025",
    category: "food",
    readTime: "6 min read",
    featured: false
  },
  {
    id: 3,
    title: "Venice Canals: Beyond the Tourist Crowds",
    excerpt: "How we discovered the authentic Venetian experience by exploring the less-traveled canals and neighborhoods.",
    imageUrl: "https://images.unsplash.com/photo-1514890547357-a9ee288728e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "February 18, 2025",
    category: "cities",
    readTime: "7 min read",
    featured: false
  }
];

const blogCategories = [
  {
    id: "all",
    label: "All Posts"
  },
  {
    id: "cities",
    label: "City Guides"
  },
  {
    id: "food",
    label: "Food & Wine"
  },
  {
    id: "travel",
    label: "Travel Stories"
  }
];

export default function BlogPost() {
  const [location] = useLocation();
  const [post, setPost] = useState<any>(null);
  const [relatedPosts, setRelatedPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // In a real app, we would fetch the post data from an API
    // Here we'll simulate that by extracting the post ID from the URL
    const postId = parseInt(location.split('/').pop() || "1");
    
    // Find the post with the matching ID
    const foundPost = blogPosts.find(p => p.id === postId);
    
    if (foundPost) {
      setPost(foundPost);
      
      // Get related posts if available
      if (foundPost.relatedPosts) {
        const related = foundPost.relatedPosts
          .map(id => blogPosts.find(p => p.id === id))
          .filter(p => p !== undefined);
        setRelatedPosts(related as any[]);
      }
    }
    
    setIsLoading(false);
  }, [location]);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#009246]"></div>
      </div>
    );
  }
  
  if (!post) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow pt-24 pb-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-['Cinzel'] text-3xl font-bold mb-4">Post Not Found</h1>
            <p className="mb-8">The blog post you're looking for doesn't exist or has been removed.</p>
            <Link href="/blog">
              <Button>Back to Blog</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero section */}
        <div className="relative h-[50vh] md:h-[60vh] mb-8">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${post.imageUrl})` }}
          ></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 max-w-4xl mx-auto">
            <div className="flex items-center mb-4">
              <span className="text-white text-sm font-medium bg-[#009246] px-3 py-1 rounded-full mr-3">
                {blogCategories.find(cat => cat.id === post.category)?.label}
              </span>
              <span className="text-white text-sm">
                {post.date} • {post.readTime}
              </span>
            </div>
            <h1 className="font-['Cinzel'] text-3xl md:text-5xl font-bold text-white mb-4 leading-tight">
              {post.title}
            </h1>
          </div>
        </div>
        
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Author section */}
            {post.author && (
              <div className="mb-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center">
                  <Avatar className="h-12 w-12 mr-4">
                    <AvatarImage src={post.author.image} alt={post.author.name} />
                    <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-['Cinzel'] text-lg font-bold">{post.author.name}</h3>
                    <p className="text-gray-600 text-sm">{post.author.bio}</p>
                  </div>
                </div>
              </div>
            )}
            
            {/* Content */}
            <article className="prose lg:prose-xl max-w-none mb-12">
              {post.content?.map((block: any, index: number) => {
                switch (block.type) {
                  case 'paragraph':
                    return (
                      <p key={index} className="font-['Montserrat'] text-gray-800 mb-6 leading-relaxed">
                        {block.text}
                      </p>
                    );
                  case 'heading':
                    return (
                      <h2 key={index} className="font-['Cinzel'] text-2xl font-bold text-gray-900 mt-10 mb-4">
                        {block.text}
                      </h2>
                    );
                  case 'image':
                    return (
                      <figure key={index} className="my-8">
                        <img 
                          src={block.url} 
                          alt={block.caption || 'Blog image'} 
                          className="w-full rounded-lg shadow-md"
                        />
                        {block.caption && (
                          <figcaption className="text-center text-gray-500 mt-2 italic text-sm">
                            {block.caption}
                          </figcaption>
                        )}
                      </figure>
                    );
                  default:
                    return null;
                }
              })}
            </article>
            
            {/* Share buttons */}
            <div className="flex items-center justify-between border-t border-b border-gray-200 py-6 mb-12">
              <div>
                <h4 className="font-['Cinzel'] font-semibold mb-2">Share this story</h4>
                <div className="flex space-x-4">
                  <button className="text-blue-600 hover:text-blue-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                    </svg>
                  </button>
                  <button className="text-blue-800 hover:text-blue-900">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/>
                    </svg>
                  </button>
                  <button className="text-green-600 hover:text-green-800">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                    </svg>
                  </button>
                  <button className="text-blue-500 hover:text-blue-700">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/>
                    </svg>
                  </button>
                </div>
              </div>
              <Link href="/blog">
                <Button variant="outline">
                  Back to Blog
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Related posts */}
          {relatedPosts.length > 0 && (
            <div className="mt-12 mb-16">
              <h2 className="font-['Cinzel'] text-3xl font-bold mb-8 text-center">You May Also Enjoy</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {relatedPosts.map((relatedPost) => (
                  <Card key={relatedPost.id} className="overflow-hidden h-full">
                    <div 
                      className="h-48 bg-cover bg-center"
                      style={{ backgroundImage: `url(${relatedPost.imageUrl})` }}
                    ></div>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-[#009246] text-sm font-medium">
                          {blogCategories.find(cat => cat.id === relatedPost.category)?.label}
                        </span>
                        <span className="text-gray-500 text-sm">
                          {relatedPost.date}
                        </span>
                      </div>
                      <h3 className="font-['Cinzel'] text-xl font-bold text-gray-900 mb-2">
                        {relatedPost.title}
                      </h3>
                      <p className="font-['Montserrat'] text-gray-700 mb-4 line-clamp-3">
                        {relatedPost.excerpt}
                      </p>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 text-sm">
                          {relatedPost.readTime}
                        </span>
                        <Link href={`/blog/${relatedPost.id}`}>
                          <Button variant="outline" className="text-[#CE2B37] border-[#CE2B37] hover:bg-[#CE2B37]/10">
                            Read More
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
}