import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Newsletter from "@/components/Newsletter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTranslation } from "react-i18next";

// Blog post data - We will use t() function within the component to translate labels
const blogRegions = [
  {
    id: "all",
    labelKey: "regions.all"
  },
  {
    id: "north",
    labelKey: "regions.north"
  },
  {
    id: "central",
    labelKey: "regions.central"
  },
  {
    id: "south",
    labelKey: "regions.south"
  }
];

// Categories for post types (now aligned with regions)
const blogCategories = [
  {
    id: "north",
    labelKey: "regions.north"
  },
  {
    id: "central",
    labelKey: "regions.central"
  },
  {
    id: "south",
    labelKey: "regions.south"
  }
];

const blogPosts = [
  {
    id: 1,
    title: "A Week in Rome: Our Complete Itinerary",
    excerpt: "Discover how we explored the Eternal City in just seven days, from hidden local spots to iconic landmarks.",
    imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1096&q=80",
    date: "March 10, 2025",
    category: "central",
    region: "central",
    readTime: "8 min read",
    featured: true
  },
  {
    id: 2,
    title: "Tuscan Vineyard Tour: Wine Tasting in Chianti",
    excerpt: "Our journey through the rolling hills of Chianti, sampling world-class wines and meeting passionate winemakers.",
    imageUrl: "https://images.unsplash.com/photo-1566559532512-004a6df74db5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1169&q=80",
    date: "March 2, 2025",
    category: "central",
    region: "central",
    readTime: "6 min read",
    featured: false
  },
  {
    id: 3,
    title: "Venice Canals: Beyond the Tourist Crowds",
    excerpt: "How we discovered the authentic Venetian experience by exploring the less-traveled canals and neighborhoods.",
    imageUrl: "https://images.unsplash.com/photo-1514890547357-a9ee288728e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "February 18, 2025",
    category: "north",
    region: "north",
    readTime: "7 min read",
    featured: false
  },
  {
    id: 4,
    title: "Amalfi Coast Road Trip: A 5-Day Adventure",
    excerpt: "Our unforgettable journey along Italy's most scenic coastline, with stops in Positano, Ravello, and hidden beaches.",
    imageUrl: "https://images.unsplash.com/photo-1612698093158-e07ac200d44e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "February 8, 2025",
    category: "south",
    region: "south",
    readTime: "9 min read",
    featured: true
  },
  {
    id: 5,
    title: "The Perfect Carbonara: Cooking Class in Rome",
    excerpt: "Learning the secrets of authentic Roman pasta from a local chef in a historic Trastevere kitchen.",
    imageUrl: "https://images.unsplash.com/photo-1546549032-9571cd6b27df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
    date: "January 29, 2025",
    category: "central",
    region: "central",
    readTime: "5 min read",
    featured: false
  },
  {
    id: 6,
    title: "Island Hopping in Sicily: Stromboli to Lipari",
    excerpt: "Our adventure through the Aeolian Islands, witnessing volcanic eruptions and discovering pristine beaches.",
    imageUrl: "https://images.unsplash.com/photo-1596627118111-5f32af0f269f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "January 15, 2025",
    category: "south",
    region: "south",
    readTime: "8 min read",
    featured: false
  },
  {
    id: 7,
    title: "Lake Como's Hidden Gems: Beyond Bellagio",
    excerpt: "Exploring the lesser-known villages and viewpoints around Italy's most famous lake.",
    imageUrl: "https://images.unsplash.com/photo-1583426573939-97d09302d76a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    date: "January 5, 2025",
    category: "north",
    region: "north",
    readTime: "7 min read",
    featured: false
  },
  {
    id: 8,
    title: "Milan Fashion Week: Our Experience",
    excerpt: "What it's like to attend one of the world's premier fashion events in Italy's style capital.",
    imageUrl: "https://images.unsplash.com/photo-1610016302534-6f67f1c968d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1075&q=80",
    date: "December 12, 2024",
    category: "north",
    region: "north",
    readTime: "6 min read",
    featured: false
  }
];

export default function Blog() {
  const { t } = useTranslation();
  const [activeRegion, setActiveRegion] = useState("all");
  
  // Filter posts based on active region
  const filteredPosts = activeRegion === "all" 
    ? blogPosts 
    : blogPosts.filter(post => post.region === activeRegion);
  
  // Get featured posts
  const featuredPosts = blogPosts.filter(post => post.featured);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero section */}
        <div className="bg-gradient-to-r from-[#009246]/10 via-white to-[#CE2B37]/10 py-12 mb-8">
          <div className="container mx-auto px-4">
            <h1 className="font-['Cinzel'] text-4xl md:text-5xl font-bold text-center text-gray-900 mb-4">
              {t('blog.title')}
            </h1>
            <p className="font-['Montserrat'] text-lg text-center text-gray-700 max-w-3xl mx-auto mb-8">
              {t('blog.subtitle')}
            </p>
          </div>
        </div>
        
        {/* Featured posts section - white background */}
        <section className="bg-white py-8 mb-8">
          <div className="container mx-auto px-4">
            <h2 className="font-['Cinzel'] text-3xl font-bold mb-6">{t('blog.featuredStories')}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {featuredPosts.map(post => (
                <div key={post.id} className="relative group overflow-hidden rounded-lg shadow-lg">
                  <div 
                    className="h-80 bg-cover bg-center"
                    style={{ backgroundImage: `url(${post.imageUrl})` }}
                  ></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                  <div className="absolute bottom-0 p-6 w-full">
                    <div className="flex items-center mb-2">
                      <span className={`text-sm font-medium px-3 py-1 rounded-full mr-3 ${
                        post.category === "north" ? "bg-green-500 text-white" : 
                        post.category === "central" ? "bg-gray-200 text-gray-800" : 
                        "bg-red-600 text-white"
                      }`}>
                        {t(blogCategories.find(cat => cat.id === post.category)?.labelKey || '')}
                      </span>
                      <span className="text-white text-sm">
                        {post.date} • {post.readTime}
                      </span>
                    </div>
                    <h3 className="font-['Cinzel'] text-2xl font-bold text-white mb-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-200 mb-4">
                      {post.excerpt}
                    </p>
                    <Link href={`/blog/${post.id}`}>
                      <Button className="bg-white text-gray-900 hover:bg-gray-100">
                        Read Story
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* All posts section - mild green background */}
        <section className="bg-[#009246]/10 py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center mb-6">
              <h2 className="font-['Cinzel'] text-3xl font-bold mb-4 md:mb-0">{t('blog.allStories')}</h2>
              <div className="w-full md:w-auto overflow-x-auto pb-2">
                <Tabs value={activeRegion} onValueChange={setActiveRegion} className="w-full">
                  <TabsList className="inline-flex h-10 min-w-full md:w-auto">
                    {blogRegions.map((region) => (
                      <TabsTrigger 
                        key={region.id} 
                        value={region.id}
                        className={`font-['Montserrat'] text-sm px-4 whitespace-nowrap ${
                          region.id === "north" ? "data-[state=active]:bg-green-500 data-[state=active]:text-white" :
                          region.id === "central" ? "data-[state=active]:bg-gray-100 data-[state=active]:text-gray-800" :
                          region.id === "south" ? "data-[state=active]:bg-red-600 data-[state=active]:text-white" :
                          ""
                        }`}
                      >
                        {t(region.labelKey)}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map(post => (
                <Card key={post.id} className="overflow-hidden h-full bg-white">
                  <div 
                    className="h-48 bg-cover bg-center"
                    style={{ backgroundImage: `url(${post.imageUrl})` }}
                  ></div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`text-sm font-medium px-2 py-1 rounded ${
                        post.category === "north" ? "bg-green-100 text-green-700 border border-green-600" : 
                        post.category === "central" ? "bg-gray-100 text-gray-700 border border-gray-400" : 
                        "bg-red-100 text-red-700 border border-red-600"
                      }`}>
                        {t(blogCategories.find(cat => cat.id === post.category)?.labelKey || '')}
                      </span>
                      <span className="text-gray-500 text-sm">
                        {post.date}
                      </span>
                    </div>
                    <h3 className="font-['Cinzel'] text-xl font-bold text-gray-900 mb-2">
                      {post.title}
                    </h3>
                    <p className="font-['Montserrat'] text-gray-700 mb-4">
                      {post.excerpt}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500 text-sm">
                        {post.readTime}
                      </span>
                      <Link href={`/blog/${post.id}`}>
                        <Button variant="outline" className="text-[#CE2B37] border-[#CE2B37] hover:bg-[#CE2B37]/10">
                          Read More
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
        
        {/* Newsletter signup section - mild red background */}
        <section className="bg-[#CE2B37]/10 py-8 mb-8">
          <div className="container mx-auto px-4">
            <div className="bg-white p-8 rounded-lg border border-gray-200">
              <div className="max-w-3xl mx-auto text-center">
                <h2 className="font-['Cinzel'] text-2xl font-bold text-gray-900 mb-3">
                  {t('newsletter.title')}
                </h2>
                <p className="font-['Montserrat'] text-gray-700 mb-6">
                  {t('newsletter.description')}
                </p>
                <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                  <input 
                    type="email" 
                    placeholder={t('footer.emailPlaceholder')}
                    className="px-4 py-2 border rounded-md flex-grow"
                  />
                  <Button className="bg-[#009246] hover:bg-[#009246]/90">
                    {t('footer.subscribe')}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
}