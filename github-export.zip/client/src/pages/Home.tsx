import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import FeaturedDestinations from "@/components/FeaturedDestinations";
import BlogTeaser from "@/components/BlogTeaser";
import GoogleReviews from "@/components/GoogleReviews";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";
import ItalyInteractiveMap from "@/components/ItalyInteractiveMap";
import { destinations, getFeaturedDestinations } from "@/data/destinations";
import { getBlogPostsByRegion, getFeaturedBlogPosts } from "@/data/blogPosts";
import { Coffee, UtensilsCrossed, Hotel, Mountain, Heart, Users, Map, Camera, CalendarDays } from "lucide-react";
import FloatingContactButton from "@/components/FloatingContactButton";
import ChatWidget from "@/components/ChatWidget";

export default function Home() {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [activeRegion, setActiveRegion] = useState<string>("");
  
  const featuredDestinations = getFeaturedDestinations();
  const featuredPosts = getFeaturedBlogPosts();
  
  const handleRegionClick = (regionId: string) => {
    setActiveRegion(regionId);
    // For detailed regions, navigate to the region page
    // For macro regions (north, central, south), filter the destinations
    if (["north", "central", "south"].includes(regionId)) {
      navigate(`/places?region=${regionId}`);
    } else {
      navigate(`/places?detailed_region=${regionId}`);
    }
  };
  
  const handlePlaceClick = (placeId: number) => {
    const place = destinations.find(d => d.id === placeId);
    if (place) {
      navigate(`/places/${place.slug}`);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="pt-16">
        <Hero />
        
        {/* Featured Destinations - White Background */}
        <div className="bg-white">
          <FeaturedDestinations />
        </div>
        
        {/* Travel Ideas Section - White Background */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('home.travelIdeas.title', 'Travel Ideas & Inspiration')}</h2>
              <div className="w-24 h-1 bg-[#009246] mx-auto mb-6"></div>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {t('home.travelIdeas.subtitle', 'Discover unique experiences and adventures across Italy')}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-[#f8f9fa] rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1516483638261-f4dbaf036963?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1286&q=80')] bg-cover bg-center"></div>
                <div className="p-6">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-[#009246]/10 rounded-full flex items-center justify-center mr-3">
                      <Camera className="w-4 h-4 text-[#1A3A5A]" />
                    </div>
                    <h3 className="font-bold text-gray-800">{t('home.travelIdeas.cultural.title', 'Cultural Experiences')}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{t('home.travelIdeas.cultural.description', 'Immerse yourself in Italy\'s rich heritage through museums, historic sites, and local traditions.')}</p>
                  <button 
                    onClick={() => navigate("/travel-tips?category=cultural")}
                    className="text-[#1A3A5A] font-medium hover:underline flex items-center"
                  >
                    {t('home.travelIdeas.exploreButton', 'Explore More')} 
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="bg-[#f8f9fa] rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1461023058943-07fcbe16d735?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1469&q=80')] bg-cover bg-center"></div>
                <div className="p-6">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-[#ffffff] rounded-full flex items-center justify-center mr-3 border border-gray-200">
                      <Coffee className="w-4 h-4 text-[#CE2B37]" />
                    </div>
                    <h3 className="font-bold text-gray-800">{t('home.travelIdeas.food.title', 'Culinary Adventures')}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{t('home.travelIdeas.food.description', 'Taste your way through Italy\'s renowned cuisine with food tours, cooking classes, and wine tastings.')}</p>
                  <button 
                    onClick={() => navigate("/travel-tips?category=food")}
                    className="text-[#1A3A5A] font-medium hover:underline flex items-center"
                  >
                    {t('home.travelIdeas.exploreButton', 'Explore More')} 
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="bg-[#f8f9fa] rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1506306682775-3552fcac3c30?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80')] bg-cover bg-center"></div>
                <div className="p-6">
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-[#CE2B37]/10 rounded-full flex items-center justify-center mr-3">
                      <Mountain className="w-4 h-4 text-[#009246]" />
                    </div>
                    <h3 className="font-bold text-gray-800">{t('home.travelIdeas.nature.title', 'Outdoor Adventures')}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{t('home.travelIdeas.nature.description', 'Experience Italy\'s natural beauty through hiking, cycling, and coastal explorations.')}</p>
                  <button 
                    onClick={() => navigate("/travel-tips?category=outdoor")}
                    className="text-[#1A3A5A] font-medium hover:underline flex items-center"
                  >
                    {t('home.travelIdeas.exploreButton', 'Explore More')} 
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Blog Teaser Section - Light Green Background */}
        <div className="bg-[#009246]/5">
          <BlogTeaser />
        </div>
        
        {/* Google Reviews Section - White Background */}
        <div className="bg-white">
          <GoogleReviews />
        </div>
        
        {/* Newsletter Section - Light Red Background */}
        <div className="bg-[#CE2B37]/5">
          <Newsletter />
        </div>
      </main>
      <Footer />
      
      {/* Interactive Elements */}
      <FloatingContactButton />
      <ChatWidget />
    </div>
  );
}
