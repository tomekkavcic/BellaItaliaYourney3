import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Newsletter from "@/components/Newsletter";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define tip categories and their content
const tipCategories = [
  {
    id: "general",
    label: "General Tips",
    tips: [
      {
        title: "Learn Basic Italian Phrases",
        content: "Even a few words like 'grazie' (thank you), 'per favore' (please), and 'buongiorno' (good morning) go a long way with locals.",
        icon: "🗣️",
      },
      {
        title: "Validate Train Tickets",
        content: "Always validate your train ticket before boarding in the small green machines at the platform. Failure to do so can result in a hefty fine.",
        icon: "🚆",
      },
      {
        title: "Siesta Hours",
        content: "Many shops and businesses close for a few hours in the afternoon, typically between 1-4 PM, especially in smaller towns and during summer.",
        icon: "⏰",
      },
      {
        title: "Cash Is King",
        content: "While credit cards are widely accepted in tourist areas, always have some cash on hand for small purchases, especially in rural areas.",
        icon: "💶",
      },
      {
        title: "Drinking Fountains",
        content: "Look for 'nasoni' drinking fountains in Rome and other cities. They provide clean, cold drinking water for free - just bring a refillable bottle!",
        icon: "🚰",
      },
    ],
  },
  {
    id: "food",
    label: "Food & Dining",
    tips: [
      {
        title: "Coperto Charge",
        content: "Many restaurants charge a 'coperto' (cover charge) of €1-5 per person. This is not a tip but a standard fee for bread and table service.",
        icon: "🍞",
      },
      {
        title: "Coffee Etiquette",
        content: "Drink cappuccino only at breakfast. Italians consider milk-based coffees a morning drink. After lunch or dinner, opt for an espresso instead.",
        icon: "☕",
      },
      {
        title: "Standing vs. Sitting",
        content: "At cafes and bars, standing at the counter costs significantly less than sitting at a table. Check the price difference before deciding.",
        icon: "🪑",
      },
      {
        title: "Regional Specialties",
        content: "Each region has its own culinary specialties. Try the local dishes wherever you go - carbonara in Rome, risotto in Milan, and seafood in Sicily.",
        icon: "🍝",
      },
      {
        title: "Meal Times",
        content: "Italians eat late compared to some cultures. Lunch is typically 1-3 PM and dinner rarely starts before 8 PM, sometimes later in summer.",
        icon: "🕗",
      },
    ],
  },
  {
    id: "transportation",
    label: "Transportation",
    tips: [
      {
        title: "Validate Bus & Metro Tickets",
        content: "Just like train tickets, you must validate bus and metro tickets in the machines before or upon boarding to avoid fines.",
        icon: "🚌",
      },
      {
        title: "ZTL Zones",
        content: "Many Italian cities have Limited Traffic Zones (ZTL) in historic centers. Don't drive in these areas without permission or you'll be fined.",
        icon: "🚫",
      },
      {
        title: "Regional Train Savings",
        content: "Regional trains are much cheaper than high-speed trains (Frecciarossa, Italo). If you're not in a hurry, they're a budget-friendly option.",
        icon: "🚉",
      },
      {
        title: "Taxi Rates",
        content: "Always use official taxis from designated stands or apps. Ensure the meter is running, and know that rates increase at night and on holidays.",
        icon: "🚕",
      },
      {
        title: "Ferry Bookings",
        content: "If visiting islands like Capri or Sicily, book ferry tickets in advance during peak season (June-September) to ensure availability.",
        icon: "⛴️",
      },
    ],
  },
  {
    id: "cultural",
    label: "Cultural Etiquette",
    tips: [
      {
        title: "Dress Code for Churches",
        content: "When visiting churches, cover shoulders and knees. Major basilicas like St. Peter's strictly enforce this rule and may deny entry.",
        icon: "⛪",
      },
      {
        title: "Greeting Customs",
        content: "Italians typically greet with 'Buongiorno' (good day) or 'Buonasera' (good evening). A handshake is common for first meetings, while friends kiss on both cheeks.",
        icon: "👋",
      },
      {
        title: "Volume Control",
        content: "While Italians can be expressive and animated, shouting in public places is still considered rude. Keep conversations at a reasonable volume.",
        icon: "🔊",
      },
      {
        title: "Photo Etiquette",
        content: "Many museums and churches prohibit photography or require no flash. Always check for signs or ask before taking pictures inside historical sites.",
        icon: "📸",
      },
      {
        title: "Tipping Culture",
        content: "Tipping is not expected in Italy as service is usually included. However, rounding up the bill or leaving a few euros for exceptional service is appreciated.",
        icon: "💰",
      },
    ],
  },
];

export default function TravelTips() {
  const [activeCategory, setActiveCategory] = useState("general");

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero section */}
        <div className="bg-gradient-to-r from-[#009246]/10 via-white to-[#CE2B37]/10 py-12 mb-8">
          <div className="container mx-auto px-4">
            <h1 className="font-['Cinzel'] text-4xl md:text-5xl font-bold text-center text-gray-900 mb-4">
              Italian Travel Tips
            </h1>
            <p className="font-['Montserrat'] text-lg text-center text-gray-700 max-w-3xl mx-auto mb-8">
              Make the most of your Italian adventure with our curated travel tips 
              from years of exploring the beautiful country of Italy.
            </p>
            
            {/* Italian cafe image */}
            <div className="max-w-4xl mx-auto rounded-lg overflow-hidden shadow-lg">
              <div className="relative h-64 md:h-80">
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{
                    backgroundImage: "url('https://images.unsplash.com/photo-1517231925375-bf2cb42917a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80')"
                  }}
                ></div>
                <div className="absolute inset-0 bg-black bg-opacity-20"></div>
              </div>
              <p className="text-center text-sm text-gray-500 italic my-2 px-4">
                "Prendi un caffè" - Enjoying a small espresso at a local café is an essential Italian ritual
              </p>
            </div>
          </div>
        </div>
        
        {/* Tips content - white background */}
        <section className="bg-white py-8 mb-8">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="general" value={activeCategory} onValueChange={setActiveCategory} className="w-full">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-8">
                {tipCategories.map((category) => (
                  <TabsTrigger 
                    key={category.id} 
                    value={category.id}
                    className="font-['Montserrat'] text-sm md:text-base"
                  >
                    {category.label}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {tipCategories.map((category) => (
                <TabsContent key={category.id} value={category.id}>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {category.tips.map((tip, index) => (
                      <Card key={index} className="overflow-hidden border border-gray-200 h-full">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <span className="text-3xl">{tip.icon}</span>
                            <div>
                              <h3 className="font-['Cinzel'] text-xl font-semibold text-gray-900 mb-2">
                                {tip.title}
                              </h3>
                              <p className="font-['Montserrat'] text-gray-700">
                                {tip.content}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>
        
        {/* Contact section - mild red background */}
        <section className="bg-[#CE2B37]/10 py-8 mb-16">
          <div className="container mx-auto px-4">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h2 className="font-['Cinzel'] text-2xl font-bold text-gray-900 mb-4">Have a Tip to Share?</h2>
              <p className="font-['Montserrat'] text-gray-700 mb-4">
                We'd love to hear about your experiences and any tips you have for traveling in Italy. Share them in the comments below or contact us directly.
              </p>
              <div className="flex items-center gap-2 text-[#009246] font-medium">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span>Email us at: contact@ouritalianjourney.com</span>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Newsletter />
      <Footer />
    </div>
  );
}