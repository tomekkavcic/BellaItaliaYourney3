<?php
/**
 * The template for displaying the blog index
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();

// Get blog layout from customizer
$blog_layout = get_theme_mod( 'bella_italia_blog_layout', 'grid' );

// Set column classes based on layout
$column_class = 'col-md-6 col-lg-4';
if ( $blog_layout === 'list' ) {
    $column_class = 'col-12';
} elseif ( $blog_layout === 'masonry' ) {
    $column_class = 'col-md-6 col-lg-4 masonry-item';
}

// Set wrapper class based on layout
$blog_wrapper_class = 'blog-' . $blog_layout;
if ( $blog_layout === 'masonry' ) {
    $blog_wrapper_class .= ' masonry-grid';
}
?>

<div id="primary" class="content-area py-5">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php if ( is_home() && ! is_front_page() ) : ?>
                        <header class="page-header mb-4">
                            <h1 class="page-title"><?php single_post_title(); ?></h1>
                            <div class="archive-description">
                                <?php echo term_description(); ?>
                            </div>
                        </header>
                    <?php endif; ?>
                    
                    <?php
                    if ( have_posts() ) :
                        ?>
                        <div class="<?php echo esc_attr( $blog_wrapper_class ); ?>">
                            <div class="row">
                                <?php
                                /* Start the Loop */
                                while ( have_posts() ) :
                                    the_post();
                                    ?>
                                    <div class="<?php echo esc_attr( $column_class ); ?> mb-4">
                                        <?php get_template_part( 'template-parts/content', get_post_format() ); ?>
                                    </div>
                                    <?php
                                endwhile;
                                ?>
                            </div>
                        </div>

                        <div class="pagination-container">
                            <?php bella_italia_pagination(); ?>
                        </div>

                    <?php
                    else :
                        get_template_part( 'template-parts/content', 'none' );
                    endif;
                    ?>
                </div>
                
                <div class="col-lg-4">
                    <?php get_sidebar(); ?>
                </div>
            </div>
        </div>
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();