<?php
/**
 * Template Name: Home Page
 *
 * This is the template that displays the home page.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();
?>

<div id="primary" class="content-area full-width">
    <main id="main" class="site-main">
        <?php
        /**
         * Hook: bella_italia_home_before_content.
         */
        do_action( 'bella_italia_home_before_content' );
        ?>

        <!-- Hero Section -->
        <section class="hero-section">
            <div class="hero-container">
                <div class="hero-content">
                    <h1 class="hero-title"><?php esc_html_e( 'Discover Authentic Italian Experiences', 'bella-italia-journey' ); ?></h1>
                    <div class="hero-subtitle">
                        <?php esc_html_e( 'Your guide to exploring the real Italy through local food, hidden gems, and unforgettable adventures', 'bella-italia-journey' ); ?>
                    </div>
                    <div class="hero-buttons">
                        <a href="<?php echo esc_url( home_url( '/destinations/' ) ); ?>" class="btn btn-primary">
                            <?php esc_html_e( 'Explore Destinations', 'bella-italia-journey' ); ?>
                        </a>
                        <a href="<?php echo esc_url( home_url( '/about/' ) ); ?>" class="btn btn-outline btn-outline-white">
                            <?php esc_html_e( 'About Us', 'bella-italia-journey' ); ?>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Regions Navigation Section -->
        <section class="regions-section bg-light">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'Explore Italy by Region', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Discover unique experiences in each distinct part of Italy', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <div class="regions-container">
                    <div class="regions-grid grid grid-3">
                        <div class="region-card region-north">
                            <div class="region-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/regions/north-italy.jpg' ); ?>" alt="<?php esc_attr_e( 'Northern Italy', 'bella-italia-journey' ); ?>">
                                <div class="region-overlay">
                                    <a href="<?php echo esc_url( home_url( '/region/north/' ) ); ?>" class="region-link"></a>
                                </div>
                            </div>
                            <div class="region-content">
                                <h3 class="region-title"><?php esc_html_e( 'Northern Italy', 'bella-italia-journey' ); ?></h3>
                                <div class="region-description">
                                    <?php esc_html_e( 'Alpine lakes, historic cities, and culinary excellence', 'bella-italia-journey' ); ?>
                                </div>
                                <a href="<?php echo esc_url( home_url( '/region/north/' ) ); ?>" class="btn btn-outline btn-outline-green">
                                    <?php esc_html_e( 'Explore North', 'bella-italia-journey' ); ?>
                                </a>
                            </div>
                        </div>

                        <div class="region-card region-central">
                            <div class="region-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/regions/central-italy.jpg' ); ?>" alt="<?php esc_attr_e( 'Central Italy', 'bella-italia-journey' ); ?>">
                                <div class="region-overlay">
                                    <a href="<?php echo esc_url( home_url( '/region/central/' ) ); ?>" class="region-link"></a>
                                </div>
                            </div>
                            <div class="region-content">
                                <h3 class="region-title"><?php esc_html_e( 'Central Italy', 'bella-italia-journey' ); ?></h3>
                                <div class="region-description">
                                    <?php esc_html_e( 'Renaissance treasures, rolling hills, and ancient history', 'bella-italia-journey' ); ?>
                                </div>
                                <a href="<?php echo esc_url( home_url( '/region/central/' ) ); ?>" class="btn btn-outline btn-outline-white">
                                    <?php esc_html_e( 'Explore Center', 'bella-italia-journey' ); ?>
                                </a>
                            </div>
                        </div>

                        <div class="region-card region-south">
                            <div class="region-image">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/regions/south-italy.jpg' ); ?>" alt="<?php esc_attr_e( 'Southern Italy', 'bella-italia-journey' ); ?>">
                                <div class="region-overlay">
                                    <a href="<?php echo esc_url( home_url( '/region/south/' ) ); ?>" class="region-link"></a>
                                </div>
                            </div>
                            <div class="region-content">
                                <h3 class="region-title"><?php esc_html_e( 'Southern Italy', 'bella-italia-journey' ); ?></h3>
                                <div class="region-description">
                                    <?php esc_html_e( 'Coastal beauty, vibrant traditions, and authentic cuisine', 'bella-italia-journey' ); ?>
                                </div>
                                <a href="<?php echo esc_url( home_url( '/region/south/' ) ); ?>" class="btn btn-outline btn-outline-red">
                                    <?php esc_html_e( 'Explore South', 'bella-italia-journey' ); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Featured Destinations Section -->
        <section class="featured-destinations-section bg-white">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'Popular Destinations', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Discover our most beloved Italian destinations', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <?php echo do_shortcode( '[featured_destinations count="6"]' ); ?>

                <div class="section-footer text-center">
                    <a href="<?php echo esc_url( home_url( '/destinations/' ) ); ?>" class="btn btn-primary">
                        <?php esc_html_e( 'View All Destinations', 'bella-italia-journey' ); ?>
                    </a>
                </div>
            </div>
        </section>

        <!-- Interactive Map Section -->
        <section class="map-section bg-light-red">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'Explore Italy on the Map', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Click on regions to discover destinations', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <?php echo do_shortcode( '[italy_map]' ); ?>
            </div>
        </section>

        <!-- Travel Experience Section -->
        <section class="travel-experience-section bg-white">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'Authentic Italian Experiences', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Immerse yourself in genuine Italian culture', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <div class="experience-grid grid grid-3">
                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-utensils"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Local Food', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Discover authentic regional cuisines and culinary traditions that vary dramatically from north to south.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>

                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-wine-glass-alt"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Local Drink', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Sample exquisite local wines, artisanal spirits, and coffee culture unique to each Italian region.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>

                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-bed"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Accommodation', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Stay in charming agriturismi, historic palazzi, and boutique hotels that showcase Italian hospitality.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>

                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-mountain"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Must-See Places', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Visit breathtaking landmarks and hidden gems away from typical tourist routes.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>

                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-theater-masks"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Local Traditions', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Experience festivals, celebrations, and cultural events that reveal the heart of Italian heritage.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>

                    <div class="experience-card">
                        <div class="experience-icon">
                            <i class="fas fa-hiking"></i>
                        </div>
                        <h3 class="experience-title"><?php esc_html_e( 'Best Experiences', 'bella-italia-journey' ); ?></h3>
                        <div class="experience-content">
                            <p><?php esc_html_e( 'Participate in authentic activities from cooking classes to vineyard tours and artisan workshops.', 'bella-italia-journey' ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Blog Teaser Section -->
        <section class="blog-teaser-section bg-light-green">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'Travel Stories & Tips', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Read about our Italian adventures and insights', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <?php echo do_shortcode( '[blog_teaser count="3"]' ); ?>

                <div class="section-footer text-center">
                    <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="btn btn-primary">
                        <?php esc_html_e( 'Read More Articles', 'bella-italia-journey' ); ?>
                    </a>
                </div>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section class="testimonials-section bg-white">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title"><?php esc_html_e( 'What Travelers Say', 'bella-italia-journey' ); ?></h2>
                    <div class="section-description">
                        <?php esc_html_e( 'Read reviews from fellow travelers', 'bella-italia-journey' ); ?>
                    </div>
                </div>

                <?php echo do_shortcode( '[google_reviews count="3"]' ); ?>
            </div>
        </section>

        <!-- Newsletter Section -->
        <section class="newsletter-section bg-primary text-white">
            <div class="container">
                <div class="newsletter-container">
                    <div class="newsletter-content">
                        <h2 class="newsletter-title"><?php esc_html_e( 'Get Travel Inspiration', 'bella-italia-journey' ); ?></h2>
                        <p class="newsletter-description"><?php esc_html_e( 'Subscribe to receive our latest Italian travel tips, hidden gems, and exclusive offers', 'bella-italia-journey' ); ?></p>
                    </div>

                    <?php echo do_shortcode( '[newsletter_form]' ); ?>
                </div>
            </div>
        </section>

        <?php
        /**
         * Hook: bella_italia_home_after_content.
         */
        do_action( 'bella_italia_home_after_content' );
        ?>
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();