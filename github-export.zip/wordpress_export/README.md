# Bella Italia Journey - WordPress Theme

## Theme Description

Bella Italia Journey is a bilingual WordPress theme designed specifically for showcasing authentic Italian travel experiences. The theme features an Italian flag-inspired color scheme, three-region navigation system (North, Central, South), and responsive design optimized for travel blogs and destination websites.

## Features

- **Bilingual Support**: Built-in support for English and Slovenian languages
- **Region-Based Navigation**: Organize content by Italian regions (North, Central, South)
- **Custom Post Types**: Dedicated "Destinations" post type for travel locations
- **Interactive Italy Map**: Visual navigation through Italian regions
- **Italian Flag Color Scheme**: White, green, and red design elements throughout the theme
- **Mobile-Responsive Design**: Optimized for all device sizes
- **Custom Shortcodes**: Easy-to-use shortcodes for displaying content
- **Page Builder Compatible**: Works with popular page builders
- **SEO Optimized**: Built with best practices for search engines
- **Fast Performance**: Optimized code for quick loading times

## Installation

1. Upload the `bella-italia-journey` folder to the `/wp-content/themes/` directory
2. Activate the theme through the 'Themes' menu in WordPress
3. Go to Appearance → Customize to configure theme options
4. Set up a static front page using the 'Home Page' template

## Theme Structure

```
bella-italia-journey/
├── assets/
│   ├── css/              # Stylesheet files
│   ├── js/               # JavaScript files
│   ├── fonts/            # Custom fonts
│   └── images/           # Theme images
├── inc/
│   ├── customizer.php    # Theme customization options
│   ├── template-tags.php # Custom template tags
│   ├── template-functions.php # Theme functions
│   └── shortcodes.php    # Custom shortcodes
├── languages/            # Translation files
├── page-templates/       # Custom page templates
├── template-parts/       # Reusable template parts
├── functions.php         # Theme functions
├── header.php            # Theme header
├── footer.php            # Theme footer
├── style.css             # Main stylesheet
└── README.md             # Documentation
```

## Customization

### Theme Options

Navigate to Appearance → Customize to access the following theme options:

1. **Header Options**
   - Logo settings
   - Sticky header toggle
   - Contact information

2. **Footer Options**
   - Footer text
   - Copyright information
   - Footer widgets configuration

3. **Social Media**
   - Social media links
   - Display options

4. **Theme Colors**
   - Primary color (Green)
   - Secondary color (Red)
   - Background colors

5. **Integrations**
   - Google Maps API key
   - Google Analytics tracking

### Content Organization

The theme organizes content using the following structure:

1. **Destinations**
   - Custom post type for travel destinations
   - Organized by region taxonomy (North, Central, South, Islands)
   - Custom meta fields for location details

2. **Regions**
   - Taxonomy applied to both destinations and posts
   - Allows filtering content by Italian region
   - Featured in the interactive map

3. **Blog Posts**
   - Standard WordPress posts
   - Can be associated with regions
   - Featured in blog teaser sections

## Custom Shortcodes

The theme includes the following shortcodes:

1. `[featured_destinations count="3" region=""]`
   - Displays featured destinations in a grid
   - Optional parameters: count, region

2. `[google_reviews count="3"]`
   - Displays Google Reviews
   - Optional parameter: count

3. `[italy_map active_region=""]`
   - Displays interactive Italy map
   - Optional parameter: active_region

4. `[blog_teaser count="3" region=""]`
   - Displays latest blog posts
   - Optional parameters: count, region

5. `[contact_form]`
   - Displays contact form
   - No parameters needed

6. `[newsletter_form]`
   - Displays newsletter signup form
   - No parameters needed

## Language Support

The theme is fully translatable and includes both English and Slovenian translations. To modify translations:

1. Use Loco Translate or a similar plugin
2. Edit the .po files in the /languages/ directory
3. Alternatively, create a child theme with custom translations

### Adding Translations

The theme supports Polylang or WPML for multilingual content. If using these plugins:

1. Install and activate the language plugin
2. Set up the languages you want to support
3. Translate your content using the plugin's interface
4. The theme will automatically display language switchers

## Creating New Pages

### Home Page

1. Create a new page
2. Select the "Home Page" template
3. Set it as your front page in Settings → Reading

### Destinations Archive

The Destinations archive is automatically created with the custom post type. You can customize its appearance through the Customizer.

### Blog Page

1. Create a new page titled "Blog"
2. Set it as your posts page in Settings → Reading

## Recommended Plugins

- Contact Form 7 (for contact forms)
- Advanced Custom Fields (for extended functionality)
- Polylang or WPML (for multilingual support)
- Yoast SEO (for search engine optimization)
- WP Super Cache (for performance optimization)

## Support and Documentation

For additional support and documentation:

- Theme documentation: [https://bellaitalia-journey.com/docs](https://bellaitalia-journey.com/docs)
- Support forum: [https://bellaitalia-journey.com/support](https://bellaitalia-journey.com/support)
- Email support: info@bellaitalia-journey.com

## Credits

- Built with WordPress
- Based on Underscores starter theme
- Uses Font Awesome for icons
- Google Fonts: Montserrat and Playfair Display
- Demo photos from Unsplash and Pexels

## License

Bella Italia Journey WordPress Theme, Copyright 2023
Bella Italia Journey is distributed under the terms of the GNU GPL v2 or later.