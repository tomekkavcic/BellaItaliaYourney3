/**
 * Bella Italia Journey - Main JavaScript
 */
(function($) {
    'use strict';

    /**
     * Initialize all functions when DOM is ready
     */
    $(document).ready(function() {
        bellaItalia.init();
    });

    /**
     * Main object containing all functions
     */
    var bellaItalia = {
        /**
         * Initialize all functions
         */
        init: function() {
            this.mobileMenu();
            this.smoothScroll();
            this.stickyHeader();
            this.backToTop();
            this.regionFilters();
            this.stickyElements();
            this.initMap();
            this.newsletterForm();
            this.contactForm();
            this.lazyLoad();
        },

        /**
         * Mobile menu toggle
         */
        mobileMenu: function() {
            $('.menu-toggle').on('click', function(e) {
                e.preventDefault();
                $(this).toggleClass('active');
                $('.main-navigation').toggleClass('toggled');
                $('body').toggleClass('menu-open');
            });

            // Close menu when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('.main-navigation').length && !$(e.target).closest('.menu-toggle').length) {
                    $('.menu-toggle').removeClass('active');
                    $('.main-navigation').removeClass('toggled');
                    $('body').removeClass('menu-open');
                }
            });

            // Add dropdown toggles to menu items with children
            $('.menu-item-has-children > a').after('<button class="dropdown-toggle" aria-expanded="false"><i class="fas fa-chevron-down"></i></button>');

            // Toggle submenu visibility on mobile
            $('.dropdown-toggle').on('click', function(e) {
                e.preventDefault();
                $(this).toggleClass('active');
                $(this).next('.sub-menu').toggleClass('toggled');
                $(this).attr('aria-expanded', $(this).attr('aria-expanded') === 'false' ? 'true' : 'false');
            });
        },

        /**
         * Smooth scrolling for anchor links
         */
        smoothScroll: function() {
            $('a[href*="#"]:not([href="#"])').on('click', function() {
                if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
                    var target = $(this.hash);
                    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                    if (target.length) {
                        $('html, body').animate({
                            scrollTop: target.offset().top - 70 // Adjusted for header height
                        }, 800);
                        return false;
                    }
                }
            });
        },

        /**
         * Sticky header
         */
        stickyHeader: function() {
            if (typeof bellaItalia !== 'undefined' && bellaItalia.stickyHeader) {
                var header = $('.site-header'),
                    headerHeight = header.outerHeight(),
                    scrolled = false;

                $(window).on('scroll', function() {
                    var scrollTop = $(this).scrollTop();
                    
                    if (scrollTop > headerHeight && !scrolled) {
                        header.addClass('sticky');
                        $('body').css('padding-top', headerHeight);
                        scrolled = true;
                    } else if (scrollTop <= headerHeight && scrolled) {
                        header.removeClass('sticky');
                        $('body').css('padding-top', '0');
                        scrolled = false;
                    }
                });
            }
        },

        /**
         * Back to top button
         */
        backToTop: function() {
            var backToTop = $('#back-to-top');
            
            $(window).on('scroll', function() {
                if ($(this).scrollTop() > 300) {
                    backToTop.addClass('visible');
                } else {
                    backToTop.removeClass('visible');
                }
            });
            
            backToTop.on('click', function(e) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: 0
                }, 800);
            });
        },

        /**
         * Region filters for destination and blog archives
         */
        regionFilters: function() {
            $('.region-filter').on('click', function(e) {
                e.preventDefault();
                
                var $this = $(this),
                    region = $this.data('region'),
                    postType = $this.data('post-type') || 'destination',
                    $container = $('.archive-grid'),
                    nonce = bellaItalia.filterNonce;
                
                // Update active state
                $('.region-filter').removeClass('active');
                $this.addClass('active');
                
                // Show loading
                $container.addClass('loading');
                
                // AJAX request
                $.ajax({
                    url: bellaItalia.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'filter_by_region',
                        region: region,
                        post_type: postType,
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Update content
                            $container.html(response.data.html);
                            
                            // Update URL for browser history
                            if (response.data.url) {
                                window.history.pushState({}, '', response.data.url);
                            }
                            
                            // Reinitialize lazy loading
                            bellaItalia.lazyLoad();
                        }
                        
                        // Remove loading state
                        $container.removeClass('loading');
                    },
                    error: function() {
                        // Remove loading state
                        $container.removeClass('loading');
                        console.log('Error filtering by region');
                    }
                });
            });
        },

        /**
         * Sticky elements for sidebars
         */
        stickyElements: function() {
            if ($(window).width() > 992) {
                $('.sticky-sidebar').stick_in_parent({
                    offset_top: 100
                });
            }
        },

        /**
         * Initialize Google Map or map placeholder
         */
        initMap: function() {
            // Handle interactive Italy map
            $('.italy-interactive-map area[data-region]').on('click', function(e) {
                var region = $(this).data('region');
                
                // Update active state
                $('.region-option').removeClass('active');
                $('.region-option[data-region="' + region + '"]').addClass('active');
                
                // Show corresponding region details
                $('.region-detail').removeClass('active');
                $('#region-' + region).addClass('active');
                
                // Highlight map region
                $('.map-region').removeClass('active');
                $('.map-region[data-region="' + region + '"]').addClass('active');
            });
            
            // Handle region selector
            $('.region-option').on('click', function(e) {
                if ($(this).hasClass('region-selector-only')) {
                    e.preventDefault();
                    
                    var region = $(this).data('region');
                    
                    // Update active state
                    $('.region-option').removeClass('active');
                    $(this).addClass('active');
                    
                    // Show corresponding region details
                    $('.region-detail').removeClass('active');
                    $('#region-' + region).addClass('active');
                    
                    // Highlight map region
                    $('.map-region').removeClass('active');
                    $('.map-region[data-region="' + region + '"]').addClass('active');
                }
            });
            
            // Google Maps for destination single pages
            var $map = $('#destination-map');
            if ($map.length) {
                var coordinates = $map.data('coordinates');
                
                if (coordinates && coordinates.indexOf(',') !== -1) {
                    var coordsArray = coordinates.split(','),
                        lat = parseFloat(coordsArray[0].trim()),
                        lng = parseFloat(coordsArray[1].trim()),
                        title = $map.data('title');
                    
                    if (!isNaN(lat) && !isNaN(lng)) {
                        if (typeof google !== 'undefined' && typeof google.maps !== 'undefined') {
                            var mapOptions = {
                                center: { lat: lat, lng: lng },
                                zoom: 12,
                                mapTypeId: google.maps.MapTypeId.ROADMAP,
                                scrollwheel: false
                            };
                            
                            var map = new google.maps.Map($map[0], mapOptions);
                            
                            var marker = new google.maps.Marker({
                                position: { lat: lat, lng: lng },
                                map: map,
                                title: title
                            });
                        } else {
                            $map.html('<div class="map-placeholder"><p>' + 
                                '<i class="fas fa-map-marker-alt"></i> ' + 
                                title + 
                                '<br><small>(' + lat + ', ' + lng + ')</small></p>' + 
                                '<a href="https://maps.google.com/maps?q=' + lat + ',' + lng + '" target="_blank" class="btn btn-sm btn-outline-primary">View on Google Maps</a>' + 
                                '</div>');
                        }
                    }
                }
            }
        },
        
        /**
         * Newsletter form handling
         */
        newsletterForm: function() {
            $('.newsletter-form').on('submit', function(e) {
                // Form validation handled by WordPress
            });
        },
        
        /**
         * Contact form handling
         */
        contactForm: function() {
            // Check for form status messages
            var urlParams = new URLSearchParams(window.location.search);
            var contactStatus = urlParams.get('contact');
            
            if (contactStatus === 'success') {
                $('.contact-form-container').prepend('<div class="alert alert-success">' + 
                    '<i class="fas fa-check-circle"></i> ' + 
                    'Thank you for your message. We will get back to you soon.' + 
                    '</div>');
            } else if (contactStatus === 'error') {
                $('.contact-form-container').prepend('<div class="alert alert-danger">' + 
                    '<i class="fas fa-exclamation-circle"></i> ' + 
                    'There was a problem sending your message. Please try again later.' + 
                    '</div>');
            }
            
            // Form validation handled by WordPress
        },
        
        /**
         * Lazy loading for images
         */
        lazyLoad: function() {
            var lazyImages = [].slice.call(document.querySelectorAll('img[data-src]'));
            
            if ('IntersectionObserver' in window) {
                var lazyImageObserver = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            var lazyImage = entry.target;
                            lazyImage.src = lazyImage.dataset.src;
                            if (lazyImage.dataset.srcset) {
                                lazyImage.srcset = lazyImage.dataset.srcset;
                            }
                            lazyImage.classList.add('loaded');
                            lazyImageObserver.unobserve(lazyImage);
                        }
                    });
                });
                
                lazyImages.forEach(function(lazyImage) {
                    lazyImageObserver.observe(lazyImage);
                });
            } else {
                // Fallback for browsers without IntersectionObserver support
                var active = false;
                
                var lazyLoad = function() {
                    if (active === false) {
                        active = true;
                        
                        setTimeout(function() {
                            lazyImages.forEach(function(lazyImage) {
                                if ((lazyImage.getBoundingClientRect().top <= window.innerHeight && lazyImage.getBoundingClientRect().bottom >= 0) && getComputedStyle(lazyImage).display !== 'none') {
                                    lazyImage.src = lazyImage.dataset.src;
                                    if (lazyImage.dataset.srcset) {
                                        lazyImage.srcset = lazyImage.dataset.srcset;
                                    }
                                    lazyImage.classList.add('loaded');
                                    
                                    lazyImages = lazyImages.filter(function(image) {
                                        return image !== lazyImage;
                                    });
                                    
                                    if (lazyImages.length === 0) {
                                        document.removeEventListener('scroll', lazyLoad);
                                        window.removeEventListener('resize', lazyLoad);
                                        window.removeEventListener('orientationchange', lazyLoad);
                                    }
                                }
                            });
                            
                            active = false;
                        }, 200);
                    }
                };
                
                document.addEventListener('scroll', lazyLoad);
                window.addEventListener('resize', lazyLoad);
                window.addEventListener('orientationchange', lazyLoad);
                lazyLoad();
            }
        }
    };

})(jQuery);