<?php
/**
 * The template for displaying single destination posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();

// Get customizer options
$layout = get_theme_mod( 'bella_italia_destination_layout', 'standard' );
$show_map = get_theme_mod( 'bella_italia_destination_show_map', true );
$enable_image_gallery = get_theme_mod( 'bella_italia_destination_enable_gallery', true );

// Additional destination metadata for the Google Map
$location = get_post_meta( get_the_ID(), '_destination_location', true );
$lat = get_post_meta( get_the_ID(), '_destination_map_lat', true );
$lng = get_post_meta( get_the_ID(), '_destination_map_lng', true );
$map_zoom = get_post_meta( get_the_ID(), '_destination_map_zoom', true );
if ( empty( $map_zoom ) ) {
    $map_zoom = 13; // Default zoom level
}

// Get gallery images
$gallery_images = array();
if ( $enable_image_gallery ) {
    $gallery = get_post_meta( get_the_ID(), '_destination_gallery', true );
    if ( ! empty( $gallery ) ) {
        $gallery_images = explode( ',', $gallery );
    }
}

// Layout specific classes
$content_class = 'col-lg-8';
$sidebar_class = 'col-lg-4';

if ( $layout === 'full-width' ) {
    $content_class = 'col-12';
    $show_sidebar = false;
} else {
    $show_sidebar = is_active_sidebar( 'sidebar-destinations' );
}

// Get if sidebar position from customizer
$sidebar_position = get_theme_mod( 'bella_italia_sidebar_position', 'right' );
$content_order = ( $sidebar_position === 'left' && $show_sidebar ) ? 'order-lg-2' : '';
$sidebar_order = ( $sidebar_position === 'left' && $show_sidebar ) ? 'order-lg-1' : '';
?>

<div id="primary" class="content-area py-5">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <div class="<?php echo esc_attr( $content_class . ' ' . $content_order ); ?>">
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        
                        get_template_part( 'template-parts/content', 'destination' );
                        
                        // Show map if enabled
                        if ( $show_map && ! empty( $lat ) && ! empty( $lng ) ) :
                            ?>
                            <div class="destination-map-section">
                                <h2><?php _e( 'Location', 'bella-italia-journey' ); ?></h2>
                                <div id="destination-map" class="destination-map" data-lat="<?php echo esc_attr( $lat ); ?>" data-lng="<?php echo esc_attr( $lng ); ?>" data-zoom="<?php echo esc_attr( $map_zoom ); ?>" data-title="<?php the_title_attribute(); ?>"></div>
                                
                                <?php if ( $location ) : ?>
                                <div class="destination-address mt-3">
                                    <i class="fa fa-map-marker"></i> <?php echo esc_html( $location ); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <script>
                                function initDestinationMap() {
                                    const mapElement = document.getElementById('destination-map');
                                    if (!mapElement) return;
                                    
                                    const lat = parseFloat(mapElement.getAttribute('data-lat'));
                                    const lng = parseFloat(mapElement.getAttribute('data-lng'));
                                    const zoom = parseInt(mapElement.getAttribute('data-zoom'));
                                    const title = mapElement.getAttribute('data-title');
                                    
                                    if (isNaN(lat) || isNaN(lng)) return;
                                    
                                    const position = { lat, lng };
                                    const map = new google.maps.Map(mapElement, {
                                        zoom: zoom,
                                        center: position
                                    });
                                    
                                    const marker = new google.maps.Marker({
                                        position: position,
                                        map: map,
                                        title: title
                                    });
                                }
                            </script>
                            
                            <?php 
                            // Get Google Maps API key from theme options
                            $google_maps_api_key = get_theme_mod( 'bella_italia_google_maps_api_key' );
                            
                            if ( $google_maps_api_key ) :
                                ?>
                                <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr( $google_maps_api_key ); ?>&callback=initDestinationMap" async defer></script>
                                <?php
                            else :
                                // Fallback if no API key is set
                                ?>
                                <div class="alert alert-warning">
                                    <?php 
                                    if ( current_user_can( 'manage_options' ) ) {
                                        _e( 'Google Maps API key is missing. Please add it in Theme Options.', 'bella-italia-journey' );
                                    } else {
                                        _e( 'Map is temporarily unavailable.', 'bella-italia-journey' );
                                    }
                                    ?>
                                </div>
                                <?php
                            endif;
                        endif;
                        
                        // Show gallery if enabled and has images
                        if ( $enable_image_gallery && ! empty( $gallery_images ) ) :
                            ?>
                            <div class="destination-gallery-section">
                                <h2><?php _e( 'Photo Gallery', 'bella-italia-journey' ); ?></h2>
                                <div class="destination-gallery">
                                    <div class="row">
                                        <?php
                                        foreach ( $gallery_images as $image_id ) :
                                            $full_img_url = wp_get_attachment_image_url( $image_id, 'full' );
                                            $image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
                                            if ( empty( $image_alt ) ) {
                                                $image_alt = get_the_title();
                                            }
                                            ?>
                                            <div class="col-md-4 col-sm-6 mb-4">
                                                <a href="<?php echo esc_url( $full_img_url ); ?>" class="gallery-item" data-lightbox="destination-gallery" data-title="<?php echo esc_attr( $image_alt ); ?>">
                                                    <?php echo wp_get_attachment_image( $image_id, 'medium', false, array( 'class' => 'img-fluid rounded' ) ); ?>
                                                </a>
                                            </div>
                                            <?php
                                        endforeach;
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endif;
                        
                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) :
                            comments_template();
                        endif;
                        
                    endwhile; // End of the loop.
                    ?>
                </div>
                
                <?php if ( $show_sidebar ) : ?>
                <div class="<?php echo esc_attr( $sidebar_class . ' ' . $sidebar_order ); ?>">
                    <?php get_sidebar(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();