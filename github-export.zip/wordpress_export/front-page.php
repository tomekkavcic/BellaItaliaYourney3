<?php
/**
 * The template for displaying the front page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        
        <?php
        // Featured Destinations Section
        get_template_part( 'template-parts/sections/featured-destinations' );
        
        // About Italy Section
        get_template_part( 'template-parts/sections/about-italy' );
        
        // Region Highlights
        get_template_part( 'template-parts/sections/region-highlights' );
        
        // Latest Blog Posts
        get_template_part( 'template-parts/sections/latest-posts' );
        
        // Testimonials
        get_template_part( 'template-parts/sections/testimonials' );
        
        // Newsletter
        get_template_part( 'template-parts/sections/newsletter' );
        
        // Regular page content if needed
        while ( have_posts() ) :
            the_post();
            
            // If page has content, display it
            if ( trim( get_the_content() ) !== '' ) :
            ?>
            <div class="page-content-section py-5">
                <div class="container">
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
            <?php
            endif;
            
        endwhile;
        ?>

    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();