<?php
/**
 * Custom hooks for Bella Italia Journey theme
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Add actions and filters for theme customization
 */

/**
 * Hook: bella_italia_before_header
 * Fires before the header content is displayed.
 */
function bella_italia_do_before_header() {
    do_action( 'bella_italia_before_header' );
}

/**
 * Hook: bella_italia_after_header
 * Fires after the header content is displayed.
 */
function bella_italia_do_after_header() {
    do_action( 'bella_italia_after_header' );
}

/**
 * Hook: bella_italia_before_content
 * Fires before the main content area.
 */
function bella_italia_do_before_content() {
    do_action( 'bella_italia_before_content' );
}

/**
 * Hook: bella_italia_after_content
 * Fires after the main content area.
 */
function bella_italia_do_after_content() {
    do_action( 'bella_italia_after_content' );
}

/**
 * Hook: bella_italia_before_footer
 * Fires before the footer content is displayed.
 */
function bella_italia_do_before_footer() {
    do_action( 'bella_italia_before_footer' );
}

/**
 * Hook: bella_italia_after_footer
 * Fires after the footer content is displayed.
 */
function bella_italia_do_after_footer() {
    do_action( 'bella_italia_after_footer' );
}

/**
 * Hook: bella_italia_before_destination_content
 * Fires before the destination content is displayed.
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_before_destination_content( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_before_destination_content', $post_id );
}

/**
 * Hook: bella_italia_after_destination_content
 * Fires after the destination content is displayed.
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_after_destination_content( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_after_destination_content', $post_id );
}

/**
 * Hook: bella_italia_destination_meta
 * Adds additional destination meta information.
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_destination_meta( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_destination_meta', $post_id );
}

/**
 * Hook: bella_italia_destination_features
 * Displays the destination features (pillars).
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_destination_features( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_destination_features', $post_id );
}

/**
 * Hook: bella_italia_destination_map
 * Displays the destination map.
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_destination_map( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_destination_map', $post_id );
}

/**
 * Hook: bella_italia_destination_related
 * Displays related destinations.
 * 
 * @param int $post_id The destination post ID.
 */
function bella_italia_do_destination_related( $post_id = 0 ) {
    if ( ! $post_id ) {
        $post_id = get_the_ID();
    }
    do_action( 'bella_italia_destination_related', $post_id );
}

/**
 * Default implementations
 */

/**
 * Add 'Read more' link to excerpts
 */
function bella_italia_excerpt_more( $more ) {
    if ( is_admin() ) {
        return $more;
    }
    
    $more_text = get_theme_mod( 'bella_italia_read_more_text', __( 'Read more', 'bella-italia-journey' ) );
    
    return sprintf( '... <a class="read-more-link" href="%s">%s <i class="fa fa-angle-right"></i></a>',
        esc_url( get_permalink() ),
        esc_html( $more_text )
    );
}
add_filter( 'excerpt_more', 'bella_italia_excerpt_more' );

/**
 * Add Italy map to the hero area on front page
 */
function bella_italia_add_map_to_hero() {
    if ( is_front_page() && get_theme_mod( 'bella_italia_hero_enable_map', true ) ) {
        get_template_part( 'template-parts/italy-map', null, array(
            'map_style' => 'simple',
            'show_pins' => false,
            'map_classes' => 'hero-map',
            'show_legend' => true,
        ) );
    }
}
add_action( 'bella_italia_after_header', 'bella_italia_add_map_to_hero' );

/**
 * Display destination features pillars
 */
function bella_italia_display_destination_features( $post_id ) {
    if ( ! $post_id ) {
        return;
    }
    
    // Get the five pillars data
    $local_food = get_post_meta( $post_id, '_destination_local_food', true );
    $local_drink = get_post_meta( $post_id, '_destination_local_drink', true );
    $accommodation = get_post_meta( $post_id, '_destination_accommodation', true );
    $must_see = get_post_meta( $post_id, '_destination_must_see', true );
    $best_experience = get_post_meta( $post_id, '_destination_best_experience', true );
    
    // Only display if at least one pillar has content
    if ( ! $local_food && ! $local_drink && ! $accommodation && ! $must_see && ! $best_experience ) {
        return;
    }
    
    // Display features
    ?>
    <div class="destination-features-wrapper">
        <h2 class="section-title text-center"><?php _e( 'Discover Local Experiences', 'bella-italia-journey' ); ?></h2>
        
        <div class="destination-pillars">
            <div class="container">
                <div class="row">
                    <?php if ( $local_food ) : ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="pillar-card h-100">
                                <div class="pillar-icon">
                                    <i class="fa fa-utensils"></i>
                                </div>
                                <h3 class="pillar-title"><?php _e( 'Local Food', 'bella-italia-journey' ); ?></h3>
                                <div class="pillar-content">
                                    <?php echo wpautop( $local_food ); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ( $local_drink ) : ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="pillar-card h-100">
                                <div class="pillar-icon">
                                    <i class="fa fa-wine-glass"></i>
                                </div>
                                <h3 class="pillar-title"><?php _e( 'Local Drink', 'bella-italia-journey' ); ?></h3>
                                <div class="pillar-content">
                                    <?php echo wpautop( $local_drink ); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ( $accommodation ) : ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="pillar-card h-100">
                                <div class="pillar-icon">
                                    <i class="fa fa-bed"></i>
                                </div>
                                <h3 class="pillar-title"><?php _e( 'Accommodation', 'bella-italia-journey' ); ?></h3>
                                <div class="pillar-content">
                                    <?php echo wpautop( $accommodation ); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ( $must_see ) : ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="pillar-card h-100">
                                <div class="pillar-icon">
                                    <i class="fa fa-eye"></i>
                                </div>
                                <h3 class="pillar-title"><?php _e( 'Must See', 'bella-italia-journey' ); ?></h3>
                                <div class="pillar-content">
                                    <?php echo wpautop( $must_see ); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ( $best_experience ) : ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="pillar-card h-100">
                                <div class="pillar-icon">
                                    <i class="fa fa-star"></i>
                                </div>
                                <h3 class="pillar-title"><?php _e( 'Best Experience', 'bella-italia-journey' ); ?></h3>
                                <div class="pillar-content">
                                    <?php echo wpautop( $best_experience ); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'bella_italia_destination_features', 'bella_italia_display_destination_features' );

/**
 * Display destination map
 */
function bella_italia_display_destination_map( $post_id ) {
    if ( ! $post_id || ! get_theme_mod( 'bella_italia_destination_show_map', true ) ) {
        return;
    }
    
    // Get map coordinates
    $map_lat = get_post_meta( $post_id, '_destination_map_lat', true );
    $map_lng = get_post_meta( $post_id, '_destination_map_lng', true );
    $map_zoom = get_post_meta( $post_id, '_destination_map_zoom', true ) ? get_post_meta( $post_id, '_destination_map_zoom', true ) : '10';
    
    // Only display if coordinates are set
    if ( ! $map_lat || ! $map_lng ) {
        return;
    }
    
    // Get API key
    $google_maps_api_key = get_theme_mod( 'bella_italia_google_maps_api_key', '' );
    
    if ( ! $google_maps_api_key ) {
        return;
    }
    
    // Display map
    ?>
    <div class="destination-map-wrapper">
        <h2 class="section-title text-center"><?php _e( 'Location', 'bella-italia-journey' ); ?></h2>
        
        <div class="destination-map" id="destination-map" data-lat="<?php echo esc_attr( $map_lat ); ?>" data-lng="<?php echo esc_attr( $map_lng ); ?>" data-zoom="<?php echo esc_attr( $map_zoom ); ?>" data-title="<?php echo esc_attr( get_the_title( $post_id ) ); ?>"></div>
        
        <?php 
        // Get location info
        $location = get_post_meta( $post_id, '_destination_location', true );
        
        if ( $location ) : 
        ?>
            <div class="destination-location-info text-center mt-3">
                <p><i class="fa fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}
add_action( 'bella_italia_destination_map', 'bella_italia_display_destination_map' );

/**
 * Display related destinations
 */
function bella_italia_display_related_destinations( $post_id ) {
    if ( ! $post_id || ! get_theme_mod( 'bella_italia_show_related_destinations', true ) ) {
        return;
    }
    
    // Get related destinations
    $related_count = get_theme_mod( 'bella_italia_related_destinations_count', 3 );
    $related_destinations = bella_italia_get_related_posts( $post_id, $related_count, array(
        'post_type' => 'destination',
    ) );
    
    if ( ! $related_destinations->have_posts() ) {
        return;
    }
    
    // Display related destinations
    ?>
    <div class="related-destinations-wrapper">
        <h2 class="section-title text-center"><?php _e( 'Explore Nearby', 'bella-italia-journey' ); ?></h2>
        
        <div class="related-destinations">
            <div class="container">
                <div class="row">
                    <?php while ( $related_destinations->have_posts() ) : $related_destinations->the_post(); ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="related-destination-card h-100">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <div class="related-destination-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail( 'bella-italia-card', array( 'class' => 'img-fluid' ) ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="related-destination-content">
                                    <h3 class="related-destination-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h3>
                                    
                                    <?php 
                                    // Get location
                                    $location = get_post_meta( get_the_ID(), '_destination_location', true );
                                    
                                    if ( $location ) : 
                                    ?>
                                        <div class="related-destination-location">
                                            <i class="fa fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="related-destination-excerpt">
                                        <?php the_excerpt(); ?>
                                    </div>
                                    
                                    <a href="<?php the_permalink(); ?>" class="btn btn-sm btn-outline-primary"><?php _e( 'Explore', 'bella-italia-journey' ); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    
    wp_reset_postdata();
}
add_action( 'bella_italia_destination_related', 'bella_italia_display_related_destinations' );

/**
 * Add newsletter section to the footer
 */
function bella_italia_add_newsletter_to_footer() {
    if ( is_front_page() || get_theme_mod( 'bella_italia_show_footer_newsletter', false ) ) {
        get_template_part( 'template-parts/sections/newsletter' );
    }
}
add_action( 'bella_italia_before_footer', 'bella_italia_add_newsletter_to_footer' );

/**
 * Add back to top button
 */
function bella_italia_add_back_to_top() {
    if ( get_theme_mod( 'bella_italia_show_back_to_top', true ) ) {
        echo '<a href="#" id="back-to-top" class="back-to-top-button" title="' . esc_attr__( 'Back to top', 'bella-italia-journey' ) . '"><i class="fa fa-chevron-up"></i></a>';
    }
}
add_action( 'bella_italia_after_footer', 'bella_italia_add_back_to_top' );

/**
 * Add floating contact button
 */
function bella_italia_add_floating_contact() {
    if ( get_theme_mod( 'bella_italia_show_floating_contact', true ) ) {
        echo '<a href="' . esc_url( get_permalink( get_page_by_path( 'contact' ) ) ) . '" id="floating-contact" class="floating-contact-button" title="' . esc_attr__( 'Contact us', 'bella-italia-journey' ) . '"><i class="fa fa-envelope"></i></a>';
    }
}
add_action( 'bella_italia_after_footer', 'bella_italia_add_floating_contact' );

/**
 * Add content before and after post content
 */
function bella_italia_before_post_content() {
    if ( is_singular( 'post' ) ) {
        // Post meta
        echo '<div class="entry-meta post-meta">';
        bella_italia_posted_on();
        bella_italia_posted_by();
        echo '</div>';
    }
}
add_action( 'bella_italia_before_content', 'bella_italia_before_post_content' );

/**
 * Add content after post content
 */
function bella_italia_after_post_content() {
    if ( is_singular( 'post' ) ) {
        // Post footer
        echo '<footer class="entry-footer">';
        bella_italia_entry_footer();
        echo '</footer>';
        
        // Author box
        if ( get_theme_mod( 'bella_italia_show_author_box', true ) ) {
            get_template_part( 'template-parts/author-bio' );
        }
        
        // Post navigation
        if ( get_theme_mod( 'bella_italia_show_post_nav', true ) ) {
            the_post_navigation(
                array(
                    'prev_text' => '<span class="nav-subtitle"><i class="fa fa-angle-left"></i> ' . esc_html__( 'Previous:', 'bella-italia-journey' ) . '</span> <span class="nav-title">%title</span>',
                    'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'bella-italia-journey' ) . ' <i class="fa fa-angle-right"></i></span> <span class="nav-title">%title</span>',
                )
            );
        }
        
        // Related posts
        if ( get_theme_mod( 'bella_italia_show_related_posts', true ) ) {
            get_template_part( 'template-parts/related-posts' );
        }
    }
}
add_action( 'bella_italia_after_content', 'bella_italia_after_post_content' );

/**
 * Add destination content
 */
function bella_italia_destination_content() {
    if ( is_singular( 'destination' ) ) {
        // Display destination features
        bella_italia_do_destination_features( get_the_ID() );
        
        // Display destination map
        bella_italia_do_destination_map( get_the_ID() );
        
        // Display related destinations
        bella_italia_do_destination_related( get_the_ID() );
    }
}
add_action( 'bella_italia_after_content', 'bella_italia_destination_content' );