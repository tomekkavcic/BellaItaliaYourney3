<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
 * <?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses bella_italia_header_style()
 */
function bella_italia_custom_header_setup() {
    add_theme_support(
        'custom-header',
        apply_filters(
            'bella_italia_custom_header_args',
            array(
                'default-image'      => get_template_directory_uri() . '/assets/images/header-background.jpg',
                'default-text-color' => 'ffffff',
                'width'              => 1920,
                'height'             => 500,
                'flex-height'        => true,
                'wp-head-callback'   => 'bella_italia_header_style',
            )
        )
    );
}
add_action( 'after_setup_theme', 'bella_italia_custom_header_setup' );

if ( ! function_exists( 'bella_italia_header_style' ) ) :
    /**
     * Styles the header image and text displayed on the blog.
     *
     * @see bella_italia_custom_header_setup().
     */
    function bella_italia_header_style() {
        $header_text_color = get_header_textcolor();

        /*
         * If no custom options for text are set, let's bail.
         * get_header_textcolor() options: Any hex value, 'blank' to hide text. Default: add_theme_support( 'custom-header' ).
         */
        if ( get_theme_support( 'custom-header', 'default-text-color' ) === $header_text_color ) {
            return;
        }

        // If we get this far, we have custom styles. Let's do this.
        ?>
        <style type="text/css">
        <?php
        // Has the text been hidden?
        if ( ! display_header_text() ) :
            ?>
            .site-title,
            .site-description {
                position: absolute;
                clip: rect(1px, 1px, 1px, 1px);
                }
            <?php
            // If the user has set a custom color for the text use that.
        else :
            ?>
            .site-title a,
            .site-description {
                color: #<?php echo esc_attr( $header_text_color ); ?>;
            }
        <?php endif; ?>
        </style>
        <?php
    }
endif;

/**
 * Filter the custom header arguments to add parallax support
 */
function bella_italia_filter_custom_header_args( $args ) {
    // Check if parallax effect is enabled in customizer
    $enable_parallax = get_theme_mod( 'bella_italia_enable_header_parallax', true );
    
    if ( $enable_parallax ) {
        $args['video'] = true; // Enable video support which also enhances image handling
    }
    
    return $args;
}
add_filter( 'bella_italia_custom_header_args', 'bella_italia_filter_custom_header_args' );

/**
 * Add dynamic header styles based on customizer settings
 */
function bella_italia_custom_header_css() {
    $header_style = get_theme_mod( 'bella_italia_header_style', 'default' );
    $header_height = get_theme_mod( 'bella_italia_header_height', 500 );
    $header_overlay_opacity = get_theme_mod( 'bella_italia_header_overlay_opacity', 0.5 );
    
    // Get header image
    $header_image = get_header_image();
    
    if ( empty( $header_image ) && $header_style === 'transparent' ) {
        // If no header image and transparent style, adjust styles
        ?>
        <style type="text/css">
            .site-header.transparent-header {
                background-color: rgba(0, 0, 0, 0.8);
            }
        </style>
        <?php
        return;
    }
    
    if ( ! empty( $header_image ) ) {
        ?>
        <style type="text/css">
            .custom-header {
                height: <?php echo esc_attr( $header_height ); ?>px;
                background-image: url(<?php echo esc_url( $header_image ); ?>);
                background-size: cover;
                background-position: center center;
                <?php if ( get_theme_mod( 'bella_italia_enable_header_parallax', true ) ) : ?>
                background-attachment: fixed;
                <?php endif; ?>
                position: relative;
            }
            
            .custom-header-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0, 0, 0, <?php echo esc_attr( $header_overlay_opacity ); ?>);
            }
            
            <?php if ( $header_style === 'transparent' ) : ?>
            .site-header.transparent-header {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                z-index: 100;
                background-color: rgba(0, 0, 0, 0.3);
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            }
            
            .site-header.transparent-header .site-title a,
            .site-header.transparent-header .site-description,
            .site-header.transparent-header .primary-menu > li > a {
                color: #fff;
            }
            
            .site-header.transparent-header .primary-menu > li:hover > a {
                color: rgba(255, 255, 255, 0.8);
            }
            <?php endif; ?>
            
            <?php if ( $header_style === 'centered' ) : ?>
            .site-header.centered-header .site-branding {
                text-align: center;
                float: none;
                margin: 0 auto 20px;
            }
            
            .site-header.centered-header .primary-menu-container {
                text-align: center;
                float: none;
            }
            
            .site-header.centered-header .primary-menu {
                display: inline-block;
            }
            <?php endif; ?>
        </style>
        <?php
    }
}
add_action( 'wp_head', 'bella_italia_custom_header_css' );

/**
 * Output the header video HTML
 */
function bella_italia_header_video() {
    if ( ! has_header_video() ) {
        return;
    }
    
    // Check if we're on a page that should display the header video
    if ( ! is_front_page() && ! is_home() && ! is_page_template( 'template-parts/page-with-header-media.php' ) ) {
        return;
    }
    
    // Get the video
    $video_url = get_header_video_url();
    
    if ( empty( $video_url ) ) {
        return;
    }
    
    // Output the video
    ?>
    <div class="header-video-container">
        <video autoplay muted loop playsinline id="header-video">
            <source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
        </video>
        <div class="header-video-overlay"></div>
    </div>
    
    <style>
        .header-video-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 1;
        }
        
        #header-video {
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        .header-video-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, <?php echo esc_attr( get_theme_mod( 'bella_italia_header_overlay_opacity', 0.5 ) ); ?>);
        }
        
        .custom-header-content {
            position: relative;
            z-index: 2;
        }
    </style>
    <?php
}

/**
 * Check if the current page should display the custom header media
 */
function bella_italia_has_header_media() {
    // Always show on front page
    if ( is_front_page() ) {
        return true;
    }
    
    // Show on the blog page
    if ( is_home() ) {
        return true;
    }
    
    // Show on pages with featured images or using template with header media
    if ( is_page() && ( has_post_thumbnail() || is_page_template( 'template-parts/page-with-header-media.php' ) ) ) {
        return true;
    }
    
    // Show on destination archives and single destinations
    if ( is_post_type_archive( 'destination' ) || is_tax( 'region' ) || is_singular( 'destination' ) ) {
        return true;
    }
    
    return false;
}

/**
 * Display custom header content
 */
function bella_italia_header_content() {
    // Only display on specific pages
    if ( ! bella_italia_has_header_media() ) {
        return;
    }
    
    // Front page
    if ( is_front_page() ) {
        $title = get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) );
        $subtitle = get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ) );
        $cta_text = get_theme_mod( 'bella_italia_hero_cta_text', __( 'Explore Destinations', 'bella-italia-journey' ) );
        $cta_url = get_theme_mod( 'bella_italia_hero_cta_url', '' );
        
        if ( empty( $cta_url ) ) {
            $cta_url = get_post_type_archive_link( 'destination' );
        }
        
        ?>
        <div class="custom-header-content hero-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center">
                        <?php if ( $title ) : ?>
                            <h1 class="hero-title"><?php echo esc_html( $title ); ?></h1>
                        <?php endif; ?>
                        
                        <?php if ( $subtitle ) : ?>
                            <p class="hero-subtitle"><?php echo esc_html( $subtitle ); ?></p>
                        <?php endif; ?>
                        
                        <?php if ( $cta_text && $cta_url ) : ?>
                            <div class="hero-cta">
                                <a href="<?php echo esc_url( $cta_url ); ?>" class="btn btn-primary btn-lg"><?php echo esc_html( $cta_text ); ?></a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ( get_theme_mod( 'bella_italia_hero_enable_search', true ) ) : ?>
                            <div class="hero-search mt-4">
                                <?php get_search_form(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    } 
    // Blog page
    elseif ( is_home() ) {
        ?>
        <div class="custom-header-content blog-header-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h1 class="page-title"><?php echo esc_html( get_the_title( get_option( 'page_for_posts' ) ) ); ?></h1>
                        <?php 
                        $blog_page_id = get_option( 'page_for_posts' );
                        if ( $blog_page_id ) {
                            $blog_page = get_post( $blog_page_id );
                            if ( $blog_page && ! empty( $blog_page->post_excerpt ) ) {
                                echo '<p class="page-description">' . esc_html( $blog_page->post_excerpt ) . '</p>';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    // Destination archive
    elseif ( is_post_type_archive( 'destination' ) ) {
        ?>
        <div class="custom-header-content archive-header-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h1 class="page-title"><?php post_type_archive_title(); ?></h1>
                        <?php the_archive_description( '<p class="archive-description">', '</p>' ); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    // Region taxonomy
    elseif ( is_tax( 'region' ) ) {
        ?>
        <div class="custom-header-content taxonomy-header-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h1 class="page-title"><?php single_term_title(); ?></h1>
                        <?php the_archive_description( '<p class="archive-description">', '</p>' ); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    // Single destination
    elseif ( is_singular( 'destination' ) ) {
        ?>
        <div class="custom-header-content destination-header-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h1 class="entry-title"><?php the_title(); ?></h1>
                        <?php 
                        $location = get_post_meta( get_the_ID(), '_destination_location', true );
                        if ( $location ) {
                            echo '<p class="destination-location"><i class="fa fa-map-marker-alt"></i> ' . esc_html( $location ) . '</p>';
                        }
                        
                        // Get regions
                        $regions = get_the_terms( get_the_ID(), 'region' );
                        if ( $regions && ! is_wp_error( $regions ) ) {
                            echo '<div class="destination-regions">';
                            foreach ( $regions as $region ) {
                                echo '<a href="' . esc_url( get_term_link( $region ) ) . '" class="destination-region-link">' . esc_html( $region->name ) . '</a>';
                            }
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    // Page
    elseif ( is_page() ) {
        ?>
        <div class="custom-header-content page-header-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 mx-auto text-center">
                        <h1 class="page-title"><?php the_title(); ?></h1>
                        <?php 
                        if ( has_excerpt() ) {
                            echo '<p class="page-description">' . get_the_excerpt() . '</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

/**
 * Register and enqueue header scripts
 */
function bella_italia_header_scripts() {
    // Only if parallax is enabled
    if ( get_theme_mod( 'bella_italia_enable_header_parallax', true ) && bella_italia_has_header_media() ) {
        wp_enqueue_script( 'bella-italia-parallax', get_template_directory_uri() . '/assets/js/parallax.min.js', array( 'jquery' ), BELLA_ITALIA_VERSION, true );
        
        // Add initialization script
        wp_add_inline_script( 'bella-italia-parallax', '
            jQuery(document).ready(function($) {
                $(".custom-header").parallax({
                    imageSrc: "' . esc_url( get_header_image() ) . '",
                    speed: 0.3
                });
            });
        ' );
    }
}
add_action( 'wp_enqueue_scripts', 'bella_italia_header_scripts' );