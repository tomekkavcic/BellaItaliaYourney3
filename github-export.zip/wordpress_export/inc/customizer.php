<?php
/**
 * Bella Italia Journey Theme Customizer
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function bella_italia_customize_register( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

    // Add Panel for Theme Options
    $wp_customize->add_panel( 'bella_italia_theme_options', array(
        'title'       => __( 'Theme Options', 'bella-italia-journey' ),
        'description' => __( 'Customize your Bella Italia Journey theme', 'bella-italia-journey' ),
        'priority'    => 130,
    ) );

    // General Options Section
    $wp_customize->add_section( 'bella_italia_general_options', array(
        'title'    => __( 'General Options', 'bella-italia-journey' ),
        'priority' => 10,
        'panel'    => 'bella_italia_theme_options',
    ) );

    // Sidebar position
    $wp_customize->add_setting( 'bella_italia_sidebar_position', array(
        'default'           => 'right',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_sidebar_position', array(
        'label'       => __( 'Sidebar Position', 'bella-italia-journey' ),
        'section'     => 'bella_italia_general_options',
        'type'        => 'radio',
        'choices'     => array(
            'left'  => __( 'Left', 'bella-italia-journey' ),
            'right' => __( 'Right', 'bella-italia-journey' ),
        ),
    ) );

    // Excerpt length
    $wp_customize->add_setting( 'bella_italia_excerpt_length', array(
        'default'           => 30,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_excerpt_length', array(
        'label'       => __( 'Excerpt Length', 'bella-italia-journey' ),
        'description' => __( 'Number of words in excerpt', 'bella-italia-journey' ),
        'section'     => 'bella_italia_general_options',
        'type'        => 'number',
        'input_attrs' => array(
            'min'  => 10,
            'max'  => 100,
            'step' => 5,
        ),
    ) );

    // Show breadcrumbs
    $wp_customize->add_setting( 'bella_italia_show_breadcrumbs', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_breadcrumbs', array(
        'label'       => __( 'Show Breadcrumbs', 'bella-italia-journey' ),
        'section'     => 'bella_italia_general_options',
        'type'        => 'checkbox',
    ) );

    // Show back to top button
    $wp_customize->add_setting( 'bella_italia_show_back_to_top', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_back_to_top', array(
        'label'       => __( 'Show "Back to Top" Button', 'bella-italia-journey' ),
        'section'     => 'bella_italia_general_options',
        'type'        => 'checkbox',
    ) );

    // Google Maps API Key
    $wp_customize->add_setting( 'bella_italia_google_maps_api_key', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_google_maps_api_key', array(
        'label'       => __( 'Google Maps API Key', 'bella-italia-journey' ),
        'description' => __( 'Required for displaying maps on destination pages.', 'bella-italia-journey' ),
        'section'     => 'bella_italia_general_options',
        'type'        => 'text',
    ) );

    // Typography Section
    $wp_customize->add_section( 'bella_italia_typography', array(
        'title'    => __( 'Typography', 'bella-italia-journey' ),
        'priority' => 20,
        'panel'    => 'bella_italia_theme_options',
    ) );

    // Body Font
    $wp_customize->add_setting( 'bella_italia_body_font', array(
        'default'           => 'Open Sans',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_body_font', array(
        'label'       => __( 'Body Font', 'bella-italia-journey' ),
        'section'     => 'bella_italia_typography',
        'type'        => 'select',
        'choices'     => array(
            'Open Sans'        => 'Open Sans',
            'Roboto'           => 'Roboto',
            'Lato'             => 'Lato',
            'Montserrat'       => 'Montserrat',
            'Source Sans Pro'  => 'Source Sans Pro',
            'PT Sans'          => 'PT Sans',
        ),
    ) );

    // Heading Font
    $wp_customize->add_setting( 'bella_italia_heading_font', array(
        'default'           => 'Playfair Display',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_heading_font', array(
        'label'       => __( 'Heading Font', 'bella-italia-journey' ),
        'section'     => 'bella_italia_typography',
        'type'        => 'select',
        'choices'     => array(
            'Playfair Display' => 'Playfair Display',
            'Merriweather'     => 'Merriweather',
            'Roboto Slab'      => 'Roboto Slab',
            'Montserrat'       => 'Montserrat',
            'Oswald'           => 'Oswald',
            'Lora'             => 'Lora',
        ),
    ) );

    // Header Section
    $wp_customize->add_section( 'bella_italia_header', array(
        'title'       => __( 'Header Options', 'bella-italia-journey' ),
        'description' => __( 'Customize the header area', 'bella-italia-journey' ),
        'priority'    => 30,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Header Style
    $wp_customize->add_setting( 'bella_italia_header_style', array(
        'default'           => 'default',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_header_style', array(
        'label'       => __( 'Header Style', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'select',
        'choices'     => array(
            'default'     => __( 'Default', 'bella-italia-journey' ),
            'transparent' => __( 'Transparent', 'bella-italia-journey' ),
            'centered'    => __( 'Centered', 'bella-italia-journey' ),
        ),
    ) );

    // Sticky Header
    $wp_customize->add_setting( 'bella_italia_enable_sticky_header', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_enable_sticky_header', array(
        'label'       => __( 'Enable Sticky Header', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'checkbox',
    ) );

    // Show Search
    $wp_customize->add_setting( 'bella_italia_show_search', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_search', array(
        'label'       => __( 'Show Search in Header', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'checkbox',
    ) );

    // Show Language Switcher
    $wp_customize->add_setting( 'bella_italia_show_language_switcher', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_language_switcher', array(
        'label'       => __( 'Show Language Switcher', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'checkbox',
    ) );

    // Contact Information
    $wp_customize->add_setting( 'bella_italia_phone', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_phone', array(
        'label'       => __( 'Phone Number', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_email', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_email',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_email', array(
        'label'       => __( 'Email Address', 'bella-italia-journey' ),
        'section'     => 'bella_italia_header',
        'type'        => 'email',
    ) );

    // Footer Section
    $wp_customize->add_section( 'bella_italia_footer', array(
        'title'       => __( 'Footer Options', 'bella-italia-journey' ),
        'description' => __( 'Customize the footer area', 'bella-italia-journey' ),
        'priority'    => 40,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Footer Widgets
    $wp_customize->add_setting( 'bella_italia_footer_widgets', array(
        'default'           => 4,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_footer_widgets', array(
        'label'       => __( 'Footer Widget Areas', 'bella-italia-journey' ),
        'section'     => 'bella_italia_footer',
        'type'        => 'select',
        'choices'     => array(
            1 => __( '1 Column', 'bella-italia-journey' ),
            2 => __( '2 Columns', 'bella-italia-journey' ),
            3 => __( '3 Columns', 'bella-italia-journey' ),
            4 => __( '4 Columns', 'bella-italia-journey' ),
        ),
    ) );

    // Footer Style
    $wp_customize->add_setting( 'bella_italia_footer_style', array(
        'default'           => 'default',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_footer_style', array(
        'label'       => __( 'Footer Style', 'bella-italia-journey' ),
        'section'     => 'bella_italia_footer',
        'type'        => 'select',
        'choices'     => array(
            'default' => __( 'Default', 'bella-italia-journey' ),
            'dark'    => __( 'Dark', 'bella-italia-journey' ),
            'light'   => __( 'Light', 'bella-italia-journey' ),
        ),
    ) );

    // Copyright Text
    $wp_customize->add_setting( 'bella_italia_copyright_text', array(
        'default'           => '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. ' . __( 'All rights reserved.', 'bella-italia-journey' ),
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_copyright_text', array(
        'label'       => __( 'Copyright Text', 'bella-italia-journey' ),
        'section'     => 'bella_italia_footer',
        'type'        => 'textarea',
    ) );

    // Social Media Section
    $wp_customize->add_section( 'bella_italia_social', array(
        'title'       => __( 'Social Media', 'bella-italia-journey' ),
        'description' => __( 'Add your social media links', 'bella-italia-journey' ),
        'priority'    => 50,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Facebook
    $wp_customize->add_setting( 'bella_italia_facebook_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_facebook_url', array(
        'label'       => __( 'Facebook URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // Twitter
    $wp_customize->add_setting( 'bella_italia_twitter_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_twitter_url', array(
        'label'       => __( 'Twitter URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // Instagram
    $wp_customize->add_setting( 'bella_italia_instagram_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_instagram_url', array(
        'label'       => __( 'Instagram URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // YouTube
    $wp_customize->add_setting( 'bella_italia_youtube_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_youtube_url', array(
        'label'       => __( 'YouTube URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // TikTok
    $wp_customize->add_setting( 'bella_italia_tiktok_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_tiktok_url', array(
        'label'       => __( 'TikTok URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // Pinterest
    $wp_customize->add_setting( 'bella_italia_pinterest_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_pinterest_url', array(
        'label'       => __( 'Pinterest URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_social',
        'type'        => 'url',
    ) );

    // Front Page Section
    $wp_customize->add_section( 'bella_italia_front_page', array(
        'title'       => __( 'Front Page Options', 'bella-italia-journey' ),
        'description' => __( 'Customize the front page sections', 'bella-italia-journey' ),
        'priority'    => 60,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Hero Section
    $wp_customize->add_setting( 'bella_italia_hero_title', array(
        'default'           => __( 'Discover the Beauty of Italy', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_title', array(
        'label'       => __( 'Hero Title', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_hero_subtitle', array(
        'default'           => __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_subtitle', array(
        'label'       => __( 'Hero Subtitle', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_hero_cta_text', array(
        'default'           => __( 'Explore Destinations', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_cta_text', array(
        'label'       => __( 'Hero CTA Text', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_hero_cta_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_cta_url', array(
        'label'       => __( 'Hero CTA URL', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'url',
    ) );

    $wp_customize->add_setting( 'bella_italia_hero_background', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bella_italia_hero_background', array(
        'label'       => __( 'Hero Background Image', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
    ) ) );

    $wp_customize->add_setting( 'bella_italia_hero_enable_search', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_enable_search', array(
        'label'       => __( 'Enable Search in Hero', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'checkbox',
    ) );

    $wp_customize->add_setting( 'bella_italia_hero_enable_map', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_hero_enable_map', array(
        'label'       => __( 'Enable Italy Map in Hero', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'checkbox',
    ) );

    // Featured Destinations Section
    $wp_customize->add_setting( 'bella_italia_featured_destinations_title', array(
        'default'           => __( 'Explore Italy', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_featured_destinations_title', array(
        'label'       => __( 'Featured Destinations Title', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_featured_destinations_subtitle', array(
        'default'           => __( 'Discover the most beautiful destinations in Italy', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_featured_destinations_subtitle', array(
        'label'       => __( 'Featured Destinations Subtitle', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_featured_destinations_count', array(
        'default'           => 6,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_featured_destinations_count', array(
        'label'       => __( 'Number of Featured Destinations', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'number',
        'input_attrs' => array(
            'min'  => 3,
            'max'  => 12,
            'step' => 3,
        ),
    ) );

    // Newsletter Section
    $wp_customize->add_setting( 'bella_italia_show_newsletter', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_newsletter', array(
        'label'       => __( 'Show Newsletter Section', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'checkbox',
    ) );

    $wp_customize->add_setting( 'bella_italia_newsletter_title', array(
        'default'           => __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_newsletter_title', array(
        'label'       => __( 'Newsletter Title', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_newsletter_subtitle', array(
        'default'           => __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' ),
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_newsletter_subtitle', array(
        'label'       => __( 'Newsletter Subtitle', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_newsletter_shortcode', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_newsletter_shortcode', array(
        'label'       => __( 'Newsletter Form Shortcode', 'bella-italia-journey' ),
        'description' => __( 'Enter shortcode from newsletter plugin like MailChimp, MailPoet, etc.', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'bella_italia_newsletter_bg', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bella_italia_newsletter_bg', array(
        'label'       => __( 'Newsletter Background Image', 'bella-italia-journey' ),
        'section'     => 'bella_italia_front_page',
    ) ) );

    // Archive Options Section
    $wp_customize->add_section( 'bella_italia_archive_options', array(
        'title'       => __( 'Archive Options', 'bella-italia-journey' ),
        'description' => __( 'Customize archive and category pages', 'bella-italia-journey' ),
        'priority'    => 70,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Archive Layout
    $wp_customize->add_setting( 'bella_italia_archive_layout', array(
        'default'           => 'grid',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_archive_layout', array(
        'label'       => __( 'Archive Layout', 'bella-italia-journey' ),
        'section'     => 'bella_italia_archive_options',
        'type'        => 'select',
        'choices'     => array(
            'grid'    => __( 'Grid', 'bella-italia-journey' ),
            'list'    => __( 'List', 'bella-italia-journey' ),
            'masonry' => __( 'Masonry', 'bella-italia-journey' ),
            'compact' => __( 'Compact Grid', 'bella-italia-journey' ),
        ),
    ) );

    // Archive Items Per Page
    $wp_customize->add_setting( 'bella_italia_archive_items_per_page', array(
        'default'           => 9,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_archive_items_per_page', array(
        'label'       => __( 'Items Per Page', 'bella-italia-journey' ),
        'section'     => 'bella_italia_archive_options',
        'type'        => 'number',
        'input_attrs' => array(
            'min'  => 3,
            'max'  => 24,
            'step' => 3,
        ),
    ) );

    // Show Map in Archive
    $wp_customize->add_setting( 'bella_italia_archive_show_map', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_archive_show_map', array(
        'label'       => __( 'Show Map in Destination Archive', 'bella-italia-journey' ),
        'section'     => 'bella_italia_archive_options',
        'type'        => 'checkbox',
    ) );

    // Map view in archive
    $wp_customize->add_setting( 'bella_italia_map_view', array(
        'default'           => 'simple',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_map_view', array(
        'label'       => __( 'Map View Style', 'bella-italia-journey' ),
        'section'     => 'bella_italia_archive_options',
        'type'        => 'select',
        'choices'     => array(
            'simple'   => __( 'Simple (Regions Only)', 'bella-italia-journey' ),
            'detailed' => __( 'Detailed (With Pins)', 'bella-italia-journey' ),
        ),
    ) );

    // Blog Layout
    $wp_customize->add_setting( 'bella_italia_blog_layout', array(
        'default'           => 'grid',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_blog_layout', array(
        'label'       => __( 'Blog Layout', 'bella-italia-journey' ),
        'section'     => 'bella_italia_archive_options',
        'type'        => 'select',
        'choices'     => array(
            'grid'    => __( 'Grid', 'bella-italia-journey' ),
            'list'    => __( 'List', 'bella-italia-journey' ),
            'masonry' => __( 'Masonry', 'bella-italia-journey' ),
        ),
    ) );

    // Single Post Options Section
    $wp_customize->add_section( 'bella_italia_single_options', array(
        'title'       => __( 'Single Post Options', 'bella-italia-journey' ),
        'description' => __( 'Customize single post and destination pages', 'bella-italia-journey' ),
        'priority'    => 80,
        'panel'       => 'bella_italia_theme_options',
    ) );

    // Show Related Posts
    $wp_customize->add_setting( 'bella_italia_show_related_posts', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_related_posts', array(
        'label'       => __( 'Show Related Posts', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'checkbox',
    ) );

    // Show Author Box
    $wp_customize->add_setting( 'bella_italia_show_author_box', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_author_box', array(
        'label'       => __( 'Show Author Box', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'checkbox',
    ) );

    // Show Post Navigation
    $wp_customize->add_setting( 'bella_italia_show_post_nav', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_show_post_nav', array(
        'label'       => __( 'Show Post Navigation', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'checkbox',
    ) );

    // Destination Single Layout
    $wp_customize->add_setting( 'bella_italia_destination_layout', array(
        'default'           => 'standard',
        'sanitize_callback' => 'bella_italia_sanitize_select',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_destination_layout', array(
        'label'       => __( 'Destination Single Layout', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'select',
        'choices'     => array(
            'standard'   => __( 'Standard (with sidebar)', 'bella-italia-journey' ),
            'full-width' => __( 'Full Width', 'bella-italia-journey' ),
        ),
    ) );

    // Show Map in Destination
    $wp_customize->add_setting( 'bella_italia_destination_show_map', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_destination_show_map', array(
        'label'       => __( 'Show Map in Destination Single', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'checkbox',
    ) );

    // Enable Destination Gallery
    $wp_customize->add_setting( 'bella_italia_destination_enable_gallery', array(
        'default'           => true,
        'sanitize_callback' => 'bella_italia_sanitize_checkbox',
        'transport'         => 'refresh',
    ) );

    $wp_customize->add_control( 'bella_italia_destination_enable_gallery', array(
        'label'       => __( 'Enable Destination Gallery', 'bella-italia-journey' ),
        'section'     => 'bella_italia_single_options',
        'type'        => 'checkbox',
    ) );

    // If selective refresh is supported, add callbacks for customizing live
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial(
            'blogname',
            array(
                'selector'        => '.site-title a',
                'render_callback' => 'bella_italia_customize_partial_blogname',
            )
        );
        $wp_customize->selective_refresh->add_partial(
            'blogdescription',
            array(
                'selector'        => '.site-description',
                'render_callback' => 'bella_italia_customize_partial_blogdescription',
            )
        );
    }
}
add_action( 'customize_register', 'bella_italia_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 */
function bella_italia_customize_partial_blogname() {
    bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 */
function bella_italia_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function bella_italia_customize_preview_js() {
    wp_enqueue_script( 'bella-italia-journey-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), BELLA_ITALIA_VERSION, true );
}
add_action( 'customize_preview_init', 'bella_italia_customize_preview_js' );

/**
 * Sanitize checkbox values
 */
function bella_italia_sanitize_checkbox( $checked ) {
    return ( ( isset( $checked ) && true === $checked ) ? true : false );
}

/**
 * Sanitize select values
 */
function bella_italia_sanitize_select( $input, $setting ) {
    // Get the list of choices from the control associated with the setting
    $choices = $setting->manager->get_control( $setting->id )->choices;
    
    // If the input is a valid key, return it; otherwise, return the default
    return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}