<?php
/**
 * Plugin compatibility functions
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * WooCommerce compatibility
 */
if ( class_exists( 'WooCommerce' ) ) {
    /**
     * WooCommerce setup function.
     *
     * @link https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/
     */
    function bella_italia_woocommerce_setup() {
        add_theme_support(
            'woocommerce',
            array(
                'thumbnail_image_width' => 300,
                'single_image_width'    => 600,
                'product_grid'          => array(
                    'default_rows'    => 3,
                    'min_rows'        => 1,
                    'default_columns' => 4,
                    'min_columns'     => 1,
                    'max_columns'     => 6,
                ),
            )
        );
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );
    }
    add_action( 'after_setup_theme', 'bella_italia_woocommerce_setup' );

    /**
     * WooCommerce specific scripts & stylesheets.
     */
    function bella_italia_woocommerce_scripts() {
        wp_enqueue_style( 'bella-italia-woocommerce-style', get_template_directory_uri() . '/assets/css/woocommerce.css', array(), BELLA_ITALIA_VERSION );
    }
    add_action( 'wp_enqueue_scripts', 'bella_italia_woocommerce_scripts' );

    /**
     * Disable the default WooCommerce stylesheet.
     *
     * Removing the default WooCommerce stylesheet and enqueing your own will
     * protect you during WooCommerce core updates.
     *
     * @link https://docs.woocommerce.com/document/disable-the-default-stylesheet/
     */
    add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

    /**
     * Add 'woocommerce-active' class to the body tag.
     *
     * @param  array $classes CSS classes applied to the body tag.
     * @return array $classes modified to include 'woocommerce-active' class.
     */
    function bella_italia_woocommerce_active_body_class( $classes ) {
        $classes[] = 'woocommerce-active';

        return $classes;
    }
    add_filter( 'body_class', 'bella_italia_woocommerce_active_body_class' );

    /**
     * Products per page.
     *
     * @return integer number of products.
     */
    function bella_italia_woocommerce_products_per_page() {
        return 12;
    }
    add_filter( 'loop_shop_per_page', 'bella_italia_woocommerce_products_per_page' );

    /**
     * Product gallery thumnbail columns.
     *
     * @return integer number of columns.
     */
    function bella_italia_woocommerce_thumbnail_columns() {
        return 4;
    }
    add_filter( 'woocommerce_product_thumbnails_columns', 'bella_italia_woocommerce_thumbnail_columns' );

    /**
     * Default loop columns on product archives.
     *
     * @return integer products per row.
     */
    function bella_italia_woocommerce_loop_columns() {
        return 3;
    }
    add_filter( 'loop_shop_columns', 'bella_italia_woocommerce_loop_columns' );

    /**
     * Related Products Args.
     *
     * @param array $args related products args.
     * @return array $args related products args.
     */
    function bella_italia_woocommerce_related_products_args( $args ) {
        $defaults = array(
            'posts_per_page' => 3,
            'columns'        => 3,
        );

        $args = wp_parse_args( $defaults, $args );

        return $args;
    }
    add_filter( 'woocommerce_output_related_products_args', 'bella_italia_woocommerce_related_products_args' );
}

/**
 * WPML compatibility
 */
if ( class_exists( 'SitePress' ) ) {
    /**
     * Add WPML language switcher to header
     */
    function bella_italia_wpml_language_switcher() {
        $languages = apply_filters( 'wpml_active_languages', NULL, array( 'skip_missing' => 0 ) );
        
        if ( ! empty( $languages ) ) {
            echo '<div class="wpml-language-switcher">';
            echo '<ul class="language-list">';
            
            foreach ( $languages as $language ) {
                $active_class = $language['active'] ? ' active' : '';
                
                echo '<li class="language-item' . $active_class . '">';
                if ( ! $language['active'] ) {
                    echo '<a href="' . esc_url( $language['url'] ) . '" class="language-link">';
                }
                
                if ( $language['country_flag_url'] ) {
                    echo '<img src="' . esc_url( $language['country_flag_url'] ) . '" alt="' . esc_attr( $language['language_code'] ) . '" class="language-flag" />';
                }
                
                echo '<span class="language-name">' . esc_html( $language['native_name'] ) . '</span>';
                
                if ( ! $language['active'] ) {
                    echo '</a>';
                }
                echo '</li>';
            }
            
            echo '</ul>';
            echo '</div>';
        }
    }
    
    /**
     * Add language classes to body
     */
    function bella_italia_wpml_body_classes( $classes ) {
        $current_language = apply_filters( 'wpml_current_language', NULL );
        
        if ( $current_language ) {
            $classes[] = 'lang-' . $current_language;
        }
        
        return $classes;
    }
    add_filter( 'body_class', 'bella_italia_wpml_body_classes' );
    
    /**
     * Register WPML strings
     */
    function bella_italia_wpml_register_strings() {
        if ( function_exists( 'icl_register_string' ) ) {
            // Register hero section strings
            icl_register_string( 'Bella Italia Journey', 'hero_title', get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) ) );
            icl_register_string( 'Bella Italia Journey', 'hero_subtitle', get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ) ) );
            icl_register_string( 'Bella Italia Journey', 'hero_cta_text', get_theme_mod( 'bella_italia_hero_cta_text', __( 'Explore Destinations', 'bella-italia-journey' ) ) );
            
            // Register featured destinations section strings
            icl_register_string( 'Bella Italia Journey', 'featured_destinations_title', get_theme_mod( 'bella_italia_featured_destinations_title', __( 'Explore Italy', 'bella-italia-journey' ) ) );
            icl_register_string( 'Bella Italia Journey', 'featured_destinations_subtitle', get_theme_mod( 'bella_italia_featured_destinations_subtitle', __( 'Discover the most beautiful destinations in Italy', 'bella-italia-journey' ) ) );
            
            // Register newsletter section strings
            icl_register_string( 'Bella Italia Journey', 'newsletter_title', get_theme_mod( 'bella_italia_newsletter_title', __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ) ) );
            icl_register_string( 'Bella Italia Journey', 'newsletter_subtitle', get_theme_mod( 'bella_italia_newsletter_subtitle', __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' ) ) );
            
            // Register copyright text
            icl_register_string( 'Bella Italia Journey', 'copyright_text', get_theme_mod( 'bella_italia_copyright_text', '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. ' . __( 'All rights reserved.', 'bella-italia-journey' ) ) );
        }
    }
    add_action( 'init', 'bella_italia_wpml_register_strings' );
    
    /**
     * Translate strings in customizer
     */
    function bella_italia_wpml_translate_strings( $value ) {
        if ( function_exists( 'icl_t' ) ) {
            if ( is_customize_preview() ) {
                return $value;
            }
            
            // Get option name
            $option_name = current_filter();
            $option_name = str_replace( 'theme_mod_', '', $option_name );
            
            // Translate specific options
            $translate_options = array(
                'bella_italia_hero_title' => 'hero_title',
                'bella_italia_hero_subtitle' => 'hero_subtitle',
                'bella_italia_hero_cta_text' => 'hero_cta_text',
                'bella_italia_featured_destinations_title' => 'featured_destinations_title',
                'bella_italia_featured_destinations_subtitle' => 'featured_destinations_subtitle',
                'bella_italia_newsletter_title' => 'newsletter_title',
                'bella_italia_newsletter_subtitle' => 'newsletter_subtitle',
                'bella_italia_copyright_text' => 'copyright_text',
            );
            
            if ( array_key_exists( $option_name, $translate_options ) ) {
                return icl_t( 'Bella Italia Journey', $translate_options[$option_name], $value );
            }
        }
        
        return $value;
    }
    
    // Add filters for translatable theme mods
    add_filter( 'theme_mod_bella_italia_hero_title', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_hero_subtitle', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_hero_cta_text', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_featured_destinations_title', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_featured_destinations_subtitle', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_newsletter_title', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_newsletter_subtitle', 'bella_italia_wpml_translate_strings' );
    add_filter( 'theme_mod_bella_italia_copyright_text', 'bella_italia_wpml_translate_strings' );
}

/**
 * Polylang compatibility
 */
if ( function_exists( 'pll_register_string' ) ) {
    /**
     * Register Polylang strings
     */
    function bella_italia_pll_register_strings() {
        // Register hero section strings
        pll_register_string( 'hero_title', get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        pll_register_string( 'hero_subtitle', get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        pll_register_string( 'hero_cta_text', get_theme_mod( 'bella_italia_hero_cta_text', __( 'Explore Destinations', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        
        // Register featured destinations section strings
        pll_register_string( 'featured_destinations_title', get_theme_mod( 'bella_italia_featured_destinations_title', __( 'Explore Italy', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        pll_register_string( 'featured_destinations_subtitle', get_theme_mod( 'bella_italia_featured_destinations_subtitle', __( 'Discover the most beautiful destinations in Italy', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        
        // Register newsletter section strings
        pll_register_string( 'newsletter_title', get_theme_mod( 'bella_italia_newsletter_title', __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        pll_register_string( 'newsletter_subtitle', get_theme_mod( 'bella_italia_newsletter_subtitle', __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
        
        // Register copyright text
        pll_register_string( 'copyright_text', get_theme_mod( 'bella_italia_copyright_text', '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. ' . __( 'All rights reserved.', 'bella-italia-journey' ) ), 'Bella Italia Journey' );
    }
    add_action( 'init', 'bella_italia_pll_register_strings' );
    
    /**
     * Translate strings in customizer
     */
    function bella_italia_pll_translate_strings( $value ) {
        if ( function_exists( 'pll__' ) ) {
            if ( is_customize_preview() ) {
                return $value;
            }
            
            // Get option name
            $option_name = current_filter();
            $option_name = str_replace( 'theme_mod_', '', $option_name );
            
            // Translate specific options
            $translate_options = array(
                'bella_italia_hero_title' => 'hero_title',
                'bella_italia_hero_subtitle' => 'hero_subtitle',
                'bella_italia_hero_cta_text' => 'hero_cta_text',
                'bella_italia_featured_destinations_title' => 'featured_destinations_title',
                'bella_italia_featured_destinations_subtitle' => 'featured_destinations_subtitle',
                'bella_italia_newsletter_title' => 'newsletter_title',
                'bella_italia_newsletter_subtitle' => 'newsletter_subtitle',
                'bella_italia_copyright_text' => 'copyright_text',
            );
            
            if ( array_key_exists( $option_name, $translate_options ) ) {
                return pll__( $translate_options[$option_name] );
            }
        }
        
        return $value;
    }
    
    // Add filters for translatable theme mods
    add_filter( 'theme_mod_bella_italia_hero_title', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_hero_subtitle', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_hero_cta_text', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_featured_destinations_title', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_featured_destinations_subtitle', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_newsletter_title', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_newsletter_subtitle', 'bella_italia_pll_translate_strings' );
    add_filter( 'theme_mod_bella_italia_copyright_text', 'bella_italia_pll_translate_strings' );
    
    /**
     * Add language classes to body
     */
    function bella_italia_pll_body_classes( $classes ) {
        $current_language = pll_current_language();
        
        if ( $current_language ) {
            $classes[] = 'lang-' . $current_language;
        }
        
        return $classes;
    }
    add_filter( 'body_class', 'bella_italia_pll_body_classes' );
}

/**
 * Contact Form 7 compatibility
 */
if ( class_exists( 'WPCF7' ) ) {
    /**
     * Change Contact Form 7 styles
     */
    function bella_italia_wpcf7_styles() {
        // Add custom styles
        wp_enqueue_style( 'bella-italia-cf7-style', get_template_directory_uri() . '/assets/css/contact-form-7.css', array(), BELLA_ITALIA_VERSION );
    }
    add_action( 'wp_enqueue_scripts', 'bella_italia_wpcf7_styles' );
    
    /**
     * Add Italian telephone format validation
     */
    function bella_italia_wpcf7_italian_phone_validation( $result, $tag ) {
        $type = $tag->type;
        $name = $tag->name;
        
        if ( 'tel' == $type ) {
            $value = isset( $_POST[$name] ) ? trim( $_POST[$name] ) : '';
            
            if ( $value && ! preg_match( '/^(\+39)?[ ]?[0-9]{3}[ ]?[0-9]{7}$/', $value ) ) {
                $result->invalidate( $tag, __( 'Please enter a valid Italian phone number.', 'bella-italia-journey' ) );
            }
        }
        
        return $result;
    }
    add_filter( 'wpcf7_validate_tel', 'bella_italia_wpcf7_italian_phone_validation', 10, 2 );
    add_filter( 'wpcf7_validate_tel*', 'bella_italia_wpcf7_italian_phone_validation', 10, 2 );
}

/**
 * Yoast SEO compatibility
 */
if ( defined( 'WPSEO_VERSION' ) ) {
    /**
     * Add schema information for destinations
     */
    function bella_italia_wpseo_schema_graph_pieces( $pieces, $context ) {
        if ( is_singular( 'destination' ) ) {
            require_once get_template_directory() . '/inc/schema/class-schema-destination.php';
            $pieces[] = new Bella_Italia_Schema_Destination( $context );
        }
        
        return $pieces;
    }
    add_filter( 'wpseo_schema_graph_pieces', 'bella_italia_wpseo_schema_graph_pieces', 11, 2 );
    
    /**
     * Add destination breadcrumbs to Yoast breadcrumbs
     */
    function bella_italia_wpseo_breadcrumb_links( $links ) {
        if ( is_singular( 'destination' ) ) {
            global $post;
            
            // Get regions
            $regions = get_the_terms( $post->ID, 'region' );
            
            if ( $regions && ! is_wp_error( $regions ) ) {
                // Find destinations link position
                $destinations_position = -1;
                
                foreach ( $links as $key => $link ) {
                    if ( isset( $link['ptarchive'] ) && 'destination' === $link['ptarchive'] ) {
                        $destinations_position = $key;
                        break;
                    }
                }
                
                // If we found the destinations archive link, insert region after it
                if ( $destinations_position !== -1 ) {
                    $region = reset( $regions ); // Get first region
                    
                    $region_link = array(
                        'term_id' => $region->term_id,
                        'url'     => get_term_link( $region ),
                        'text'    => $region->name,
                    );
                    
                    // Insert after destinations link
                    array_splice( $links, $destinations_position + 1, 0, array( $region_link ) );
                }
            }
        }
        
        return $links;
    }
    add_filter( 'wpseo_breadcrumb_links', 'bella_italia_wpseo_breadcrumb_links' );
}

/**
 * Advanced Custom Fields compatibility
 */
if ( class_exists( 'ACF' ) ) {
    /**
     * Register ACF fields for destinations
     */
    function bella_italia_register_acf_fields() {
        if ( function_exists( 'acf_add_local_field_group' ) ) {
            acf_add_local_field_group( array(
                'key' => 'group_destination_details',
                'title' => __( 'Destination Details', 'bella-italia-journey' ),
                'fields' => array(
                    array(
                        'key' => 'field_destination_location',
                        'label' => __( 'Location', 'bella-italia-journey' ),
                        'name' => '_destination_location',
                        'type' => 'text',
                        'instructions' => __( 'Enter the location name (city, town, area)', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_map_lat',
                        'label' => __( 'Map Latitude', 'bella-italia-journey' ),
                        'name' => '_destination_map_lat',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '50',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_map_lng',
                        'label' => __( 'Map Longitude', 'bella-italia-journey' ),
                        'name' => '_destination_map_lng',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '50',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_map_zoom',
                        'label' => __( 'Map Zoom Level', 'bella-italia-journey' ),
                        'name' => '_destination_map_zoom',
                        'type' => 'number',
                        'instructions' => '',
                        'required' => 0,
                        'default_value' => 10,
                        'min' => 1,
                        'max' => 20,
                        'step' => 1,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_featured_destination',
                        'label' => __( 'Featured Destination', 'bella-italia-journey' ),
                        'name' => '_featured_destination',
                        'type' => 'true_false',
                        'instructions' => __( 'Featured destinations appear in the featured section on the homepage', 'bella-italia-journey' ),
                        'required' => 0,
                        'default_value' => 0,
                        'ui' => 1,
                        'ui_on_text' => __( 'Yes', 'bella-italia-journey' ),
                        'ui_off_text' => __( 'No', 'bella-italia-journey' ),
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'destination',
                        ),
                    ),
                ),
                'menu_order' => 0,
                'position' => 'side',
                'style' => 'default',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => true,
                'description' => '',
            ) );
            
            acf_add_local_field_group( array(
                'key' => 'group_destination_features',
                'title' => __( 'Destination Features', 'bella-italia-journey' ),
                'fields' => array(
                    array(
                        'key' => 'field_destination_local_food',
                        'label' => __( 'Local Food', 'bella-italia-journey' ),
                        'name' => '_destination_local_food',
                        'type' => 'textarea',
                        'instructions' => __( 'Describe famous local dishes and food specialties', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_local_drink',
                        'label' => __( 'Local Drink', 'bella-italia-journey' ),
                        'name' => '_destination_local_drink',
                        'type' => 'textarea',
                        'instructions' => __( 'Mention local wines, spirits or beverages', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_accommodation',
                        'label' => __( 'Accommodation', 'bella-italia-journey' ),
                        'name' => '_destination_accommodation',
                        'type' => 'textarea',
                        'instructions' => __( 'Recommend places to stay (hotels, B&Bs, agriturismo, etc.)', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_must_see',
                        'label' => __( 'Must See', 'bella-italia-journey' ),
                        'name' => '_destination_must_see',
                        'type' => 'textarea',
                        'instructions' => __( 'List attractions and landmarks that visitors shouldn\'t miss', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                    array(
                        'key' => 'field_destination_best_experience',
                        'label' => __( 'Best Experience', 'bella-italia-journey' ),
                        'name' => '_destination_best_experience',
                        'type' => 'textarea',
                        'instructions' => __( 'Describe unique activities and experiences visitors should try', 'bella-italia-journey' ),
                        'required' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                    ),
                ),
                'location' => array(
                    array(
                        array(
                            'param' => 'post_type',
                            'operator' => '==',
                            'value' => 'destination',
                        ),
                    ),
                ),
                'menu_order' => 10,
                'position' => 'normal',
                'style' => 'default',
                'label_placement' => 'top',
                'instruction_placement' => 'label',
                'hide_on_screen' => '',
                'active' => true,
                'description' => '',
            ) );
        }
    }
    add_action( 'acf/init', 'bella_italia_register_acf_fields' );
    
    /**
     * Use ACF fields if meta boxes are not available
     */
    function bella_italia_acf_get_meta( $meta_value, $post_id, $meta_key ) {
        // If using ACF, get values from ACF fields
        if ( function_exists( 'get_field' ) ) {
            $acf_value = get_field( $meta_key, $post_id );
            
            if ( $acf_value !== null && $acf_value !== false ) {
                return $acf_value;
            }
        }
        
        return $meta_value;
    }
    add_filter( 'get_post_metadata', 'bella_italia_acf_get_meta', 10, 3 );
}