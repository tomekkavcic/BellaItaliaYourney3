<?php
/**
 * Custom shortcodes for the Bella Italia Journey theme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Featured Destinations shortcode
 * Usage: [featured_destinations count="3" region=""]
 */
function bella_italia_featured_destinations_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'count' => 3,
        'region' => '',
    ), $atts, 'featured_destinations' );
    
    $args = array(
        'post_type'      => 'destination',
        'posts_per_page' => intval( $atts['count'] ),
        'meta_key'       => '_destination_featured',
        'meta_value'     => '1',
        'orderby'        => 'menu_order date',
        'order'          => 'ASC',
    );
    
    // If region is specified, add tax query
    if ( ! empty( $atts['region'] ) ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'region',
                'field'    => 'slug',
                'terms'    => $atts['region'],
            ),
        );
    }
    
    $featured_query = new WP_Query( $args );
    
    ob_start();
    
    if ( $featured_query->have_posts() ) :
        ?>
        <div class="featured-destinations-grid grid grid-3">
            <?php
            while ( $featured_query->have_posts() ) :
                $featured_query->the_post();
                
                // Get region for destination
                $regions = get_the_terms( get_the_ID(), 'region' );
                $region_class = '';
                $region_name = '';
                
                if ( ! empty( $regions ) ) {
                    $region_slug = $regions[0]->slug;
                    $region_class = 'region-' . $region_slug;
                    $region_name = $regions[0]->name;
                }
                
                // Get location
                $location = get_post_meta( get_the_ID(), '_destination_location', true );
                ?>
                <article class="featured-destination card">
                    <?php if ( has_post_thumbnail() ) : ?>
                    <div class="card-image-wrapper">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail( 'bella-italia-featured', array( 'class' => 'card-image' ) ); ?>
                        </a>
                        <?php if ( $region_name ) : ?>
                        <span class="region-badge <?php echo esc_attr( $region_class ); ?>"><?php echo esc_html( $region_name ); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-content p-3">
                        <h3 class="card-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        
                        <?php if ( $location ) : ?>
                        <div class="destination-location mb-2">
                            <i class="fas fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="card-excerpt mb-3">
                            <?php the_excerpt(); ?>
                        </div>
                        
                        <a href="<?php the_permalink(); ?>" class="btn btn-outline btn-outline-green mt-auto">
                            <?php esc_html_e( 'Explore', 'bella-italia-journey' ); ?>
                        </a>
                    </div>
                </article>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>
        </div>
        <?php
    else :
        ?>
        <div class="no-destinations-found">
            <?php esc_html_e( 'No featured destinations found.', 'bella-italia-journey' ); ?>
        </div>
        <?php
    endif;
    
    return ob_get_clean();
}
add_shortcode( 'featured_destinations', 'bella_italia_featured_destinations_shortcode' );

/**
 * Google Reviews shortcode
 * Usage: [google_reviews count="3"]
 */
function bella_italia_google_reviews_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'count' => 3,
    ), $atts, 'google_reviews' );
    
    // Sample reviews data - would normally be fetched from Google API
    $reviews = array(
        array(
            'id'      => 1,
            'author'  => 'Sofia M.',
            'rating'  => 5,
            'date'    => '2023-06-15',
            'content' => 'The travel tips and recommendations were fantastic! We had the most authentic Italian experience thanks to this site.',
            'avatar'  => 'https://i.pravatar.cc/100?img=1',
        ),
        array(
            'id'      => 2,
            'author'  => 'Marco L.',
            'rating'  => 5,
            'date'    => '2023-05-22',
            'content' => 'Found amazing hidden gems in Tuscany that weren\'t in any of the typical tourist guides. Highly recommend their local food suggestions!',
            'avatar'  => 'https://i.pravatar.cc/100?img=2',
        ),
        array(
            'id'      => 3,
            'author'  => 'Emma T.',
            'rating'  => 4,
            'date'    => '2023-04-10',
            'content' => 'The regional breakdown helped us plan our trip much more effectively. Great resource for first-time visitors to Italy.',
            'avatar'  => 'https://i.pravatar.cc/100?img=3',
        ),
    );
    
    // Limit the number of reviews
    $reviews = array_slice( $reviews, 0, intval( $atts['count'] ) );
    
    ob_start();
    ?>
    <div class="google-reviews-container">
        <div class="google-reviews-grid grid grid-3">
            <?php foreach ( $reviews as $review ) : ?>
                <div class="review-card card">
                    <div class="review-header p-3">
                        <div class="review-author">
                            <img src="<?php echo esc_url( $review['avatar'] ); ?>" alt="<?php echo esc_attr( $review['author'] ); ?>" class="review-avatar">
                            <div class="review-author-info">
                                <div class="review-author-name"><?php echo esc_html( $review['author'] ); ?></div>
                                <div class="review-date"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $review['date'] ) ); ?></div>
                            </div>
                        </div>
                        <div class="review-rating">
                            <?php
                            for ( $i = 1; $i <= 5; $i++ ) {
                                if ( $i <= $review['rating'] ) {
                                    echo '<i class="fas fa-star"></i>';
                                } else {
                                    echo '<i class="far fa-star"></i>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="review-content p-3">
                        <?php echo esc_html( $review['content'] ); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="google-reviews-footer text-center mt-4">
            <a href="https://www.google.com/search?q=bella+italia+journey+reviews" target="_blank" class="btn btn-outline btn-outline-white">
                <i class="fab fa-google me-2"></i> <?php esc_html_e( 'Read More Reviews', 'bella-italia-journey' ); ?>
            </a>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'google_reviews', 'bella_italia_google_reviews_shortcode' );

/**
 * Italy Map shortcode
 * Usage: [italy_map active_region=""]
 */
function bella_italia_italy_map_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'active_region' => '',
    ), $atts, 'italy_map' );
    
    $active_region = $atts['active_region'];
    
    // Get all regions
    $regions = get_terms( array(
        'taxonomy' => 'region',
        'hide_empty' => false,
    ) );
    
    // Base path to SVG map
    $svg_path = get_template_directory_uri() . '/assets/images/italy-map.svg';
    
    ob_start();
    ?>
    <div class="italy-map-container">
        <div class="italy-interactive-map">
            <!-- You would include an SVG map here with regions that can be clicked -->
            <img src="<?php echo esc_url( $svg_path ); ?>" alt="<?php esc_attr_e( 'Map of Italy', 'bella-italia-journey' ); ?>" usemap="#italy-map" class="italy-map-image">
            
            <map name="italy-map">
                <?php 
                // This would include area tags for each region
                // For example:
                // <area shape="poly" coords="..." alt="North Italy" href="..." data-region="north">
                ?>
            </map>
            
            <div class="region-selector">
                <?php if ( ! empty( $regions ) && ! is_wp_error( $regions ) ) : ?>
                    <?php foreach ( $regions as $region ) : ?>
                        <a href="<?php echo esc_url( get_term_link( $region ) ); ?>" 
                           class="region-option <?php echo $region->slug === $active_region ? 'active' : ''; ?>"
                           data-region="<?php echo esc_attr( $region->slug ); ?>">
                            <?php echo esc_html( $region->name ); ?>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="region-details">
            <?php if ( ! empty( $regions ) && ! is_wp_error( $regions ) ) : ?>
                <?php foreach ( $regions as $region ) : ?>
                    <div class="region-detail <?php echo $region->slug === $active_region ? 'active' : ''; ?>" id="region-<?php echo esc_attr( $region->slug ); ?>">
                        <h3 class="region-name"><?php echo esc_html( $region->name ); ?></h3>
                        <div class="region-description">
                            <?php echo wp_kses_post( term_description( $region->term_id, 'region' ) ); ?>
                        </div>
                        <a href="<?php echo esc_url( get_term_link( $region ) ); ?>" class="btn btn-outline btn-outline-green mt-3">
                            <?php esc_html_e( 'Explore Region', 'bella-italia-journey' ); ?>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    (function($) {
        $(document).ready(function() {
            // Handle region selection
            $('.region-option, area[data-region]').on('click', function(e) {
                if ($(this).hasClass('region-selector-only')) {
                    e.preventDefault();
                    
                    var region = $(this).data('region');
                    
                    // Update active state
                    $('.region-option').removeClass('active');
                    $('.region-option[data-region="' + region + '"]').addClass('active');
                    
                    // Show corresponding region details
                    $('.region-detail').removeClass('active');
                    $('#region-' + region).addClass('active');
                    
                    // Highlight map region (would require additional JS to manipulate SVG)
                }
            });
        });
    })(jQuery);
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode( 'italy_map', 'bella_italia_italy_map_shortcode' );

/**
 * Blog Teaser shortcode
 * Usage: [blog_teaser count="3" region=""]
 */
function bella_italia_blog_teaser_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'count' => 3,
        'region' => '',
    ), $atts, 'blog_teaser' );
    
    $args = array(
        'post_type'      => 'post',
        'posts_per_page' => intval( $atts['count'] ),
        'orderby'        => 'date',
        'order'          => 'DESC',
    );
    
    // If region is specified, add tax query
    if ( ! empty( $atts['region'] ) ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'region',
                'field'    => 'slug',
                'terms'    => $atts['region'],
            ),
        );
    }
    
    $blog_query = new WP_Query( $args );
    
    ob_start();
    
    if ( $blog_query->have_posts() ) :
        ?>
        <div class="blog-teaser-grid grid grid-3">
            <?php
            while ( $blog_query->have_posts() ) :
                $blog_query->the_post();
                
                // Get region for post
                $regions = get_the_terms( get_the_ID(), 'region' );
                $region_class = '';
                $region_name = '';
                
                if ( ! empty( $regions ) ) {
                    $region_slug = $regions[0]->slug;
                    $region_class = 'region-' . $region_slug;
                    $region_name = $regions[0]->name;
                }
                ?>
                <article class="blog-card card">
                    <?php if ( has_post_thumbnail() ) : ?>
                    <div class="card-image-wrapper">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail( 'medium', array( 'class' => 'card-image' ) ); ?>
                        </a>
                        <?php if ( $region_name ) : ?>
                        <span class="region-badge <?php echo esc_attr( $region_class ); ?>"><?php echo esc_html( $region_name ); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-content p-3">
                        <h3 class="card-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        <div class="card-meta mb-2">
                            <span class="date"><?php echo get_the_date(); ?></span>
                            <span class="read-time">
                                <?php 
                                // Calculate read time based on word count
                                $content = get_the_content();
                                $word_count = str_word_count( strip_tags( $content ) );
                                $read_time = ceil( $word_count / 200 ); // Assuming 200 words per minute
                                printf( esc_html__( '%d min read', 'bella-italia-journey' ), $read_time );
                                ?>
                            </span>
                        </div>
                        <div class="card-excerpt mb-3">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="btn btn-outline btn-outline-red mt-auto">
                            <?php esc_html_e( 'Read Article', 'bella-italia-journey' ); ?>
                        </a>
                    </div>
                </article>
                <?php
            endwhile;
            wp_reset_postdata();
            ?>
        </div>
        <?php
    else :
        ?>
        <div class="no-posts-found">
            <?php esc_html_e( 'No blog posts found.', 'bella-italia-journey' ); ?>
        </div>
        <?php
    endif;
    
    return ob_get_clean();
}
add_shortcode( 'blog_teaser', 'bella_italia_blog_teaser_shortcode' );

/**
 * Contact Form shortcode
 * Usage: [contact_form]
 */
function bella_italia_contact_form_shortcode( $atts ) {
    $atts = shortcode_atts( array(), $atts, 'contact_form' );
    
    ob_start();
    ?>
    <div class="contact-form-container">
        <form class="contact-form" id="contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="bella_italia_contact_form">
            <?php wp_nonce_field( 'bella_italia_contact_form_nonce', 'contact_form_nonce' ); ?>
            
            <div class="form-grid grid grid-2">
                <div class="form-field">
                    <label for="contact-name"><?php esc_html_e( 'Name', 'bella-italia-journey' ); ?> <span class="required">*</span></label>
                    <input type="text" name="contact_name" id="contact-name" required>
                </div>
                
                <div class="form-field">
                    <label for="contact-email"><?php esc_html_e( 'Email', 'bella-italia-journey' ); ?> <span class="required">*</span></label>
                    <input type="email" name="contact_email" id="contact-email" required>
                </div>
            </div>
            
            <div class="form-field">
                <label for="contact-subject"><?php esc_html_e( 'Subject', 'bella-italia-journey' ); ?> <span class="required">*</span></label>
                <input type="text" name="contact_subject" id="contact-subject" required>
            </div>
            
            <div class="form-field">
                <label for="contact-message"><?php esc_html_e( 'Message', 'bella-italia-journey' ); ?> <span class="required">*</span></label>
                <textarea name="contact_message" id="contact-message" rows="5" required></textarea>
            </div>
            
            <?php if ( function_exists( 'bella_italia_language_preferences_field' ) ) : ?>
                <?php bella_italia_language_preferences_field(); ?>
            <?php endif; ?>
            
            <div class="form-field">
                <button type="submit" class="btn btn-primary"><?php esc_html_e( 'Send Message', 'bella-italia-journey' ); ?></button>
            </div>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'contact_form', 'bella_italia_contact_form_shortcode' );

/**
 * Newsletter Form shortcode
 * Usage: [newsletter_form]
 */
function bella_italia_newsletter_form_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'title' => __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ),
        'subtitle' => __( 'Get the latest travel tips and updates directly to your inbox', 'bella-italia-journey' ),
    ), $atts, 'newsletter_form' );
    
    ob_start();
    ?>
    <div class="newsletter-form-container">
        <?php if ( $atts['title'] ) : ?>
            <h3 class="newsletter-title"><?php echo esc_html( $atts['title'] ); ?></h3>
        <?php endif; ?>
        
        <?php if ( $atts['subtitle'] ) : ?>
            <p class="newsletter-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
        <?php endif; ?>
        
        <form class="newsletter-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="bella_italia_newsletter_subscribe">
            <?php wp_nonce_field( 'bella_italia_newsletter_nonce', 'newsletter_nonce' ); ?>
            
            <div class="newsletter-form-fields">
                <input type="email" name="subscriber_email" placeholder="<?php esc_attr_e( 'Your email address', 'bella-italia-journey' ); ?>" required>
                <button type="submit" class="btn btn-primary"><?php esc_html_e( 'Subscribe', 'bella-italia-journey' ); ?></button>
            </div>
            
            <div class="privacy-note">
                <small><?php esc_html_e( 'By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.', 'bella-italia-journey' ); ?></small>
            </div>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'newsletter_form', 'bella_italia_newsletter_form_shortcode' );