<?php
/**
 * Custom template tags for this theme
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Prints HTML with meta information for the current post-date/time.
 */
if ( ! function_exists( 'bella_italia_posted_on' ) ) :
    function bella_italia_posted_on() {
        $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
        if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
            $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
        }

        $time_string = sprintf(
            $time_string,
            esc_attr( get_the_date( DATE_W3C ) ),
            esc_html( get_the_date() ),
            esc_attr( get_the_modified_date( DATE_W3C ) ),
            esc_html( get_the_modified_date() )
        );

        $posted_on = sprintf(
            /* translators: %s: post date. */
            esc_html_x( 'Posted on %s', 'post date', 'bella-italia-journey' ),
            '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
        );

        echo '<span class="posted-on"><i class="fa fa-calendar"></i> ' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
endif;

/**
 * Prints HTML with meta information for the current author.
 */
if ( ! function_exists( 'bella_italia_posted_by' ) ) :
    function bella_italia_posted_by() {
        $byline = sprintf(
            /* translators: %s: post author. */
            esc_html_x( 'by %s', 'post author', 'bella-italia-journey' ),
            '<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
        );

        echo '<span class="byline"><i class="fa fa-user"></i> ' . $byline . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
endif;

/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
if ( ! function_exists( 'bella_italia_entry_footer' ) ) :
    function bella_italia_entry_footer() {
        // Hide category and tag text for pages.
        if ( 'post' === get_post_type() ) {
            /* translators: used between list items, there is a space after the comma */
            $categories_list = get_the_category_list( esc_html__( ', ', 'bella-italia-journey' ) );
            if ( $categories_list ) {
                /* translators: 1: list of categories. */
                printf( '<span class="cat-links"><i class="fa fa-folder"></i> ' . esc_html__( 'Posted in %1$s', 'bella-italia-journey' ) . '</span>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }

            /* translators: used between list items, there is a space after the comma */
            $tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'bella-italia-journey' ) );
            if ( $tags_list ) {
                /* translators: 1: list of tags. */
                printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . esc_html__( 'Tagged %1$s', 'bella-italia-journey' ) . '</span>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
        }

        if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
            echo '<span class="comments-link"><i class="fa fa-comments"></i> ';
            comments_popup_link(
                sprintf(
                    wp_kses(
                        /* translators: %s: post title */
                        __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'bella-italia-journey' ),
                        array(
                            'span' => array(
                                'class' => array(),
                            ),
                        )
                    ),
                    wp_kses_post( get_the_title() )
                )
            );
            echo '</span>';
        }

        edit_post_link(
            sprintf(
                wp_kses(
                    /* translators: %s: Name of current post. Only visible to screen readers */
                    __( 'Edit <span class="screen-reader-text">%s</span>', 'bella-italia-journey' ),
                    array(
                        'span' => array(
                            'class' => array(),
                        ),
                    )
                ),
                wp_kses_post( get_the_title() )
            ),
            '<span class="edit-link"><i class="fa fa-edit"></i> ',
            '</span>'
        );
    }
endif;

/**
 * Display category/tag/term description on archive pages.
 */
if ( ! function_exists( 'bella_italia_category_description' ) ) :
    function bella_italia_category_description() {
        if ( is_category() || is_tag() || is_tax() ) {
            $description = term_description();
            if ( $description ) {
                echo '<div class="archive-description">' . wp_kses_post( $description ) . '</div>';
            }
        }
    }
endif;

/**
 * Display pagination for archive pages.
 */
if ( ! function_exists( 'bella_italia_pagination' ) ) :
    function bella_italia_pagination() {
        global $wp_query;
        
        if ( $wp_query->max_num_pages <= 1 ) {
            return;
        }
        
        $big = 999999999; // Need an unlikely integer
        
        $pages = paginate_links( array(
            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format'    => '?paged=%#%',
            'current'   => max( 1, get_query_var( 'paged' ) ),
            'total'     => $wp_query->max_num_pages,
            'type'      => 'array',
            'prev_text' => '<i class="fa fa-angle-left"></i> ' . __( 'Previous', 'bella-italia-journey' ),
            'next_text' => __( 'Next', 'bella-italia-journey' ) . ' <i class="fa fa-angle-right"></i>',
        ) );
        
        if ( is_array( $pages ) ) {
            echo '<nav class="pagination-nav" aria-label="' . esc_attr__( 'Posts Navigation', 'bella-italia-journey' ) . '">';
            echo '<ul class="pagination">';
            
            foreach ( $pages as $page ) {
                $active = strpos( $page, 'current' ) !== false ? ' active' : '';
                echo '<li class="page-item' . $active . '">';
                echo str_replace( 'page-numbers', 'page-link', $page );
                echo '</li>';
            }
            
            echo '</ul>';
            echo '</nav>';
        }
    }
endif;

/**
 * Output breadcrumbs navigation.
 */
if ( ! function_exists( 'bella_italia_breadcrumbs' ) ) :
    function bella_italia_breadcrumbs() {
        // Skip if on homepage
        if ( is_front_page() ) {
            return;
        }
        
        // Check if breadcrumbs are enabled in theme options
        $show_breadcrumbs = get_theme_mod( 'bella_italia_show_breadcrumbs', true );
        
        if ( ! $show_breadcrumbs ) {
            return;
        }
        
        echo '<div class="breadcrumbs-wrapper py-2 bg-light">';
        echo '<div class="container">';
        echo '<nav aria-label="' . esc_attr__( 'Breadcrumb', 'bella-italia-journey' ) . '">';
        echo '<ol class="breadcrumb mb-0">';
        
        // Home link
        echo '<li class="breadcrumb-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'bella-italia-journey' ) . '</a></li>';
        
        if ( is_category() || is_single() ) {
            if ( is_category() ) {
                // Category archive
                echo '<li class="breadcrumb-item active" aria-current="page">' . single_cat_title( '', false ) . '</li>';
            } elseif ( is_single() ) {
                // Single post
                if ( 'post' === get_post_type() ) {
                    // Get the first category
                    $categories = get_the_category();
                    if ( ! empty( $categories ) ) {
                        echo '<li class="breadcrumb-item"><a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a></li>';
                    }
                    echo '<li class="breadcrumb-item active" aria-current="page">' . get_the_title() . '</li>';
                } elseif ( 'destination' === get_post_type() ) {
                    // Destination post type
                    echo '<li class="breadcrumb-item"><a href="' . esc_url( get_post_type_archive_link( 'destination' ) ) . '">' . esc_html__( 'Destinations', 'bella-italia-journey' ) . '</a></li>';
                    
                    // Get the region if available
                    $regions = get_the_terms( get_the_ID(), 'region' );
                    if ( $regions && ! is_wp_error( $regions ) ) {
                        $region = reset( $regions );
                        echo '<li class="breadcrumb-item"><a href="' . esc_url( get_term_link( $region ) ) . '">' . esc_html( $region->name ) . '</a></li>';
                    }
                    
                    echo '<li class="breadcrumb-item active" aria-current="page">' . get_the_title() . '</li>';
                } else {
                    // Other post types
                    $post_type = get_post_type_object( get_post_type() );
                    echo '<li class="breadcrumb-item"><a href="' . esc_url( get_post_type_archive_link( get_post_type() ) ) . '">' . esc_html( $post_type->labels->name ) . '</a></li>';
                    echo '<li class="breadcrumb-item active" aria-current="page">' . get_the_title() . '</li>';
                }
            }
        } elseif ( is_page() ) {
            // Pages
            $parent_id = wp_get_post_parent_id( get_the_ID() );
            if ( $parent_id ) {
                echo '<li class="breadcrumb-item"><a href="' . esc_url( get_permalink( $parent_id ) ) . '">' . esc_html( get_the_title( $parent_id ) ) . '</a></li>';
            }
            echo '<li class="breadcrumb-item active" aria-current="page">' . get_the_title() . '</li>';
        } elseif ( is_post_type_archive() ) {
            // Post type archives
            $post_type = get_post_type_object( get_post_type() );
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html( $post_type->labels->name ) . '</li>';
        } elseif ( is_tag() ) {
            // Tag archives
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html__( 'Tagged: ', 'bella-italia-journey' ) . single_tag_title( '', false ) . '</li>';
        } elseif ( is_author() ) {
            // Author archives
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html__( 'Author: ', 'bella-italia-journey' ) . get_the_author() . '</li>';
        } elseif ( is_search() ) {
            // Search results
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html__( 'Search Results', 'bella-italia-journey' ) . '</li>';
        } elseif ( is_tax( 'region' ) ) {
            // Region taxonomy archive
            echo '<li class="breadcrumb-item"><a href="' . esc_url( get_post_type_archive_link( 'destination' ) ) . '">' . esc_html__( 'Destinations', 'bella-italia-journey' ) . '</a></li>';
            echo '<li class="breadcrumb-item active" aria-current="page">' . single_term_title( '', false ) . '</li>';
        } elseif ( is_404() ) {
            // 404 page
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html__( 'Page Not Found', 'bella-italia-journey' ) . '</li>';
        }
        
        echo '</ol>';
        echo '</nav>';
        echo '</div>';
        echo '</div>';
    }
endif;

/**
 * Display social media links
 */
if ( ! function_exists( 'bella_italia_social_links' ) ) :
    function bella_italia_social_links() {
        // Get social links from theme options
        $facebook_url  = get_theme_mod( 'bella_italia_facebook_url' );
        $twitter_url   = get_theme_mod( 'bella_italia_twitter_url' );
        $instagram_url = get_theme_mod( 'bella_italia_instagram_url' );
        $youtube_url   = get_theme_mod( 'bella_italia_youtube_url' );
        $tiktok_url    = get_theme_mod( 'bella_italia_tiktok_url' );
        $pinterest_url = get_theme_mod( 'bella_italia_pinterest_url' );
        
        // Only proceed if at least one social link is set
        if ( ! $facebook_url && ! $twitter_url && ! $instagram_url && ! $youtube_url && ! $tiktok_url && ! $pinterest_url ) {
            return;
        }
        
        echo '<ul class="social-icons">';
        
        if ( $facebook_url ) {
            echo '<li><a href="' . esc_url( $facebook_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Facebook', 'bella-italia-journey' ) . '"><i class="fa fa-facebook"></i></a></li>';
        }
        
        if ( $twitter_url ) {
            echo '<li><a href="' . esc_url( $twitter_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Twitter', 'bella-italia-journey' ) . '"><i class="fa fa-twitter"></i></a></li>';
        }
        
        if ( $instagram_url ) {
            echo '<li><a href="' . esc_url( $instagram_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Instagram', 'bella-italia-journey' ) . '"><i class="fa fa-instagram"></i></a></li>';
        }
        
        if ( $youtube_url ) {
            echo '<li><a href="' . esc_url( $youtube_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'YouTube', 'bella-italia-journey' ) . '"><i class="fa fa-youtube"></i></a></li>';
        }
        
        if ( $tiktok_url ) {
            echo '<li><a href="' . esc_url( $tiktok_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'TikTok', 'bella-italia-journey' ) . '"><i class="fa fa-tiktok"></i></a></li>';
        }
        
        if ( $pinterest_url ) {
            echo '<li><a href="' . esc_url( $pinterest_url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Pinterest', 'bella-italia-journey' ) . '"><i class="fa fa-pinterest"></i></a></li>';
        }
        
        echo '</ul>';
    }
endif;

/**
 * Fallback for primary menu if no menu is assigned
 */
if ( ! function_exists( 'bella_italia_primary_menu_fallback' ) ) :
    function bella_italia_primary_menu_fallback() {
        if ( current_user_can( 'edit_theme_options' ) ) {
            echo '<ul id="primary-menu" class="primary-menu">';
            echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Create a menu', 'bella-italia-journey' ) . '</a></li>';
            echo '</ul>';
        } else {
            echo '<ul id="primary-menu" class="primary-menu">';
            echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'bella-italia-journey' ) . '</a></li>';
            
            // Get 5 most recent pages
            $recent_pages = get_pages( array(
                'sort_column' => 'post_date',
                'sort_order'  => 'DESC',
                'number'      => 5,
            ) );
            
            foreach ( $recent_pages as $page ) {
                echo '<li><a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( $page->post_title ) . '</a></li>';
            }
            
            echo '</ul>';
        }
    }
endif;