<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function bella_italia_body_classes( $classes ) {
    // Adds a class of hfeed to non-singular pages.
    if ( ! is_singular() ) {
        $classes[] = 'hfeed';
    }

    // Adds a class of no-sidebar when there is no sidebar present.
    if ( ! is_active_sidebar( 'sidebar-1' ) ) {
        $classes[] = 'no-sidebar';
    }
    
    // Add class based on the customizer setting for sidebar position
    $sidebar_position = get_theme_mod( 'bella_italia_sidebar_position', 'right' );
    $classes[] = 'sidebar-' . $sidebar_position;
    
    // Add class based on the customizer setting for header style
    $header_style = get_theme_mod( 'bella_italia_header_style', 'default' );
    $classes[] = 'header-style-' . $header_style;
    
    // Add class for language
    $classes[] = 'lang-' . get_locale();
    
    // Add class if sticky header is enabled
    if ( get_theme_mod( 'bella_italia_enable_sticky_header', true ) ) {
        $classes[] = 'has-sticky-header';
    }
    
    // Add class for current page/post type
    if ( is_singular() ) {
        $classes[] = 'single-' . get_post_type();
    } elseif ( is_archive() ) {
        $classes[] = 'archive-' . get_post_type();
    }
    
    return $classes;
}
add_filter( 'body_class', 'bella_italia_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function bella_italia_pingback_header() {
    if ( is_singular() && pings_open() ) {
        printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}
add_action( 'wp_head', 'bella_italia_pingback_header' );

/**
 * Change the excerpt length
 */
function bella_italia_excerpt_length( $length ) {
    $excerpt_length = get_theme_mod( 'bella_italia_excerpt_length', 30 );
    return $excerpt_length;
}
add_filter( 'excerpt_length', 'bella_italia_excerpt_length' );

/**
 * Change the excerpt more string
 */
function bella_italia_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'bella_italia_excerpt_more' );

/**
 * Filter the archive title
 */
function bella_italia_archive_title( $title ) {
    if ( is_category() ) {
        $title = single_cat_title( '', false );
    } elseif ( is_tag() ) {
        $title = single_tag_title( '', false );
    } elseif ( is_author() ) {
        $title = get_the_author();
    } elseif ( is_post_type_archive() ) {
        $title = post_type_archive_title( '', false );
    } elseif ( is_tax() ) {
        $title = single_term_title( '', false );
    }

    return $title;
}
add_filter( 'get_the_archive_title', 'bella_italia_archive_title' );

/**
 * Add classes to post thumbnail
 */
function bella_italia_post_thumbnail_classes( $attr ) {
    if ( ! isset( $attr['class'] ) ) {
        $attr['class'] = '';
    }

    $attr['class'] .= ' img-fluid';

    return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'bella_italia_post_thumbnail_classes', 10, 1 );

/**
 * Add language selector to WordPress login page
 */
function bella_italia_add_language_selector_to_login() {
    // Only if language plugins are active
    if ( function_exists( 'pll_the_languages' ) || function_exists( 'icl_get_languages' ) ) {
        echo '<div class="language-selector-login">';
        
        if ( function_exists( 'pll_the_languages' ) ) {
            $args = array(
                'dropdown'              => 1,
                'show_names'            => 1,
                'display_names_as'      => 'name',
                'show_flags'            => 1,
                'hide_if_empty'         => 0,
                'hide_if_no_translation' => 0,
                'hide_current'          => 0,
            );
            pll_the_languages( $args );
        } elseif ( function_exists( 'icl_get_languages' ) ) {
            $languages = icl_get_languages( 'skip_missing=0' );
            if ( ! empty( $languages ) ) {
                echo '<select onchange="window.location.href=this.value">';
                foreach ( $languages as $lang ) {
                    $selected = $lang['active'] ? ' selected="selected"' : '';
                    echo '<option value="' . esc_url( $lang['url'] ) . '"' . $selected . '>' . esc_html( $lang['native_name'] ) . '</option>';
                }
                echo '</select>';
            }
        }
        
        echo '</div>';
    }
}
add_action( 'login_footer', 'bella_italia_add_language_selector_to_login' );

/**
 * Add some fields to user profile
 */
function bella_italia_add_custom_user_profile_fields( $user ) {
    ?>
    <h3><?php _e( 'Social Media Information', 'bella-italia-journey' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="twitter"><?php _e( 'Twitter', 'bella-italia-journey' ); ?></label></th>
            <td>
                <input type="text" name="twitter" id="twitter" value="<?php echo esc_attr( get_the_author_meta( 'twitter', $user->ID ) ); ?>" class="regular-text" />
                <span class="description"><?php _e( 'Please enter your Twitter username (without @).', 'bella-italia-journey' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="instagram"><?php _e( 'Instagram', 'bella-italia-journey' ); ?></label></th>
            <td>
                <input type="text" name="instagram" id="instagram" value="<?php echo esc_attr( get_the_author_meta( 'instagram', $user->ID ) ); ?>" class="regular-text" />
                <span class="description"><?php _e( 'Please enter your Instagram username.', 'bella-italia-journey' ); ?></span>
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'bella_italia_add_custom_user_profile_fields' );
add_action( 'edit_user_profile', 'bella_italia_add_custom_user_profile_fields' );

/**
 * Save additional user profile fields
 */
function bella_italia_save_custom_user_profile_fields( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) {
        return false;
    }
    
    if ( isset( $_POST['twitter'] ) ) {
        update_user_meta( $user_id, 'twitter', sanitize_text_field( $_POST['twitter'] ) );
    }
    
    if ( isset( $_POST['instagram'] ) ) {
        update_user_meta( $user_id, 'instagram', sanitize_text_field( $_POST['instagram'] ) );
    }
}
add_action( 'personal_options_update', 'bella_italia_save_custom_user_profile_fields' );
add_action( 'edit_user_profile_update', 'bella_italia_save_custom_user_profile_fields' );

/**
 * Add author social links to author bio
 */
function bella_italia_author_social_links( $author_id = false ) {
    if ( ! $author_id ) {
        $author_id = get_the_author_meta( 'ID' );
    }
    
    $twitter = get_the_author_meta( 'twitter', $author_id );
    $instagram = get_the_author_meta( 'instagram', $author_id );
    
    if ( ! empty( $twitter ) || ! empty( $instagram ) ) {
        echo '<div class="author-social-links">';
        
        if ( ! empty( $twitter ) ) {
            echo '<a href="' . esc_url( 'https://twitter.com/' . $twitter ) . '" class="author-social-link twitter" target="_blank" rel="noopener noreferrer"><i class="fa fa-twitter"></i></a>';
        }
        
        if ( ! empty( $instagram ) ) {
            echo '<a href="' . esc_url( 'https://instagram.com/' . $instagram ) . '" class="author-social-link instagram" target="_blank" rel="noopener noreferrer"><i class="fa fa-instagram"></i></a>';
        }
        
        echo '</div>';
    }
}

/**
 * Add destination custom fields to REST API
 */
function bella_italia_register_destination_meta_rest_api() {
    register_rest_field(
        'destination',
        'destination_details',
        array(
            'get_callback'    => 'bella_italia_get_destination_meta',
            'update_callback' => null,
            'schema'          => null,
        )
    );
}
add_action( 'rest_api_init', 'bella_italia_register_destination_meta_rest_api' );

/**
 * Get destination meta for REST API
 */
function bella_italia_get_destination_meta( $object, $field_name, $request ) {
    $post_id = $object['id'];
    
    return array(
        'location'        => get_post_meta( $post_id, '_destination_location', true ),
        'map_lat'         => get_post_meta( $post_id, '_destination_map_lat', true ),
        'map_lng'         => get_post_meta( $post_id, '_destination_map_lng', true ),
        'map_zoom'        => get_post_meta( $post_id, '_destination_map_zoom', true ),
        'local_food'      => get_post_meta( $post_id, '_destination_local_food', true ),
        'local_drink'     => get_post_meta( $post_id, '_destination_local_drink', true ),
        'accommodation'   => get_post_meta( $post_id, '_destination_accommodation', true ),
        'must_see'        => get_post_meta( $post_id, '_destination_must_see', true ),
        'best_experience' => get_post_meta( $post_id, '_destination_best_experience', true ),
        'featured'        => get_post_meta( $post_id, '_featured_destination', true ),
    );
}

/**
 * Get related posts by category or tag
 */
function bella_italia_get_related_posts( $post_id, $related_count = 3, $args = array() ) {
    $args = wp_parse_args(
        (array) $args,
        array(
            'orderby'        => 'rand',
            'post__not_in'   => array( $post_id ),
            'posts_per_page' => $related_count,
        )
    );
    
    $post_type = get_post_type( $post_id );
    $args['post_type'] = $post_type;
    
    // Get posts by category
    if ( 'post' === $post_type ) {
        $cats = get_the_category( $post_id );
        if ( $cats ) {
            $cat_ids = array();
            foreach ( $cats as $cat ) {
                $cat_ids[] = $cat->term_id;
            }
            $args['category__in'] = $cat_ids;
        }
    } elseif ( 'destination' === $post_type ) {
        // For destination post type, get by region
        $regions = get_the_terms( $post_id, 'region' );
        if ( $regions && ! is_wp_error( $regions ) ) {
            $region_ids = array();
            foreach ( $regions as $region ) {
                $region_ids[] = $region->term_id;
            }
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'region',
                    'field'    => 'term_id',
                    'terms'    => $region_ids,
                ),
            );
        }
    }
    
    $related = new WP_Query( $args );
    
    return $related;
}

/**
 * Custom search form
 */
function bella_italia_search_form( $form ) {
    $form = '<form role="search" method="get" class="search-form" action="' . esc_url( home_url( '/' ) ) . '">
        <div class="input-group">
            <input type="search" class="search-field form-control" placeholder="' . esc_attr_x( 'Search&hellip;', 'placeholder', 'bella-italia-journey' ) . '" value="' . get_search_query() . '" name="s" />
            <div class="input-group-append">
                <button type="submit" class="search-submit btn btn-primary">
                    <i class="fa fa-search"></i>
                    <span class="screen-reader-text">' . _x( 'Search', 'submit button', 'bella-italia-journey' ) . '</span>
                </button>
            </div>
        </div>
    </form>';

    return $form;
}
add_filter( 'get_search_form', 'bella_italia_search_form' );

/**
 * Add admin column for featured destinations
 */
function bella_italia_add_admin_columns( $columns ) {
    $new_columns = array();
    
    foreach ( $columns as $key => $value ) {
        if ( 'title' === $key ) {
            $new_columns[$key] = $value;
            $new_columns['featured'] = __( 'Featured', 'bella-italia-journey' );
        } else {
            $new_columns[$key] = $value;
        }
    }
    
    return $new_columns;
}
add_filter( 'manage_destination_posts_columns', 'bella_italia_add_admin_columns' );

/**
 * Add content to custom admin columns
 */
function bella_italia_custom_column_content( $column, $post_id ) {
    if ( 'featured' === $column ) {
        $featured = get_post_meta( $post_id, '_featured_destination', true );
        
        if ( $featured ) {
            echo '<span class="dashicons dashicons-star-filled" style="color: #ffb900;"></span>';
        } else {
            echo '<span class="dashicons dashicons-star-empty"></span>';
        }
    }
}
add_action( 'manage_destination_posts_custom_column', 'bella_italia_custom_column_content', 10, 2 );

/**
 * Add custom post type and taxonomy to Yoast SEO sitemap
 */
function bella_italia_add_to_yoast_sitemap( $post_types ) {
    $post_types[] = 'destination';
    return $post_types;
}
add_filter( 'wpseo_sitemap_exclude_post_type', 'bella_italia_add_to_yoast_sitemap', 10, 1 );

/**
 * Add styles to the WordPress editor
 */
function bella_italia_add_editor_styles() {
    add_editor_style( 'assets/css/editor-style.css' );
    
    // Add custom fonts
    $font_url = bella_italia_get_google_fonts_url();
    if ( $font_url ) {
        add_editor_style( $font_url );
    }
}
add_action( 'after_setup_theme', 'bella_italia_add_editor_styles' );

/**
 * Get Google Fonts URL
 */
function bella_italia_get_google_fonts_url() {
    $fonts_url = '';
    
    // Define font families
    $font_families = array();
    
    // Add custom font families from theme options
    $body_font = get_theme_mod( 'bella_italia_body_font', 'Open Sans' );
    $heading_font = get_theme_mod( 'bella_italia_heading_font', 'Playfair Display' );
    
    if ( $body_font ) {
        $font_families[] = $body_font . ':400,400i,700,700i';
    }
    
    if ( $heading_font && $heading_font !== $body_font ) {
        $font_families[] = $heading_font . ':400,400i,700,700i';
    }
    
    if ( empty( $font_families ) ) {
        return false;
    }
    
    // Build font URL
    $query_args = array(
        'family' => urlencode( implode( '|', $font_families ) ),
        'subset' => urlencode( 'latin,latin-ext' ),
        'display' => 'swap',
    );
    
    $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    
    return esc_url_raw( $fonts_url );
}

/**
 * Register custom query vars
 */
function bella_italia_register_query_vars( $vars ) {
    $vars[] = 'region';
    $vars[] = 'interest';
    return $vars;
}
add_filter( 'query_vars', 'bella_italia_register_query_vars' );

/**
 * Add Schema.org structured data
 */
function bella_italia_add_schema_data() {
    // Only add schema data on single posts and pages
    if ( ! is_singular() ) {
        return;
    }
    
    $schema = array(
        '@context' => 'https://schema.org',
    );
    
    if ( is_singular( 'post' ) ) {
        $schema['@type'] = 'BlogPosting';
        $schema['headline'] = get_the_title();
        $schema['datePublished'] = get_the_date( 'c' );
        $schema['dateModified'] = get_the_modified_date( 'c' );
        
        // Add featured image
        if ( has_post_thumbnail() ) {
            $schema['image'] = array(
                '@type' => 'ImageObject',
                'url' => get_the_post_thumbnail_url( null, 'full' ),
            );
        }
        
        // Add author
        $schema['author'] = array(
            '@type' => 'Person',
            'name' => get_the_author(),
        );
        
        // Add publisher
        $schema['publisher'] = array(
            '@type' => 'Organization',
            'name' => get_bloginfo( 'name' ),
            'logo' => array(
                '@type' => 'ImageObject',
                'url' => get_theme_mod( 'bella_italia_logo' ) ? get_theme_mod( 'bella_italia_logo' ) : '',
            ),
        );
        
        // Add main entity of page
        $schema['mainEntityOfPage'] = array(
            '@type' => 'WebPage',
            '@id' => get_permalink(),
        );
    } elseif ( is_singular( 'destination' ) ) {
        $schema['@type'] = 'TouristAttraction';
        $schema['name'] = get_the_title();
        $schema['description'] = get_the_excerpt();
        
        // Add location data
        $location = get_post_meta( get_the_ID(), '_destination_location', true );
        $lat = get_post_meta( get_the_ID(), '_destination_map_lat', true );
        $lng = get_post_meta( get_the_ID(), '_destination_map_lng', true );
        
        if ( $location ) {
            $schema['address'] = $location;
        }
        
        if ( $lat && $lng ) {
            $schema['geo'] = array(
                '@type' => 'GeoCoordinates',
                'latitude' => $lat,
                'longitude' => $lng,
            );
        }
        
        // Add featured image
        if ( has_post_thumbnail() ) {
            $schema['image'] = get_the_post_thumbnail_url( null, 'full' );
        }
    } elseif ( is_page() ) {
        $schema['@type'] = 'WebPage';
        $schema['name'] = get_the_title();
        $schema['description'] = get_the_excerpt();
        
        // Add featured image
        if ( has_post_thumbnail() ) {
            $schema['image'] = get_the_post_thumbnail_url( null, 'full' );
        }
    }
    
    if ( ! empty( $schema ) ) {
        echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
    }
}
add_action( 'wp_head', 'bella_italia_add_schema_data' );

/**
 * Flush rewrite rules on theme activation
 */
function bella_italia_rewrite_flush() {
    // First register post types and taxonomies
    bella_italia_register_destination_post_type();
    bella_italia_register_region_taxonomy();
    
    // Then flush rewrite rules
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'bella_italia_rewrite_flush' );