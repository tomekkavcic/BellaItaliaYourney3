<?php
/**
 * Custom widgets for Bella Italia Journey theme
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Featured Destinations Widget
 */
class Bella_Italia_Featured_Destinations_Widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'bella_italia_featured_destinations',
            __( 'Bella Italia: Featured Destinations', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display featured destinations', 'bella-italia-journey' ),
            )
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        // Widget title
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Number of destinations to show
        $number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 3;
        
        // Query featured destinations
        $featured_query = new WP_Query( array(
            'post_type'      => 'destination',
            'posts_per_page' => $number,
            'meta_query'     => array(
                array(
                    'key'   => '_featured_destination',
                    'value' => '1',
                ),
            ),
        ) );
        
        // If no featured destinations, get latest destinations
        if ( ! $featured_query->have_posts() ) {
            $featured_query = new WP_Query( array(
                'post_type'      => 'destination',
                'posts_per_page' => $number,
            ) );
        }
        
        if ( $featured_query->have_posts() ) :
        ?>
            <div class="widget-featured-destinations">
                <?php while ( $featured_query->have_posts() ) : $featured_query->the_post(); ?>
                    <div class="widget-destination-item">
                        <div class="widget-destination-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <?php the_post_thumbnail( 'bella-italia-card', array( 'class' => 'img-fluid' ) ); ?>
                                <?php else : ?>
                                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/placeholder.jpg' ); ?>" alt="<?php the_title_attribute(); ?>" class="img-fluid" />
                                <?php endif; ?>
                            </a>
                        </div>
                        
                        <div class="widget-destination-content">
                            <h4 class="widget-destination-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h4>
                            
                            <?php 
                            // Get location
                            $location = get_post_meta( get_the_ID(), '_destination_location', true );
                            
                            if ( $location ) : 
                            ?>
                                <div class="widget-destination-location">
                                    <i class="fa fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
                
                <div class="widget-more-destinations">
                    <a href="<?php echo esc_url( get_post_type_archive_link( 'destination' ) ); ?>" class="btn btn-sm btn-outline-primary">
                        <?php _e( 'View All Destinations', 'bella-italia-journey' ); ?>
                    </a>
                </div>
            </div>
        <?php
        endif;
        
        wp_reset_postdata();
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Featured Destinations', 'bella-italia-journey' );
        $number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 3;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of destinations to show:', 'bella-italia-journey' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1" value="<?php echo esc_attr( $number ); ?>" size="3">
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['number'] = ( ! empty( $new_instance['number'] ) ) ? absint( $new_instance['number'] ) : 3;

        return $instance;
    }
}

/**
 * Recent Posts Widget with Thumbnails
 */
class Bella_Italia_Recent_Posts_Widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'bella_italia_recent_posts',
            __( 'Bella Italia: Recent Posts', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display recent posts with thumbnails', 'bella-italia-journey' ),
            )
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        // Widget title
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Number of posts to show
        $number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 5;
        
        // Show post date
        $show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
        
        // Query recent posts
        $recent_posts = new WP_Query( array(
            'post_type'      => 'post',
            'posts_per_page' => $number,
            'no_found_rows'  => true,
        ) );
        
        if ( $recent_posts->have_posts() ) :
        ?>
            <ul class="widget-recent-posts">
                <?php while ( $recent_posts->have_posts() ) : $recent_posts->the_post(); ?>
                    <li class="widget-post-item">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="widget-post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'thumbnail', array( 'class' => 'img-fluid' ) ); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="widget-post-content">
                            <h5 class="widget-post-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h5>
                            
                            <?php if ( $show_date ) : ?>
                                <div class="widget-post-date">
                                    <i class="fa fa-calendar"></i> <?php echo get_the_date(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php
        endif;
        
        wp_reset_postdata();
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Recent Posts', 'bella-italia-journey' );
        $number = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 5;
        $show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'bella-italia-journey' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1" value="<?php echo esc_attr( $number ); ?>" size="3">
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>">
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php esc_html_e( 'Display post date?', 'bella-italia-journey' ); ?></label>
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['number'] = ( ! empty( $new_instance['number'] ) ) ? absint( $new_instance['number'] ) : 5;
        $instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;

        return $instance;
    }
}

/**
 * Region Map Widget
 */
class Bella_Italia_Region_Map_Widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'bella_italia_region_map',
            __( 'Bella Italia: Region Map', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display an interactive Italy map with regions', 'bella-italia-journey' ),
            )
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        // Widget title
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Map style
        $map_style = ! empty( $instance['map_style'] ) ? $instance['map_style'] : 'simple';
        
        // Show pins
        $show_pins = isset( $instance['show_pins'] ) ? (bool) $instance['show_pins'] : false;
        
        // Show region names
        $show_region_names = isset( $instance['show_region_names'] ) ? (bool) $instance['show_region_names'] : true;
        
        // Show legend
        $show_legend = isset( $instance['show_legend'] ) ? (bool) $instance['show_legend'] : false;
        
        // Active region (if on a region archive)
        $active_region = '';
        if ( is_tax( 'region' ) ) {
            $term = get_queried_object();
            if ( $term && isset( $term->slug ) ) {
                $active_region = $term->slug;
            }
        }
        
        // Display map
        get_template_part( 'template-parts/italy-map', null, array(
            'active_region'    => $active_region,
            'map_style'        => $map_style,
            'show_pins'        => $show_pins,
            'show_region_names' => $show_region_names,
            'show_legend'      => $show_legend,
            'map_classes'      => 'widget-map',
        ) );
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Explore Italian Regions', 'bella-italia-journey' );
        $map_style = ! empty( $instance['map_style'] ) ? $instance['map_style'] : 'simple';
        $show_pins = isset( $instance['show_pins'] ) ? (bool) $instance['show_pins'] : false;
        $show_region_names = isset( $instance['show_region_names'] ) ? (bool) $instance['show_region_names'] : true;
        $show_legend = isset( $instance['show_legend'] ) ? (bool) $instance['show_legend'] : false;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'map_style' ) ); ?>"><?php esc_html_e( 'Map Style:', 'bella-italia-journey' ); ?></label>
            <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'map_style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'map_style' ) ); ?>">
                <option value="simple" <?php selected( $map_style, 'simple' ); ?>><?php esc_html_e( 'Simple', 'bella-italia-journey' ); ?></option>
                <option value="detailed" <?php selected( $map_style, 'detailed' ); ?>><?php esc_html_e( 'Detailed', 'bella-italia-journey' ); ?></option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_pins ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_pins' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_pins' ) ); ?>">
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_pins' ) ); ?>"><?php esc_html_e( 'Show destination pins?', 'bella-italia-journey' ); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_region_names ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_region_names' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_region_names' ) ); ?>">
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_region_names' ) ); ?>"><?php esc_html_e( 'Show region names?', 'bella-italia-journey' ); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_legend ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_legend' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_legend' ) ); ?>">
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_legend' ) ); ?>"><?php esc_html_e( 'Show map legend?', 'bella-italia-journey' ); ?></label>
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['map_style'] = ( ! empty( $new_instance['map_style'] ) ) ? sanitize_text_field( $new_instance['map_style'] ) : 'simple';
        $instance['show_pins'] = isset( $new_instance['show_pins'] ) ? (bool) $new_instance['show_pins'] : false;
        $instance['show_region_names'] = isset( $new_instance['show_region_names'] ) ? (bool) $new_instance['show_region_names'] : true;
        $instance['show_legend'] = isset( $new_instance['show_legend'] ) ? (bool) $new_instance['show_legend'] : false;

        return $instance;
    }
}

/**
 * About Italy Widget
 */
class Bella_Italia_About_Italy_Widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'bella_italia_about_italy',
            __( 'Bella Italia: About Italy', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display a brief introduction about Italy', 'bella-italia-journey' ),
            )
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        // Widget title
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Widget content
        $content = ! empty( $instance['content'] ) ? $instance['content'] : '';
        
        // Show image
        $show_image = isset( $instance['show_image'] ) ? (bool) $instance['show_image'] : true;
        
        // Display widget
        ?>
        <div class="widget-about-italy">
            <?php if ( $show_image ) : ?>
                <div class="widget-about-image">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/italy-map.png' ); ?>" alt="<?php esc_attr_e( 'Map of Italy', 'bella-italia-journey' ); ?>" class="img-fluid" />
                </div>
            <?php endif; ?>
            
            <?php if ( $content ) : ?>
                <div class="widget-about-content">
                    <?php echo wpautop( wp_kses_post( $content ) ); ?>
                </div>
            <?php endif; ?>
            
            <div class="widget-about-regions">
                <div class="region-count-box">
                    <span class="region-count">20</span>
                    <span class="region-label"><?php _e( 'Regions', 'bella-italia-journey' ); ?></span>
                </div>
            </div>
            
            <div class="widget-about-flag">
                <div class="italian-flag-small">
                    <span class="flag-green"></span>
                    <span class="flag-white"></span>
                    <span class="flag-red"></span>
                </div>
            </div>
        </div>
        <?php
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'About Italy', 'bella-italia-journey' );
        $content = ! empty( $instance['content'] ) ? $instance['content'] : __( 'Italy, a country in southern Europe, is known for its rich history, art, culture, and cuisine. With its diverse landscapes, from the Alps to Mediterranean beaches, Italy offers unforgettable experiences for travelers.', 'bella-italia-journey' );
        $show_image = isset( $instance['show_image'] ) ? (bool) $instance['show_image'] : true;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content:', 'bella-italia-journey' ); ?></label>
            <textarea class="widefat" rows="5" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>"><?php echo esc_textarea( $content ); ?></textarea>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked( $show_image ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>">
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php esc_html_e( 'Show Italy map image?', 'bella-italia-journey' ); ?></label>
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['content'] = ( ! empty( $new_instance['content'] ) ) ? wp_kses_post( $new_instance['content'] ) : '';
        $instance['show_image'] = isset( $new_instance['show_image'] ) ? (bool) $new_instance['show_image'] : true;

        return $instance;
    }
}

/**
 * Newsletter Widget
 */
class Bella_Italia_Newsletter_Widget extends WP_Widget {
    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'bella_italia_newsletter',
            __( 'Bella Italia: Newsletter', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display a newsletter subscription form', 'bella-italia-journey' ),
            )
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        // Widget title
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Widget description
        $description = ! empty( $instance['description'] ) ? $instance['description'] : '';
        
        // Newsletter shortcode
        $shortcode = ! empty( $instance['shortcode'] ) ? $instance['shortcode'] : '';
        
        // Display widget
        ?>
        <div class="widget-newsletter">
            <?php if ( $description ) : ?>
                <div class="widget-newsletter-description">
                    <?php echo wpautop( wp_kses_post( $description ) ); ?>
                </div>
            <?php endif; ?>
            
            <div class="widget-newsletter-form">
                <?php 
                if ( $shortcode ) {
                    // Display newsletter form from shortcode
                    echo do_shortcode( $shortcode );
                } else {
                    // Display default form
                ?>
                    <form class="newsletter-subscribe-form" action="#" method="post">
                        <div class="form-group mb-3">
                            <input type="email" class="form-control" name="email" placeholder="<?php esc_attr_e( 'Your Email Address', 'bella-italia-journey' ); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary w-100">
                                <?php esc_html_e( 'Subscribe', 'bella-italia-journey' ); ?>
                            </button>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="privacyCheck" required>
                            <label class="form-check-label small" for="privacyCheck">
                                <?php 
                                $privacy_page = get_privacy_policy_url();
                                if ( $privacy_page ) {
                                    printf(
                                        __( 'I agree to the <a href="%s" target="_blank">privacy policy</a> and consent to receive email updates.', 'bella-italia-journey' ),
                                        esc_url( $privacy_page )
                                    );
                                } else {
                                    esc_html_e( 'I consent to receive email updates from Bella Italia Journey.', 'bella-italia-journey' );
                                }
                                ?>
                            </label>
                        </div>
                    </form>
                    <div class="newsletter-message d-none">
                        <div class="alert alert-success">
                            <?php esc_html_e( 'Thank you for subscribing!', 'bella-italia-journey' ); ?>
                        </div>
                    </div>
                <?php } ?>
            </div>
            
            <div class="widget-newsletter-flag">
                <div class="italian-flag-small">
                    <span class="flag-green"></span>
                    <span class="flag-white"></span>
                    <span class="flag-red"></span>
                </div>
            </div>
        </div>
        <?php
        
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Subscribe to Our Newsletter', 'bella-italia-journey' );
        $description = ! empty( $instance['description'] ) ? $instance['description'] : __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' );
        $shortcode = ! empty( $instance['shortcode'] ) ? $instance['shortcode'] : '';
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"><?php esc_html_e( 'Description:', 'bella-italia-journey' ); ?></label>
            <textarea class="widefat" rows="3" id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>"><?php echo esc_textarea( $description ); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'shortcode' ) ); ?>"><?php esc_html_e( 'Newsletter Form Shortcode:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'shortcode' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'shortcode' ) ); ?>" type="text" value="<?php echo esc_attr( $shortcode ); ?>">
            <span class="description"><?php _e( 'Enter shortcode from newsletter plugin (optional). If empty, default form will be used.', 'bella-italia-journey' ); ?></span>
        </p>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['description'] = ( ! empty( $new_instance['description'] ) ) ? wp_kses_post( $new_instance['description'] ) : '';
        $instance['shortcode'] = ( ! empty( $new_instance['shortcode'] ) ) ? $new_instance['shortcode'] : '';

        return $instance;
    }
}

/**
 * Register custom widgets
 */
function bella_italia_register_custom_widgets() {
    register_widget( 'Bella_Italia_Featured_Destinations_Widget' );
    register_widget( 'Bella_Italia_Recent_Posts_Widget' );
    register_widget( 'Bella_Italia_Region_Map_Widget' );
    register_widget( 'Bella_Italia_About_Italy_Widget' );
    register_widget( 'Bella_Italia_Newsletter_Widget' );
}
add_action( 'widgets_init', 'bella_italia_register_custom_widgets' );