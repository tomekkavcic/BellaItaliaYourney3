<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until main content
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bella_Italia_Journey
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'bella-italia-journey' ); ?></a>

	<?php bella_italia_do_before_header(); ?>

	<?php
	// Determine header style
	$header_style = get_theme_mod( 'bella_italia_header_style', 'default' );
	$header_class = 'site-header';
	$header_class .= ' ' . $header_style . '-header';
	
	// Add sticky class if enabled
	if ( get_theme_mod( 'bella_italia_enable_sticky_header', true ) ) {
		$header_class .= ' sticky-header';
	}
	?>

	<header id="masthead" class="<?php echo esc_attr( $header_class ); ?>">
		<div class="container">
			<div class="header-wrapper">
				<div class="site-branding">
					<?php
					// Check if custom logo is set
					if ( has_custom_logo() ) :
						the_custom_logo();
					else :
						if ( is_front_page() && is_home() ) :
							?>
							<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
							<?php
						else :
							?>
							<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
							<?php
						endif;
						
						$bella_italia_description = get_bloginfo( 'description', 'display' );
						if ( $bella_italia_description || is_customize_preview() ) :
							?>
							<p class="site-description"><?php echo $bella_italia_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
						<?php endif; ?>
					<?php endif; ?>
				</div><!-- .site-branding -->

				<nav id="site-navigation" class="main-navigation">
					<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
						<span class="menu-toggle-icon"></span>
						<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'bella-italia-journey' ); ?></span>
					</button>
					
					<?php
					// Display primary menu
					if ( has_nav_menu( 'primary' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'primary',
								'menu_id'        => 'primary-menu',
								'container_class' => 'primary-menu-container',
								'fallback_cb'    => 'bella_italia_primary_menu_fallback',
							)
						);
					} else {
						// Fallback if no menu is assigned
						bella_italia_primary_menu_fallback();
					}
					?>
					
					<div class="header-actions">
						<?php if ( get_theme_mod( 'bella_italia_show_search', true ) ) : ?>
							<div class="header-search">
								<button class="search-toggle" aria-expanded="false">
									<i class="fa fa-search"></i>
									<span class="screen-reader-text"><?php esc_html_e( 'Search', 'bella-italia-journey' ); ?></span>
								</button>
								<div class="header-search-form">
									<?php get_search_form(); ?>
								</div>
							</div>
						<?php endif; ?>
						
						<?php if ( get_theme_mod( 'bella_italia_show_language_switcher', true ) ) : ?>
							<div class="header-language">
								<?php
								// Display language switcher if WPML or Polylang is active
								if ( function_exists( 'pll_the_languages' ) ) {
									pll_the_languages( array(
										'dropdown'       => 1,
										'show_names'     => 1,
										'show_flags'     => 1,
										'hide_if_empty'  => 0,
									) );
								} elseif ( function_exists( 'icl_get_languages' ) ) {
									do_action( 'wpml_add_language_selector' );
								} else {
									// Display a message if translation plugins are not active
									if ( current_user_can( 'manage_options' ) ) {
										echo '<span class="language-notice">' . esc_html__( 'Install WPML or Polylang for multilingual support', 'bella-italia-journey' ) . '</span>';
									}
								}
								?>
							</div>
						<?php endif; ?>
					</div>
				</nav><!-- #site-navigation -->
			</div><!-- .header-wrapper -->
		</div><!-- .container -->
	</header><!-- #masthead -->

	<?php
	// Display custom header if it exists and we're on a page that should display it
	if ( bella_italia_has_header_media() ) :
	?>
		<div class="custom-header">
			<?php
			// Add header image or video
			if ( has_header_video() ) {
				bella_italia_header_video();
			}
			?>
			<div class="custom-header-overlay"></div>
			<?php bella_italia_header_content(); ?>
		</div>
	<?php
	endif;
	
	// Display breadcrumbs if enabled
	if ( get_theme_mod( 'bella_italia_show_breadcrumbs', true ) && ! is_front_page() ) {
		bella_italia_breadcrumbs();
	}
	?>

	<?php bella_italia_do_after_header(); ?>

	<div id="content" class="site-content">
		<div class="container">
			<div class="row">