<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

get_header();

// Determine sidebar position
$sidebar_position = get_theme_mod( 'bella_italia_sidebar_position', 'right' );
$content_class = 'content-area';

if ( is_active_sidebar( 'sidebar-1' ) ) {
	$content_class .= ' col-lg-9';
	if ( $sidebar_position === 'left' ) {
		$content_class .= ' order-lg-2';
	}
} else {
	$content_class .= ' col-lg-12';
}
?>

	<main id="primary" class="<?php echo esc_attr( $content_class ); ?>">

		<?php bella_italia_do_before_content(); ?>

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				bella_italia_category_description();
				?>
			</header><!-- .page-header -->

			<?php
			// Get archive layout
			$archive_layout = get_theme_mod( 'bella_italia_archive_layout', 'grid' );
			
			if ( $archive_layout === 'grid' || $archive_layout === 'masonry' ) {
				echo '<div class="row posts-row posts-' . esc_attr( $archive_layout ) . '">';
			}

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 */
				if ( $archive_layout === 'grid' ) {
					echo '<div class="col-md-6 col-lg-4 post-column">';
					get_template_part( 'template-parts/content', 'grid' );
					echo '</div>';
				} elseif ( $archive_layout === 'masonry' ) {
					echo '<div class="col-md-6 col-lg-4 post-column">';
					get_template_part( 'template-parts/content', 'masonry' );
					echo '</div>';
				} else {
					get_template_part( 'template-parts/content', get_post_type() );
				}

			endwhile;

			if ( $archive_layout === 'grid' || $archive_layout === 'masonry' ) {
				echo '</div>';
			}

			// Display pagination
			bella_italia_pagination();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		<?php bella_italia_do_after_content(); ?>

	</main><!-- #main -->

<?php
// Display sidebar if it's active
if ( is_active_sidebar( 'sidebar-1' ) ) :
	$sidebar_class = 'col-lg-3';
	if ( $sidebar_position === 'left' ) {
		$sidebar_class .= ' order-lg-1';
	}
	echo '<div class="' . esc_attr( $sidebar_class ) . '">';
	get_sidebar();
	echo '</div>';
endif;

get_footer();