<?php
/**
 * Bella Italia Journey functions and definitions
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Define theme version
define( 'BELLA_ITALIA_VERSION', '1.0.0' );

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function bella_italia_setup() {
    /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     */
    load_theme_textdomain( 'bella-italia-journey', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
     * Let WordPress manage the document title.
     * By adding theme support, we declare that this theme does not use a
     * hard-coded <title> tag in the document head, and expect WordPress to
     * provide it for us.
     */
    add_theme_support( 'title-tag' );

    /*
     * Enable support for Post Thumbnails on posts and pages.
     *
     * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
     */
    add_theme_support( 'post-thumbnails' );

    // Custom image sizes
    add_image_size( 'bella-italia-featured', 800, 600, true );
    add_image_size( 'bella-italia-hero', 1920, 1080, true );
    add_image_size( 'bella-italia-card', 600, 400, true );
    add_image_size( 'bella-italia-square', 400, 400, true );

    // This theme uses wp_nav_menu() in multiple locations.
    register_nav_menus( array(
        'primary'   => esc_html__( 'Primary Menu', 'bella-italia-journey' ),
        'footer'    => esc_html__( 'Footer Menu', 'bella-italia-journey' ),
        'social'    => esc_html__( 'Social Links Menu', 'bella-italia-journey' ),
        'languages' => esc_html__( 'Language Menu', 'bella-italia-journey' ),
    ) );

    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Set up the WordPress core custom background feature.
    add_theme_support( 'custom-background', apply_filters( 'bella_italia_custom_background_args', array(
        'default-color' => 'ffffff',
        'default-image' => '',
    ) ) );

    // Add theme support for selective refresh for widgets.
    add_theme_support( 'customize-selective-refresh-widgets' );

    /**
     * Add support for core custom logo.
     *
     * @link https://codex.wordpress.org/Theme_Logo
     */
    add_theme_support( 'custom-logo', array(
        'height'      => 250,
        'width'       => 250,
        'flex-width'  => true,
        'flex-height' => true,
    ) );

    // Add support for full and wide align images.
    add_theme_support( 'align-wide' );

    // Add support for responsive embedded content.
    add_theme_support( 'responsive-embeds' );

    // Add support for custom color scheme.
    add_theme_support( 'editor-color-palette', array(
        array(
            'name'  => esc_html__( 'Primary', 'bella-italia-journey' ),
            'slug'  => 'primary',
            'color' => '#007bff',
        ),
        array(
            'name'  => esc_html__( 'Secondary', 'bella-italia-journey' ),
            'slug'  => 'secondary',
            'color' => '#6c757d',
        ),
        array(
            'name'  => esc_html__( 'Success', 'bella-italia-journey' ),
            'slug'  => 'success',
            'color' => '#28a745',
        ),
        array(
            'name'  => esc_html__( 'Danger', 'bella-italia-journey' ),
            'slug'  => 'danger',
            'color' => '#dc3545',
        ),
        array(
            'name'  => esc_html__( 'Italian Green', 'bella-italia-journey' ),
            'slug'  => 'italian-green',
            'color' => '#008d46',
        ),
        array(
            'name'  => esc_html__( 'Italian White', 'bella-italia-journey' ),
            'slug'  => 'italian-white',
            'color' => '#f5f5f5',
        ),
        array(
            'name'  => esc_html__( 'Italian Red', 'bella-italia-journey' ),
            'slug'  => 'italian-red',
            'color' => '#cd212a',
        ),
    ) );
}
add_action( 'after_setup_theme', 'bella_italia_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function bella_italia_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'bella_italia_content_width', 1140 );
}
add_action( 'after_setup_theme', 'bella_italia_content_width', 0 );

/**
 * Register widget areas.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function bella_italia_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'bella-italia-journey' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'bella-italia-journey' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

    // Destination Sidebar
    register_sidebar( array(
        'name'          => esc_html__( 'Destination Sidebar', 'bella-italia-journey' ),
        'id'            => 'sidebar-destination',
        'description'   => esc_html__( 'Add widgets here to appear in destination single pages.', 'bella-italia-journey' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

    // Determine footer widget count
    $footer_widget_count = get_theme_mod( 'bella_italia_footer_widgets', 4 );
    
    // Register footer widget areas
    for ( $i = 1; $i <= $footer_widget_count; $i++ ) {
        register_sidebar( array(
            'name'          => sprintf( esc_html__( 'Footer %d', 'bella-italia-journey' ), $i ),
            'id'            => 'footer-' . $i,
            'description'   => sprintf( esc_html__( 'Add widgets here to appear in footer column %d.', 'bella-italia-journey' ), $i ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>',
        ) );
    }
}
add_action( 'widgets_init', 'bella_italia_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function bella_italia_scripts() {
    // Bootstrap CSS
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '5.1.3' );
    
    // Font Awesome
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/fontawesome-all.min.css', array(), '5.15.4' );
    
    // Google Fonts
    $font_url = bella_italia_get_google_fonts_url();
    if ( $font_url ) {
        wp_enqueue_style( 'bella-italia-google-fonts', $font_url, array(), BELLA_ITALIA_VERSION );
    }
    
    // Main stylesheet
    wp_enqueue_style( 'bella-italia-style', get_stylesheet_uri(), array(), BELLA_ITALIA_VERSION );

    // Theme stylesheet
    wp_enqueue_style( 'bella-italia-main', get_template_directory_uri() . '/assets/css/main.css', array(), BELLA_ITALIA_VERSION );
    
    // Bootstrap JS
    wp_enqueue_script( 'bootstrap-bundle', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array('jquery'), '5.1.3', true );
    
    // Main JavaScript file
    wp_enqueue_script( 'bella-italia-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), BELLA_ITALIA_VERSION, true );
    
    // Navigation JavaScript
    wp_enqueue_script( 'bella-italia-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array('jquery'), BELLA_ITALIA_VERSION, true );
    
    // Italy Map JavaScript
    wp_enqueue_script( 'bella-italia-map', get_template_directory_uri() . '/assets/js/italy-map.js', array('jquery'), BELLA_ITALIA_VERSION, true );

    // Localize script for map interactions
    wp_localize_script( 'bella-italia-map', 'bellaItaliaMapSettings', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'i18n' => array(
            'viewDestination' => __( 'View Destination', 'bella-italia-journey' ),
            'exploreRegion' => __( 'Explore Region', 'bella-italia-journey' ),
        ),
    ) );
    
    // Only load Google Maps API if needed and API key is provided
    $google_maps_api_key = get_theme_mod( 'bella_italia_google_maps_api_key', '' );
    if ( $google_maps_api_key && (is_singular( 'destination' ) || is_post_type_archive( 'destination' ) || is_tax( 'region' )) ) {
        wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=' . $google_maps_api_key, array(), null, true );
        wp_enqueue_script( 'bella-italia-destination-map', get_template_directory_uri() . '/assets/js/destination-map.js', array('jquery', 'google-maps'), BELLA_ITALIA_VERSION, true );
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'bella_italia_scripts' );

/**
 * Enqueue admin scripts and styles.
 */
function bella_italia_admin_scripts() {
    wp_enqueue_style( 'bella-italia-admin-style', get_template_directory_uri() . '/assets/css/admin.css', array(), BELLA_ITALIA_VERSION );
    
    // Destination post type edit screen
    if ( get_current_screen()->id === 'destination' ) {
        $google_maps_api_key = get_theme_mod( 'bella_italia_google_maps_api_key', '' );
        
        if ( $google_maps_api_key ) {
            wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=' . $google_maps_api_key, array(), null, true );
            wp_enqueue_script( 'bella-italia-admin-map', get_template_directory_uri() . '/assets/js/admin-map.js', array('jquery', 'google-maps'), BELLA_ITALIA_VERSION, true );
        }
    }
}
add_action( 'admin_enqueue_scripts', 'bella_italia_admin_scripts' );

/**
 * Register the Destination post type
 */
function bella_italia_register_destination_post_type() {
    $labels = array(
        'name'                  => _x( 'Destinations', 'Post type general name', 'bella-italia-journey' ),
        'singular_name'         => _x( 'Destination', 'Post type singular name', 'bella-italia-journey' ),
        'menu_name'             => _x( 'Destinations', 'Admin Menu text', 'bella-italia-journey' ),
        'name_admin_bar'        => _x( 'Destination', 'Add New on Toolbar', 'bella-italia-journey' ),
        'add_new'               => __( 'Add New', 'bella-italia-journey' ),
        'add_new_item'          => __( 'Add New Destination', 'bella-italia-journey' ),
        'new_item'              => __( 'New Destination', 'bella-italia-journey' ),
        'edit_item'             => __( 'Edit Destination', 'bella-italia-journey' ),
        'view_item'             => __( 'View Destination', 'bella-italia-journey' ),
        'all_items'             => __( 'All Destinations', 'bella-italia-journey' ),
        'search_items'          => __( 'Search Destinations', 'bella-italia-journey' ),
        'parent_item_colon'     => __( 'Parent Destinations:', 'bella-italia-journey' ),
        'not_found'             => __( 'No destinations found.', 'bella-italia-journey' ),
        'not_found_in_trash'    => __( 'No destinations found in Trash.', 'bella-italia-journey' ),
        'featured_image'        => _x( 'Destination Cover Image', 'Overrides the "Featured Image" phrase', 'bella-italia-journey' ),
        'set_featured_image'    => _x( 'Set cover image', 'Overrides the "Set featured image" phrase', 'bella-italia-journey' ),
        'remove_featured_image' => _x( 'Remove cover image', 'Overrides the "Remove featured image" phrase', 'bella-italia-journey' ),
        'use_featured_image'    => _x( 'Use as cover image', 'Overrides the "Use as featured image" phrase', 'bella-italia-journey' ),
        'archives'              => _x( 'Destination archives', 'The post type archive label used in nav menus', 'bella-italia-journey' ),
        'insert_into_item'      => _x( 'Insert into destination', 'Overrides the "Insert into post" phrase', 'bella-italia-journey' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this destination', 'Overrides the "Uploaded to this post" phrase', 'bella-italia-journey' ),
        'filter_items_list'     => _x( 'Filter destinations list', 'Screen reader text for the filter links', 'bella-italia-journey' ),
        'items_list_navigation' => _x( 'Destinations list navigation', 'Screen reader text for the pagination', 'bella-italia-journey' ),
        'items_list'            => _x( 'Destinations list', 'Screen reader text for the items list', 'bella-italia-journey' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'destination' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-location-alt',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
        'show_in_rest'       => true,
    );

    register_post_type( 'destination', $args );
}
add_action( 'init', 'bella_italia_register_destination_post_type' );

/**
 * Register custom taxonomies for Destination post type
 */
function bella_italia_register_region_taxonomy() {
    // Region taxonomy
    $labels = array(
        'name'                       => _x( 'Regions', 'taxonomy general name', 'bella-italia-journey' ),
        'singular_name'              => _x( 'Region', 'taxonomy singular name', 'bella-italia-journey' ),
        'search_items'               => __( 'Search Regions', 'bella-italia-journey' ),
        'popular_items'              => __( 'Popular Regions', 'bella-italia-journey' ),
        'all_items'                  => __( 'All Regions', 'bella-italia-journey' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Region', 'bella-italia-journey' ),
        'update_item'                => __( 'Update Region', 'bella-italia-journey' ),
        'add_new_item'               => __( 'Add New Region', 'bella-italia-journey' ),
        'new_item_name'              => __( 'New Region Name', 'bella-italia-journey' ),
        'separate_items_with_commas' => __( 'Separate regions with commas', 'bella-italia-journey' ),
        'add_or_remove_items'        => __( 'Add or remove regions', 'bella-italia-journey' ),
        'choose_from_most_used'      => __( 'Choose from the most used regions', 'bella-italia-journey' ),
        'not_found'                  => __( 'No regions found.', 'bella-italia-journey' ),
        'menu_name'                  => __( 'Regions', 'bella-italia-journey' ),
    );

    $args = array(
        'hierarchical'          => true,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'region' ),
        'show_in_rest'          => true,
    );

    register_taxonomy( 'region', array( 'destination' ), $args );
}
add_action( 'init', 'bella_italia_register_region_taxonomy' );

/**
 * Add meta boxes for Destination post type
 */
function bella_italia_add_destination_meta_boxes() {
    add_meta_box(
        'bella_italia_destination_details',
        __( 'Destination Details', 'bella-italia-journey' ),
        'bella_italia_destination_details_callback',
        'destination',
        'normal',
        'high'
    );
    
    add_meta_box(
        'bella_italia_destination_features',
        __( 'Destination Features', 'bella-italia-journey' ),
        'bella_italia_destination_features_callback',
        'destination',
        'normal',
        'high'
    );
    
    add_meta_box(
        'bella_italia_destination_map',
        __( 'Destination Map', 'bella-italia-journey' ),
        'bella_italia_destination_map_callback',
        'destination',
        'side',
        'default'
    );
    
    add_meta_box(
        'bella_italia_destination_featured',
        __( 'Featured Destination', 'bella-italia-journey' ),
        'bella_italia_destination_featured_callback',
        'destination',
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'bella_italia_add_destination_meta_boxes' );

/**
 * Destination details meta box callback
 */
function bella_italia_destination_details_callback( $post ) {
    wp_nonce_field( 'bella_italia_destination_details', 'bella_italia_destination_details_nonce' );
    
    // Retrieve current values
    $location = get_post_meta( $post->ID, '_destination_location', true );
    
    // Output fields
    ?>
    <p>
        <label for="destination_location"><strong><?php _e( 'Location:', 'bella-italia-journey' ); ?></strong></label>
        <input type="text" id="destination_location" name="destination_location" value="<?php echo esc_attr( $location ); ?>" class="widefat" />
        <span class="description"><?php _e( 'Enter the location name (city, town, area)', 'bella-italia-journey' ); ?></span>
    </p>
    <?php
}

/**
 * Destination features meta box callback
 */
function bella_italia_destination_features_callback( $post ) {
    wp_nonce_field( 'bella_italia_destination_features', 'bella_italia_destination_features_nonce' );
    
    // Retrieve current values
    $local_food = get_post_meta( $post->ID, '_destination_local_food', true );
    $local_drink = get_post_meta( $post->ID, '_destination_local_drink', true );
    $accommodation = get_post_meta( $post->ID, '_destination_accommodation', true );
    $must_see = get_post_meta( $post->ID, '_destination_must_see', true );
    $best_experience = get_post_meta( $post->ID, '_destination_best_experience', true );
    
    // Output fields
    ?>
    <div class="destination-features-wrapper">
        <h3><?php _e( 'Five Pillars of Italian Experience', 'bella-italia-journey' ); ?></h3>
        <p class="description"><?php _e( 'These details will help visitors plan their authentic Italian experience.', 'bella-italia-journey' ); ?></p>
        
        <div class="destination-feature">
            <label for="destination_local_food"><strong><?php _e( 'Local Food:', 'bella-italia-journey' ); ?></strong></label>
            <textarea id="destination_local_food" name="destination_local_food" class="widefat" rows="3"><?php echo esc_textarea( $local_food ); ?></textarea>
            <span class="description"><?php _e( 'Describe famous local dishes and food specialties', 'bella-italia-journey' ); ?></span>
        </div>
        
        <div class="destination-feature">
            <label for="destination_local_drink"><strong><?php _e( 'Local Drink:', 'bella-italia-journey' ); ?></strong></label>
            <textarea id="destination_local_drink" name="destination_local_drink" class="widefat" rows="3"><?php echo esc_textarea( $local_drink ); ?></textarea>
            <span class="description"><?php _e( 'Mention local wines, spirits or beverages', 'bella-italia-journey' ); ?></span>
        </div>
        
        <div class="destination-feature">
            <label for="destination_accommodation"><strong><?php _e( 'Accommodation:', 'bella-italia-journey' ); ?></strong></label>
            <textarea id="destination_accommodation" name="destination_accommodation" class="widefat" rows="3"><?php echo esc_textarea( $accommodation ); ?></textarea>
            <span class="description"><?php _e( 'Recommend places to stay (hotels, B&Bs, agriturismo, etc.)', 'bella-italia-journey' ); ?></span>
        </div>
        
        <div class="destination-feature">
            <label for="destination_must_see"><strong><?php _e( 'Must See:', 'bella-italia-journey' ); ?></strong></label>
            <textarea id="destination_must_see" name="destination_must_see" class="widefat" rows="3"><?php echo esc_textarea( $must_see ); ?></textarea>
            <span class="description"><?php _e( 'List attractions and landmarks that visitors shouldn\'t miss', 'bella-italia-journey' ); ?></span>
        </div>
        
        <div class="destination-feature">
            <label for="destination_best_experience"><strong><?php _e( 'Best Experience:', 'bella-italia-journey' ); ?></strong></label>
            <textarea id="destination_best_experience" name="destination_best_experience" class="widefat" rows="3"><?php echo esc_textarea( $best_experience ); ?></textarea>
            <span class="description"><?php _e( 'Describe unique activities and experiences visitors should try', 'bella-italia-journey' ); ?></span>
        </div>
    </div>
    <?php
}

/**
 * Destination map meta box callback
 */
function bella_italia_destination_map_callback( $post ) {
    wp_nonce_field( 'bella_italia_destination_map', 'bella_italia_destination_map_nonce' );
    
    // Retrieve current values
    $map_lat = get_post_meta( $post->ID, '_destination_map_lat', true );
    $map_lng = get_post_meta( $post->ID, '_destination_map_lng', true );
    $map_zoom = get_post_meta( $post->ID, '_destination_map_zoom', true ) ? get_post_meta( $post->ID, '_destination_map_zoom', true ) : '10';
    
    // Output fields
    ?>
    <div class="destination-map-fields">
        <p>
            <label for="destination_map_lat"><strong><?php _e( 'Latitude:', 'bella-italia-journey' ); ?></strong></label>
            <input type="text" id="destination_map_lat" name="destination_map_lat" value="<?php echo esc_attr( $map_lat ); ?>" class="widefat" />
        </p>
        <p>
            <label for="destination_map_lng"><strong><?php _e( 'Longitude:', 'bella-italia-journey' ); ?></strong></label>
            <input type="text" id="destination_map_lng" name="destination_map_lng" value="<?php echo esc_attr( $map_lng ); ?>" class="widefat" />
        </p>
        <p>
            <label for="destination_map_zoom"><strong><?php _e( 'Zoom Level:', 'bella-italia-journey' ); ?></strong></label>
            <input type="number" id="destination_map_zoom" name="destination_map_zoom" value="<?php echo esc_attr( $map_zoom ); ?>" class="small-text" min="1" max="20" />
        </p>
    </div>
    <?php
    // Display map instructions or map preview depending on whether API key is available
    $google_maps_api_key = get_theme_mod( 'bella_italia_google_maps_api_key', '' );
    if ( ! $google_maps_api_key ) {
        // No API key available
        echo '<div class="map-no-api-message">';
        printf(
            __( 'To enable the map preview, add a Google Maps API key in the <a href="%s">Customizer</a>.', 'bella-italia-journey' ),
            admin_url( 'customize.php?autofocus[section]=bella_italia_general_options' )
        );
        echo '</div>';
    } else {
        // Display map preview if coordinates are set
        if ( $map_lat && $map_lng ) {
            echo '<div id="destination-map-preview" style="width: 100%; height: 200px; margin-top: 10px; background-color: #e9e9e9;"></div>';
            echo '<p><button type="button" class="button" id="reset-map-coords">' . __( 'Clear Coordinates', 'bella-italia-journey' ) . '</button></p>';
        } else {
            echo '<div id="destination-map-preview" style="width: 100%; height: 200px; margin-top: 10px; background-color: #e9e9e9;">';
            echo '<div class="map-placeholder">' . __( 'Search for a location or click on the map to set coordinates.', 'bella-italia-journey' ) . '</div>';
            echo '</div>';
        }
    }
}

/**
 * Featured destination meta box callback
 */
function bella_italia_destination_featured_callback( $post ) {
    wp_nonce_field( 'bella_italia_destination_featured', 'bella_italia_destination_featured_nonce' );
    
    // Retrieve current value
    $featured = get_post_meta( $post->ID, '_featured_destination', true );
    
    // Output field
    ?>
    <div class="bella-italia-featured-destination">
        <p>
            <input type="checkbox" id="featured_destination" name="featured_destination" value="1" <?php checked( $featured, '1' ); ?> />
            <label for="featured_destination"><?php _e( 'Feature this destination on the homepage', 'bella-italia-journey' ); ?></label>
        </p>
        <p class="description"><?php _e( 'Featured destinations appear in the featured section on the homepage.', 'bella-italia-journey' ); ?></p>
    </div>
    <?php
}

/**
 * Save destination meta box data
 */
function bella_italia_save_destination_meta_boxes( $post_id ) {
    // Check if our nonce is set
    if ( 
        ! isset( $_POST['bella_italia_destination_details_nonce'] ) || 
        ! isset( $_POST['bella_italia_destination_features_nonce'] ) || 
        ! isset( $_POST['bella_italia_destination_map_nonce'] ) || 
        ! isset( $_POST['bella_italia_destination_featured_nonce'] ) 
    ) {
        return;
    }
    
    // Verify the nonces
    if ( 
        ! wp_verify_nonce( $_POST['bella_italia_destination_details_nonce'], 'bella_italia_destination_details' ) || 
        ! wp_verify_nonce( $_POST['bella_italia_destination_features_nonce'], 'bella_italia_destination_features' ) || 
        ! wp_verify_nonce( $_POST['bella_italia_destination_map_nonce'], 'bella_italia_destination_map' ) || 
        ! wp_verify_nonce( $_POST['bella_italia_destination_featured_nonce'], 'bella_italia_destination_featured' ) 
    ) {
        return;
    }
    
    // If this is an autosave, our form has not been submitted, so we don't want to do anything
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions
    if ( isset( $_POST['post_type'] ) && 'destination' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    // Sanitize and save the data
    
    // Details
    if ( isset( $_POST['destination_location'] ) ) {
        update_post_meta( $post_id, '_destination_location', sanitize_text_field( $_POST['destination_location'] ) );
    }
    
    // Features
    if ( isset( $_POST['destination_local_food'] ) ) {
        update_post_meta( $post_id, '_destination_local_food', wp_kses_post( $_POST['destination_local_food'] ) );
    }
    
    if ( isset( $_POST['destination_local_drink'] ) ) {
        update_post_meta( $post_id, '_destination_local_drink', wp_kses_post( $_POST['destination_local_drink'] ) );
    }
    
    if ( isset( $_POST['destination_accommodation'] ) ) {
        update_post_meta( $post_id, '_destination_accommodation', wp_kses_post( $_POST['destination_accommodation'] ) );
    }
    
    if ( isset( $_POST['destination_must_see'] ) ) {
        update_post_meta( $post_id, '_destination_must_see', wp_kses_post( $_POST['destination_must_see'] ) );
    }
    
    if ( isset( $_POST['destination_best_experience'] ) ) {
        update_post_meta( $post_id, '_destination_best_experience', wp_kses_post( $_POST['destination_best_experience'] ) );
    }
    
    // Map
    if ( isset( $_POST['destination_map_lat'] ) ) {
        update_post_meta( $post_id, '_destination_map_lat', sanitize_text_field( $_POST['destination_map_lat'] ) );
    }
    
    if ( isset( $_POST['destination_map_lng'] ) ) {
        update_post_meta( $post_id, '_destination_map_lng', sanitize_text_field( $_POST['destination_map_lng'] ) );
    }
    
    if ( isset( $_POST['destination_map_zoom'] ) ) {
        update_post_meta( $post_id, '_destination_map_zoom', sanitize_text_field( $_POST['destination_map_zoom'] ) );
    }
    
    // Featured
    $featured = isset( $_POST['featured_destination'] ) ? '1' : '0';
    update_post_meta( $post_id, '_featured_destination', $featured );
}
add_action( 'save_post', 'bella_italia_save_destination_meta_boxes' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
    require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Add custom widgets
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Add theme hooks for extending functionality
 */
require get_template_directory() . '/inc/hooks.php';

/**
 * Add theme plugins compatibility
 */
require get_template_directory() . '/inc/plugins-compatibility.php';

/**
 * AJAX handler for region data
 */
function bella_italia_get_region_destinations() {
    if ( ! isset( $_POST['region'] ) ) {
        wp_send_json_error();
    }
    
    $region = sanitize_text_field( $_POST['region'] );
    
    $args = array(
        'post_type' => 'destination',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'region',
                'field'    => 'slug',
                'terms'    => $region,
            ),
        ),
    );
    
    $query = new WP_Query( $args );
    
    $destinations = array();
    
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            
            $destination = array(
                'id'        => get_the_ID(),
                'title'     => get_the_title(),
                'permalink' => get_permalink(),
                'excerpt'   => get_the_excerpt(),
                'thumbnail' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) : '',
                'location'  => get_post_meta( get_the_ID(), '_destination_location', true ),
            );
            
            $destinations[] = $destination;
        }
        
        wp_reset_postdata();
        
        wp_send_json_success( array(
            'destinations' => $destinations,
        ) );
    } else {
        wp_send_json_error( array(
            'message' => __( 'No destinations found in this region.', 'bella-italia-journey' ),
        ) );
    }
}
add_action( 'wp_ajax_get_region_destinations', 'bella_italia_get_region_destinations' );
add_action( 'wp_ajax_nopriv_get_region_destinations', 'bella_italia_get_region_destinations' );

/**
 * Register theme activation hook
 */
function bella_italia_theme_activation() {
    // Create default regions if they don't exist
    $default_regions = array(
        'north' => __( 'Northern Italy', 'bella-italia-journey' ),
        'central' => __( 'Central Italy', 'bella-italia-journey' ),
        'south' => __( 'Southern Italy', 'bella-italia-journey' ),
        'islands' => __( 'Italian Islands', 'bella-italia-journey' ),
    );
    
    foreach ( $default_regions as $slug => $name ) {
        if ( ! term_exists( $slug, 'region' ) ) {
            wp_insert_term( $name, 'region', array( 'slug' => $slug ) );
        }
    }
    
    // Create specific Italian regions if they don't exist
    $italian_regions = array(
        'valle-d-aosta' => array(
            'name' => __( 'Valle d\'Aosta', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'piemonte' => array(
            'name' => __( 'Piemonte', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'liguria' => array(
            'name' => __( 'Liguria', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'lombardia' => array(
            'name' => __( 'Lombardia', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'trentino-alto-adige' => array(
            'name' => __( 'Trentino-Alto Adige', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'veneto' => array(
            'name' => __( 'Veneto', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'friuli-venezia-giulia' => array(
            'name' => __( 'Friuli-Venezia Giulia', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'emilia-romagna' => array(
            'name' => __( 'Emilia-Romagna', 'bella-italia-journey' ),
            'parent' => 'north',
        ),
        'toscana' => array(
            'name' => __( 'Toscana', 'bella-italia-journey' ),
            'parent' => 'central',
        ),
        'umbria' => array(
            'name' => __( 'Umbria', 'bella-italia-journey' ),
            'parent' => 'central',
        ),
        'marche' => array(
            'name' => __( 'Marche', 'bella-italia-journey' ),
            'parent' => 'central',
        ),
        'lazio' => array(
            'name' => __( 'Lazio', 'bella-italia-journey' ),
            'parent' => 'central',
        ),
        'abruzzo' => array(
            'name' => __( 'Abruzzo', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'molise' => array(
            'name' => __( 'Molise', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'campania' => array(
            'name' => __( 'Campania', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'puglia' => array(
            'name' => __( 'Puglia', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'basilicata' => array(
            'name' => __( 'Basilicata', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'calabria' => array(
            'name' => __( 'Calabria', 'bella-italia-journey' ),
            'parent' => 'south',
        ),
        'sicilia' => array(
            'name' => __( 'Sicilia', 'bella-italia-journey' ),
            'parent' => 'islands',
        ),
        'sardegna' => array(
            'name' => __( 'Sardegna', 'bella-italia-journey' ),
            'parent' => 'islands',
        ),
    );
    
    foreach ( $italian_regions as $slug => $region_data ) {
        if ( ! term_exists( $slug, 'region' ) ) {
            $parent_term = term_exists( $region_data['parent'], 'region' );
            $parent_id = isset( $parent_term['term_id'] ) ? $parent_term['term_id'] : 0;
            
            wp_insert_term( $region_data['name'], 'region', array(
                'slug' => $slug,
                'parent' => $parent_id,
            ) );
        }
    }
}
add_action( 'after_switch_theme', 'bella_italia_theme_activation' );

/**
 * Modify archive query for destination
 */
function bella_italia_modify_destination_query( $query ) {
    if ( ! is_admin() && $query->is_main_query() ) {
        if ( $query->is_post_type_archive( 'destination' ) ) {
            // Set posts per page from theme options
            $posts_per_page = get_theme_mod( 'bella_italia_archive_items_per_page', 9 );
            $query->set( 'posts_per_page', $posts_per_page );
            
            // Handle region filter
            if ( isset( $_GET['region'] ) && ! empty( $_GET['region'] ) ) {
                $region = sanitize_text_field( $_GET['region'] );
                
                $tax_query = array(
                    array(
                        'taxonomy' => 'region',
                        'field'    => 'slug',
                        'terms'    => $region,
                    ),
                );
                
                $query->set( 'tax_query', $tax_query );
            }
        }
    }
}
add_action( 'pre_get_posts', 'bella_italia_modify_destination_query' );

/**
 * Add body classes for better CSS targeting
 */
function bella_italia_add_body_classes( $classes ) {
    // Add class for archive layout
    if ( is_archive() || is_home() ) {
        if ( is_post_type_archive( 'destination' ) || is_tax( 'region' ) ) {
            $classes[] = 'archive-layout-' . get_theme_mod( 'bella_italia_archive_layout', 'grid' );
        } else {
            $classes[] = 'blog-layout-' . get_theme_mod( 'bella_italia_blog_layout', 'grid' );
        }
    }
    
    // Add class for destination single layout
    if ( is_singular( 'destination' ) ) {
        $classes[] = 'destination-layout-' . get_theme_mod( 'bella_italia_destination_layout', 'standard' );
    }
    
    return $classes;
}
add_filter( 'body_class', 'bella_italia_add_body_classes' );

/**
 * Register region filter widget for destination archive
 */
class Bella_Italia_Region_Filter_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'bella_italia_region_filter',
            __( 'Bella Italia: Region Filter', 'bella-italia-journey' ),
            array(
                'description' => __( 'Display region filter for destinations', 'bella-italia-journey' ),
            )
        );
    }
    
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
        
        // Get all regions
        $regions = get_terms( array(
            'taxonomy' => 'region',
            'hide_empty' => true,
            'parent' => 0,
        ) );
        
        if ( ! empty( $regions ) && ! is_wp_error( $regions ) ) {
            echo '<div class="region-filter-widget">';
            echo '<ul class="region-filter-list">';
            
            // All destinations link
            echo '<li class="region-item"><a href="' . esc_url( get_post_type_archive_link( 'destination' ) ) . '" class="region-link">' . __( 'All Regions', 'bella-italia-journey' ) . '</a></li>';
            
            foreach ( $regions as $region ) {
                echo '<li class="region-item">';
                echo '<a href="' . esc_url( get_term_link( $region ) ) . '" class="region-link">' . esc_html( $region->name ) . '</a>';
                
                // Get child regions
                $child_regions = get_terms( array(
                    'taxonomy' => 'region',
                    'hide_empty' => true,
                    'parent' => $region->term_id,
                ) );
                
                if ( ! empty( $child_regions ) && ! is_wp_error( $child_regions ) ) {
                    echo '<ul class="sub-region-list">';
                    
                    foreach ( $child_regions as $child_region ) {
                        echo '<li class="sub-region-item"><a href="' . esc_url( get_term_link( $child_region ) ) . '" class="sub-region-link">' . esc_html( $child_region->name ) . '</a></li>';
                    }
                    
                    echo '</ul>';
                }
                
                echo '</li>';
            }
            
            echo '</ul>';
            echo '</div>';
        }
        
        echo $args['after_widget'];
    }
    
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Filter by Region', 'bella-italia-journey' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'bella-italia-journey' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <?php
    }
    
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        
        return $instance;
    }
}

/**
 * Register widgets
 */
function bella_italia_register_widgets() {
    register_widget( 'Bella_Italia_Region_Filter_Widget' );
}
add_action( 'widgets_init', 'bella_italia_register_widgets' );

/**
 * AJAX handler for newsletter signup
 */
function bella_italia_newsletter_signup() {
    if ( ! isset( $_POST['email'] ) || ! is_email( $_POST['email'] ) ) {
        wp_send_json_error( array(
            'message' => __( 'Please enter a valid email address.', 'bella-italia-journey' ),
        ) );
    }
    
    $email = sanitize_email( $_POST['email'] );
    
    // In a real implementation, this would integrate with a newsletter service
    // For now, just return success
    wp_send_json_success( array(
        'message' => __( 'Thank you for subscribing! Please check your email to confirm your subscription.', 'bella-italia-journey' ),
    ) );
}
add_action( 'wp_ajax_newsletter_signup', 'bella_italia_newsletter_signup' );
add_action( 'wp_ajax_nopriv_newsletter_signup', 'bella_italia_newsletter_signup' );

/**
 * Add language switcher to the menu
 */
function bella_italia_language_switcher( $items, $args ) {
    if ( $args->theme_location == 'primary' && function_exists( 'pll_the_languages' ) ) {
        $items .= '<li class="menu-item language-switcher-container">';
        
        ob_start();
        pll_the_languages( array(
            'dropdown'       => 1,
            'show_names'     => 1,
            'display_names_as' => 'name',
            'show_flags'     => 1,
        ) );
        $items .= ob_get_clean();
        
        $items .= '</li>';
    }
    
    return $items;
}
add_filter( 'wp_nav_menu_items', 'bella_italia_language_switcher', 10, 2 );

/**
 * Customizer partial renders
 */
function bella_italia_customize_partial_hero_title() {
    return get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_hero_subtitle() {
    return get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_featured_destinations_title() {
    return get_theme_mod( 'bella_italia_featured_destinations_title', __( 'Explore Italy', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_featured_destinations_subtitle() {
    return get_theme_mod( 'bella_italia_featured_destinations_subtitle', __( 'Discover the most beautiful destinations in Italy', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_newsletter_title() {
    return get_theme_mod( 'bella_italia_newsletter_title', __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_newsletter_subtitle() {
    return get_theme_mod( 'bella_italia_newsletter_subtitle', __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' ) );
}

function bella_italia_customize_partial_copyright_text() {
    return get_theme_mod( 'bella_italia_copyright_text', '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. ' . __( 'All rights reserved.', 'bella-italia-journey' ) );
}

/**
 * Add theme admin page
 */
function bella_italia_admin_menu() {
    add_theme_page(
        __( 'Bella Italia Journey', 'bella-italia-journey' ),
        __( 'Bella Italia Journey', 'bella-italia-journey' ),
        'manage_options',
        'bella-italia-journey',
        'bella_italia_admin_page'
    );
}
add_action( 'admin_menu', 'bella_italia_admin_menu' );

/**
 * Theme admin page content
 */
function bella_italia_admin_page() {
    ?>
    <div class="wrap bella-italia-admin-page">
        <h1><?php _e( 'Bella Italia Journey Theme', 'bella-italia-journey' ); ?></h1>
        
        <div class="bella-italia-admin-content">
            <div class="bella-italia-admin-section">
                <h2><?php _e( 'Welcome to Bella Italia Journey!', 'bella-italia-journey' ); ?></h2>
                <p><?php _e( 'Thank you for choosing our theme. Bella Italia Journey is designed to showcase the beauty of Italy and provide an immersive experience for your visitors.', 'bella-italia-journey' ); ?></p>
                
                <h3><?php _e( 'Getting Started', 'bella-italia-journey' ); ?></h3>
                <ol>
                    <li><?php _e( 'Create destinations using the Destinations menu in the sidebar.', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Assign regions to your destinations to organize them.', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Customize your theme options in the Customizer.', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Set up your menus and widgets.', 'bella-italia-journey' ); ?></li>
                </ol>
                
                <p>
                    <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>" class="button button-primary"><?php _e( 'Customize Theme', 'bella-italia-journey' ); ?></a>
                    <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=destination' ) ); ?>" class="button"><?php _e( 'Manage Destinations', 'bella-italia-journey' ); ?></a>
                </p>
            </div>
            
            <div class="bella-italia-admin-section">
                <h3><?php _e( 'Theme Features', 'bella-italia-journey' ); ?></h3>
                <ul>
                    <li><?php _e( 'Custom Destination Post Type', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Interactive Italy Map', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Region Taxonomy', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Five Pillars Content Model', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Multilingual Support', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Responsive Design', 'bella-italia-journey' ); ?></li>
                    <li><?php _e( 'Italian Flag-Inspired Colors', 'bella-italia-journey' ); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Merge in a specific theme if we need to
 */
function bella_italia_check_theme_template() {
    // Note: Implement this function if we need to apply a specific external template
    // For now, we're using the custom theme we've built from scratch
}
add_action( 'after_setup_theme', 'bella_italia_check_theme_template' );