<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

get_header();

// Determine sidebar position
$sidebar_position = get_theme_mod( 'bella_italia_sidebar_position', 'right' );
$content_class = 'content-area';

if ( is_active_sidebar( 'sidebar-1' ) ) {
	$content_class .= ' col-lg-9';
	if ( $sidebar_position === 'left' ) {
		$content_class .= ' order-lg-2';
	}
} else {
	$content_class .= ' col-lg-12';
}
?>

	<main id="primary" class="<?php echo esc_attr( $content_class ); ?>">

		<?php bella_italia_do_before_content(); ?>

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		<?php bella_italia_do_after_content(); ?>

	</main><!-- #main -->

<?php
// Display sidebar if it's active
if ( is_active_sidebar( 'sidebar-1' ) ) :
	$sidebar_class = 'col-lg-3';
	if ( $sidebar_position === 'left' ) {
		$sidebar_class .= ' order-lg-1';
	}
	echo '<div class="' . esc_attr( $sidebar_class ) . '">';
	get_sidebar();
	echo '</div>';
endif;

get_footer();