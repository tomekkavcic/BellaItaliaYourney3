<?php
/**
 * The template for displaying destination archives
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

get_header();

// Get archive layout
$archive_layout = get_theme_mod( 'bella_italia_archive_layout', 'grid' );

// Check if map should be displayed at the top
$show_map = get_theme_mod( 'bella_italia_archive_show_map', true );

// Get current region if on a region taxonomy page
$current_region = '';
if ( is_tax( 'region' ) ) {
	$term = get_queried_object();
	if ( $term && isset( $term->slug ) ) {
		$current_region = $term->slug;
	}
}
?>

	<div class="container destinations-archive">
		<div class="row">
			<?php if ( $show_map ) : ?>
			<div class="col-12 destination-archive-map mb-4">
				<?php 
				// Include the Italy map
				get_template_part('template-parts/italy-map', null, array(
					'active_region' => $current_region,
					'map_style' => get_theme_mod( 'bella_italia_map_view', 'simple' ),
					'show_pins' => true,
					'show_region_names' => true,
					'show_legend' => true,
				));
				?>
			</div>
			<?php endif; ?>
			
			<div class="col-md-3 col-lg-3 destination-sidebar">
				<div class="card filter-card mb-4">
					<div class="card-header">
						<h3 class="filter-title"><?php _e( 'Filter By Region', 'bella-italia-journey' ); ?></h3>
					</div>
					<div class="card-body">
						<?php
						// Display region filter
						$regions = get_terms( array(
							'taxonomy' => 'region',
							'hide_empty' => true,
							'parent' => 0,
						) );
						
						if ( ! empty( $regions ) && ! is_wp_error( $regions ) ) :
						?>
							<ul class="region-filter-list">
								<li class="region-item <?php echo empty( $current_region ) ? 'active' : ''; ?>">
									<a href="<?php echo esc_url( get_post_type_archive_link( 'destination' ) ); ?>" class="region-link">
										<?php _e( 'All Regions', 'bella-italia-journey' ); ?>
									</a>
								</li>
								
								<?php foreach ( $regions as $region ) : ?>
									<li class="region-item <?php echo ( $current_region === $region->slug ) ? 'active' : ''; ?>">
										<a href="<?php echo esc_url( get_term_link( $region ) ); ?>" class="region-link">
											<?php echo esc_html( $region->name ); ?>
										</a>
										
										<?php
										// Display child regions
										$child_regions = get_terms( array(
											'taxonomy' => 'region',
											'hide_empty' => true,
											'parent' => $region->term_id,
										) );
										
										if ( ! empty( $child_regions ) && ! is_wp_error( $child_regions ) ) :
										?>
											<ul class="sub-region-list">
												<?php foreach ( $child_regions as $child_region ) : ?>
													<li class="sub-region-item <?php echo ( $current_region === $child_region->slug ) ? 'active' : ''; ?>">
														<a href="<?php echo esc_url( get_term_link( $child_region ) ); ?>" class="sub-region-link">
															<?php echo esc_html( $child_region->name ); ?>
														</a>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
				
				<?php if ( is_active_sidebar( 'sidebar-destination' ) ) : ?>
					<?php dynamic_sidebar( 'sidebar-destination' ); ?>
				<?php endif; ?>
			</div>
			
			<div class="col-md-9 col-lg-9 destinations-content">
				<?php if ( have_posts() ) : ?>
					<header class="page-header">
						<?php
						the_archive_title( '<h1 class="page-title">', '</h1>' );
						the_archive_description( '<div class="archive-description">', '</div>' );
						?>
					</header><!-- .page-header -->
					
					<div class="destinations-grid row">
						<?php
						/* Start the Loop */
						while ( have_posts() ) :
							the_post();
							
							// Get destination details
							$location = get_post_meta( get_the_ID(), '_destination_location', true );
							$featured = get_post_meta( get_the_ID(), '_featured_destination', true );
							
							// Get region for display
							$destination_regions = get_the_terms( get_the_ID(), 'region' );
							$region_names = array();
							
							if ( ! empty( $destination_regions ) && ! is_wp_error( $destination_regions ) ) {
								foreach ( $destination_regions as $region ) {
									$region_names[] = $region->name;
								}
							}
						?>
							<div class="col-md-6 col-lg-4 mb-4 destination-item">
								<div class="card destination-card h-100">
									<div class="card-img-wrapper">
										<?php if ( has_post_thumbnail() ) : ?>
											<a href="<?php the_permalink(); ?>">
												<?php the_post_thumbnail( 'medium_large', array( 'class' => 'card-img-top' ) ); ?>
											</a>
										<?php endif; ?>
										
										<?php if ( ! empty( $region_names ) ) : ?>
											<div class="destination-region">
												<span class="badge bg-primary"><?php echo esc_html( implode( ', ', $region_names ) ); ?></span>
											</div>
										<?php endif; ?>
										
										<?php if ( $featured ) : ?>
											<div class="featured-badge">
												<span class="badge bg-warning text-dark">
													<i class="fa fa-star"></i> <?php _e( 'Featured', 'bella-italia-journey' ); ?>
												</span>
											</div>
										<?php endif; ?>
									</div>
									
									<div class="card-body">
										<h3 class="card-title">
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</h3>
										
										<?php if ( $location ) : ?>
											<div class="destination-location mb-2">
												<i class="fa fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?>
											</div>
										<?php endif; ?>
										
										<div class="card-text">
											<?php the_excerpt(); ?>
										</div>
									</div>
									
									<div class="card-footer">
										<div class="row align-items-center">
											<div class="col">
												<div class="destination-highlights">
													<?php
													// Show up to 3 highlights/features
													$highlights = array();
													
													if ( get_post_meta( get_the_ID(), '_destination_local_food', true ) ) {
														$highlights[] = '<span class="highlight-item" title="' . esc_attr__( 'Local Food', 'bella-italia-journey' ) . '"><i class="fa fa-utensils"></i></span>';
													}
													
													if ( get_post_meta( get_the_ID(), '_destination_local_drink', true ) ) {
														$highlights[] = '<span class="highlight-item" title="' . esc_attr__( 'Local Drink', 'bella-italia-journey' ) . '"><i class="fa fa-wine-glass"></i></span>';
													}
													
													if ( get_post_meta( get_the_ID(), '_destination_accommodation', true ) ) {
														$highlights[] = '<span class="highlight-item" title="' . esc_attr__( 'Accommodation', 'bella-italia-journey' ) . '"><i class="fa fa-bed"></i></span>';
													}
													
													if ( get_post_meta( get_the_ID(), '_destination_must_see', true ) ) {
														$highlights[] = '<span class="highlight-item" title="' . esc_attr__( 'Must See', 'bella-italia-journey' ) . '"><i class="fa fa-eye"></i></span>';
													}
													
													if ( get_post_meta( get_the_ID(), '_destination_best_experience', true ) ) {
														$highlights[] = '<span class="highlight-item" title="' . esc_attr__( 'Best Experience', 'bella-italia-journey' ) . '"><i class="fa fa-star"></i></span>';
													}
													
													// Limit to 3 highlights
													$highlights = array_slice( $highlights, 0, 3 );
													
													// Output highlights
													echo implode( ' ', $highlights );
													?>
												</div>
											</div>
											<div class="col-auto">
												<a href="<?php the_permalink(); ?>" class="btn btn-sm btn-primary">
													<?php _e( 'Explore', 'bella-italia-journey' ); ?>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
					
					<?php
					// Display pagination
					bella_italia_pagination();
					?>
				
				<?php else : ?>
					
					<div class="alert alert-info">
						<p><?php _e( 'No destinations found. Please try another filter or search.', 'bella-italia-journey' ); ?></p>
					</div>
					
				<?php endif; ?>
			</div>
		</div>
	</div>

<?php
get_footer();