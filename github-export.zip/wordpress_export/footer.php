<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bella_Italia_Journey
 */

?>
			</div><!-- .row -->
		</div><!-- .container -->
	</div><!-- #content -->

	<?php bella_italia_do_before_footer(); ?>

	<footer id="colophon" class="site-footer">
		<?php
		// Determine footer style
		$footer_style = get_theme_mod( 'bella_italia_footer_style', 'default' );
		$footer_widgets = get_theme_mod( 'bella_italia_footer_widgets', 4 );
		
		// Footer widgets area
		if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || 
			 is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) ) :
		?>
		<div class="footer-widgets footer-widgets-<?php echo absint( $footer_widgets ); ?> footer-style-<?php echo esc_attr( $footer_style ); ?>">
			<div class="container">
				<div class="row">
					<?php
					// Calculate column width based on number of widget areas
					$column_class = 'col-md-' . ( 12 / $footer_widgets );
					
					// Display active footer widget areas
					for ( $i = 1; $i <= $footer_widgets; $i++ ) :
						if ( is_active_sidebar( 'footer-' . $i ) ) :
							echo '<div class="' . esc_attr( $column_class ) . ' footer-column footer-column-' . esc_attr( $i ) . '">';
							dynamic_sidebar( 'footer-' . $i );
							echo '</div>';
						endif;
					endfor;
					?>
				</div>
			</div>
		</div>
		<?php
		endif;
		?>

		<div class="footer-info">
			<div class="container">
				<div class="row">
					<div class="col-md-6 footer-info-left">
						<?php
						// Display copyright text
						$copyright_text = get_theme_mod( 'bella_italia_copyright_text', '&copy; ' . date( 'Y' ) . ' ' . get_bloginfo( 'name' ) . '. ' . __( 'All rights reserved.', 'bella-italia-journey' ) );
						echo '<div class="site-info">';
						echo wp_kses_post( $copyright_text );
						echo '</div>';
						?>
					</div>
					
					<div class="col-md-6 footer-info-right">
						<?php
						// Display footer menu if it exists
						if ( has_nav_menu( 'footer' ) ) :
							wp_nav_menu(
								array(
									'theme_location' => 'footer',
									'menu_class'     => 'footer-menu',
									'container'      => false,
									'depth'          => 1,
								)
							);
						endif;
						
						// Display social menu if it exists
						if ( has_nav_menu( 'social' ) ) :
							wp_nav_menu(
								array(
									'theme_location' => 'social',
									'menu_class'     => 'social-links-menu',
									'container'      => 'div',
									'container_class' => 'footer-social-links',
									'link_before'    => '<span class="screen-reader-text">',
									'link_after'     => '</span>',
									'depth'          => 1,
								)
							);
						else :
							// Display social links from theme options
							bella_italia_social_links();
						endif;
						?>
					</div>
				</div>
				
				<div class="footer-flag">
					<div class="italian-flag">
						<span class="flag-green"></span>
						<span class="flag-white"></span>
						<span class="flag-red"></span>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- #colophon -->
	
	<?php bella_italia_do_after_footer(); ?>
	
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>