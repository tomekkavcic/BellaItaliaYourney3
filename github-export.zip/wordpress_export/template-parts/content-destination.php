<?php
/**
 * Template part for displaying destination posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get if we're in archive view
$is_archive = is_post_type_archive( 'destination' ) || is_tax( 'region' );

// Get region
$regions = get_the_terms( get_the_ID(), 'region' );
$region_name = '';
$region_class = '';

if ( $regions && ! is_wp_error( $regions ) ) {
    $region = reset( $regions );
    $region_name = $region->name;
    $region_slug = $region->slug;
    
    // Set region class for styling
    if ( strpos( $region_slug, 'north' ) !== false ) {
        $region_class = 'region-north';
    } elseif ( strpos( $region_slug, 'central' ) !== false ) {
        $region_class = 'region-central';
    } elseif ( strpos( $region_slug, 'south' ) !== false ) {
        $region_class = 'region-south';
    }
}

// Additional destination metadata
$location = get_post_meta( get_the_ID(), '_destination_location', true );
$local_food = get_post_meta( get_the_ID(), '_destination_local_food', true );
$local_drink = get_post_meta( get_the_ID(), '_destination_local_drink', true );
$accommodation = get_post_meta( get_the_ID(), '_destination_accommodation', true );
$must_see = get_post_meta( get_the_ID(), '_destination_must_see', true );
$best_experience = get_post_meta( get_the_ID(), '_destination_best_experience', true );

if ( $is_archive ) : 
// ARCHIVE VIEW
?>
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'destination-card ' . $region_class ); ?>>
        <a href="<?php the_permalink(); ?>" class="destination-card-link">
            <div class="destination-card-inner">
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="destination-image">
                        <?php the_post_thumbnail( 'medium_large', array( 'class' => 'img-fluid' ) ); ?>
                        <?php if ( $region_name ) : ?>
                            <div class="destination-region-badge"><?php echo esc_html( $region_name ); ?></div>
                        <?php endif; ?>
                    </div>
                <?php else : ?>
                    <div class="destination-image no-image">
                        <div class="no-image-placeholder">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <?php if ( $region_name ) : ?>
                            <div class="destination-region-badge"><?php echo esc_html( $region_name ); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <div class="destination-details">
                    <h3 class="destination-title"><?php the_title(); ?></h3>
                    
                    <?php if ( $location ) : ?>
                    <div class="destination-location">
                        <i class="fa fa-map-marker"></i> <?php echo esc_html( $location ); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="destination-excerpt">
                        <?php 
                        $excerpt = get_the_excerpt();
                        echo wp_trim_words( $excerpt, 15, '...' ); 
                        ?>
                    </div>
                    
                    <div class="destination-highlights">
                        <?php if ( $must_see ) : ?>
                        <div class="highlight-item">
                            <i class="fa fa-eye"></i> <?php _e( 'Must See', 'bella-italia-journey' ); ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ( $best_experience ) : ?>
                        <div class="highlight-item">
                            <i class="fa fa-star"></i> <?php _e( 'Best Experience', 'bella-italia-journey' ); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="destination-meta">
                        <span class="read-more-link"><?php _e( 'Discover more', 'bella-italia-journey' ); ?> <i class="fa fa-arrow-right"></i></span>
                    </div>
                </div>
            </div>
        </a>
    </article>
<?php 
else : 
// SINGLE VIEW
?>
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'destination-single ' . $region_class ); ?>>
        <header class="destination-header">
            <?php if ( $region_name ) : ?>
                <div class="destination-region-badge large">
                    <?php echo esc_html( $region_name ); ?>
                </div>
            <?php endif; ?>
            
            <h1 class="destination-title"><?php the_title(); ?></h1>
            
            <?php if ( $location ) : ?>
            <div class="destination-location">
                <i class="fa fa-map-marker"></i> <?php echo esc_html( $location ); ?>
            </div>
            <?php endif; ?>
        </header><!-- .destination-header -->

        <?php if ( has_post_thumbnail() ) : ?>
            <div class="destination-featured-image">
                <?php the_post_thumbnail( 'full', array( 'class' => 'img-fluid' ) ); ?>
            </div>
        <?php endif; ?>

        <div class="destination-content">
            <div class="destination-intro">
                <?php the_excerpt(); ?>
            </div>
            
            <div class="destination-detail-content">
                <?php the_content(); ?>
            </div>
        </div><!-- .destination-content -->
        
        <div class="destination-highlights-section">
            <h2><?php _e( 'Highlights', 'bella-italia-journey' ); ?></h2>
            
            <div class="row">
                <?php if ( $local_food ) : ?>
                <div class="col-md-6 mb-4">
                    <div class="highlight-card local-food">
                        <h3><i class="fa fa-utensils"></i> <?php _e( 'Local Food', 'bella-italia-journey' ); ?></h3>
                        <div class="highlight-content">
                            <?php echo wpautop( esc_html( $local_food ) ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ( $local_drink ) : ?>
                <div class="col-md-6 mb-4">
                    <div class="highlight-card local-drink">
                        <h3><i class="fa fa-wine-glass"></i> <?php _e( 'Local Drink', 'bella-italia-journey' ); ?></h3>
                        <div class="highlight-content">
                            <?php echo wpautop( esc_html( $local_drink ) ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ( $accommodation ) : ?>
                <div class="col-md-6 mb-4">
                    <div class="highlight-card accommodation">
                        <h3><i class="fa fa-bed"></i> <?php _e( 'Accommodation', 'bella-italia-journey' ); ?></h3>
                        <div class="highlight-content">
                            <?php echo wpautop( esc_html( $accommodation ) ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ( $must_see ) : ?>
                <div class="col-md-6 mb-4">
                    <div class="highlight-card must-see">
                        <h3><i class="fa fa-eye"></i> <?php _e( 'Must See', 'bella-italia-journey' ); ?></h3>
                        <div class="highlight-content">
                            <?php echo wpautop( esc_html( $must_see ) ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ( $best_experience ) : ?>
                <div class="col-md-6 mb-4">
                    <div class="highlight-card best-experience">
                        <h3><i class="fa fa-star"></i> <?php _e( 'Best Experience', 'bella-italia-journey' ); ?></h3>
                        <div class="highlight-content">
                            <?php echo wpautop( esc_html( $best_experience ) ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php 
        // Nearby destinations
        $current_region_terms = wp_get_post_terms( get_the_ID(), 'region', array( 'fields' => 'ids' ) );
        
        if ( ! empty( $current_region_terms ) ) {
            $args = array(
                'post_type'      => 'destination',
                'posts_per_page' => 3,
                'post__not_in'   => array( get_the_ID() ),
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'region',
                        'field'    => 'term_id',
                        'terms'    => $current_region_terms,
                    ),
                ),
            );
            
            $nearby_destinations = new WP_Query( $args );
            
            if ( $nearby_destinations->have_posts() ) :
            ?>
            <div class="nearby-destinations-section">
                <h2><?php _e( 'Explore Nearby', 'bella-italia-journey' ); ?></h2>
                
                <div class="row">
                    <?php 
                    while ( $nearby_destinations->have_posts() ) : 
                        $nearby_destinations->the_post();
                        // Get region
                        $regions = get_the_terms( get_the_ID(), 'region' );
                        $region_name = '';
                        $region_class = '';
                        
                        if ( $regions && ! is_wp_error( $regions ) ) {
                            $region = reset( $regions );
                            $region_name = $region->name;
                            $region_slug = $region->slug;
                            
                            // Set region class for styling
                            if ( strpos( $region_slug, 'north' ) !== false ) {
                                $region_class = 'region-north';
                            } elseif ( strpos( $region_slug, 'central' ) !== false ) {
                                $region_class = 'region-central';
                            } elseif ( strpos( $region_slug, 'south' ) !== false ) {
                                $region_class = 'region-south';
                            }
                        }
                    ?>
                        <div class="col-md-4 mb-4">
                            <article <?php post_class( 'destination-card ' . $region_class ); ?>>
                                <a href="<?php the_permalink(); ?>" class="destination-card-link">
                                    <div class="destination-card-inner">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <div class="destination-image">
                                                <?php the_post_thumbnail( 'medium', array( 'class' => 'img-fluid' ) ); ?>
                                                <?php if ( $region_name ) : ?>
                                                    <div class="destination-region-badge"><?php echo esc_html( $region_name ); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        <?php else : ?>
                                            <div class="destination-image no-image">
                                                <div class="no-image-placeholder">
                                                    <i class="fa fa-map-marker"></i>
                                                </div>
                                                <?php if ( $region_name ) : ?>
                                                    <div class="destination-region-badge"><?php echo esc_html( $region_name ); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="destination-details">
                                            <h3 class="destination-title"><?php the_title(); ?></h3>
                                            
                                            <div class="destination-meta">
                                                <span class="read-more-link"><?php _e( 'Discover more', 'bella-italia-journey' ); ?> <i class="fa fa-arrow-right"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </article>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php
            endif;
            wp_reset_postdata();
        }
        ?>
        
        <footer class="destination-footer">
            <?php
            if ( get_edit_post_link() ) :
                edit_post_link(
                    sprintf(
                        wp_kses(
                            /* translators: %s: Name of current post. Only visible to screen readers */
                            __( 'Edit <span class="screen-reader-text">%s</span>', 'bella-italia-journey' ),
                            array(
                                'span' => array(
                                    'class' => array(),
                                ),
                            )
                        ),
                        wp_kses_post( get_the_title() )
                    ),
                    '<div class="edit-link">',
                    '</div>'
                );
            endif;
            ?>
        </footer><!-- .destination-footer -->
    </article><!-- #post-<?php the_ID(); ?> -->
<?php 
endif;