<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>

<section class="no-results not-found">
    <header class="page-header">
        <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'bella-italia-journey' ); ?></h1>
    </header><!-- .page-header -->

    <div class="page-content">
        <?php
        if ( is_home() && current_user_can( 'publish_posts' ) ) :

            printf(
                '<p>' . wp_kses(
                    /* translators: 1: link to WP admin new post page. */
                    __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'bella-italia-journey' ),
                    array(
                        'a' => array(
                            'href' => array(),
                        ),
                    )
                ) . '</p>',
                esc_url( admin_url( 'post-new.php' ) )
            );

        elseif ( is_search() ) :
            ?>

            <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'bella-italia-journey' ); ?></p>
            <?php
            get_search_form();

        elseif ( is_tax( 'region' ) ) :
            ?>

            <p><?php esc_html_e( 'We couldn\'t find any destinations in this region. Please check back later or explore other regions.', 'bella-italia-journey' ); ?></p>
            <div class="mt-4">
                <a href="<?php echo esc_url( get_post_type_archive_link( 'destination' ) ); ?>" class="btn btn-primary">
                    <?php esc_html_e( 'View All Destinations', 'bella-italia-journey' ); ?>
                </a>
            </div>
            <?php

        else :
            ?>

            <p><?php esc_html_e( 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.', 'bella-italia-journey' ); ?></p>
            <?php
            get_search_form();

        endif;
        ?>
    </div><!-- .page-content -->
</section><!-- .no-results -->