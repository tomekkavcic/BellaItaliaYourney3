<?php
/**
 * Template part for displaying the hero section
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get hero content from customizer
$hero_title = get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) );
$hero_subtitle = get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences across Northern, Central and Southern regions', 'bella-italia-journey' ) );
$hero_button_text = get_theme_mod( 'bella_italia_hero_button_text', __( 'Explore Destinations', 'bella-italia-journey' ) );
$hero_button_url = get_theme_mod( 'bella_italia_hero_button_url', home_url( '/destination' ) );
$hero_image = get_theme_mod( 'bella_italia_hero_image', get_template_directory_uri() . '/assets/images/hero-default.jpg' );
?>

<div class="hero-section" style="background-image: url('<?php echo esc_url( $hero_image ); ?>');">
    <div class="container">
        <div class="hero-content">
            <?php if ( $hero_title ) : ?>
                <h1 class="hero-title"><?php echo esc_html( $hero_title ); ?></h1>
            <?php endif; ?>
            
            <?php if ( $hero_subtitle ) : ?>
                <p class="hero-subtitle"><?php echo esc_html( $hero_subtitle ); ?></p>
            <?php endif; ?>
            
            <div class="hero-search">
                <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <div class="input-group">
                        <input type="search" class="form-control" placeholder="<?php esc_attr_e( 'Search for destinations, experiences...', 'bella-italia-journey' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                        <input type="hidden" name="post_type" value="destination" />
                        <button type="submit" class="btn btn-primary"><?php esc_html_e( 'Search', 'bella-italia-journey' ); ?></button>
                    </div>
                </form>
            </div>
            
            <?php if ( $hero_button_text && $hero_button_url ) : ?>
                <div class="hero-buttons mt-4">
                    <a href="<?php echo esc_url( $hero_button_url ); ?>" class="btn btn-lg btn-primary"><?php echo esc_html( $hero_button_text ); ?></a>
                </div>
            <?php endif; ?>
            
            <div class="hero-regions mt-5">
                <div class="row">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <a href="<?php echo esc_url( add_query_arg( 'region', 'north', get_post_type_archive_link( 'destination' ) ) ); ?>" class="region-card region-north">
                            <div class="region-icon">
                                <i class="fas fa-mountain"></i>
                            </div>
                            <h3><?php esc_html_e( 'Northern Italy', 'bella-italia-journey' ); ?></h3>
                            <p><?php esc_html_e( 'Alps, Lakes & Renaissance Cities', 'bella-italia-journey' ); ?></p>
                        </a>
                    </div>
                    
                    <div class="col-md-4 mb-3 mb-md-0">
                        <a href="<?php echo esc_url( add_query_arg( 'region', 'central', get_post_type_archive_link( 'destination' ) ) ); ?>" class="region-card region-central">
                            <div class="region-icon">
                                <i class="fas fa-monument"></i>
                            </div>
                            <h3><?php esc_html_e( 'Central Italy', 'bella-italia-journey' ); ?></h3>
                            <p><?php esc_html_e( 'Art, History & Tuscan Landscapes', 'bella-italia-journey' ); ?></p>
                        </a>
                    </div>
                    
                    <div class="col-md-4">
                        <a href="<?php echo esc_url( add_query_arg( 'region', 'south', get_post_type_archive_link( 'destination' ) ) ); ?>" class="region-card region-south">
                            <div class="region-icon">
                                <i class="fas fa-umbrella-beach"></i>
                            </div>
                            <h3><?php esc_html_e( 'Southern Italy', 'bella-italia-journey' ); ?></h3>
                            <p><?php esc_html_e( 'Coastal Beauty, Islands & Cuisine', 'bella-italia-journey' ); ?></p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="hero-overlay"></div>
</div>