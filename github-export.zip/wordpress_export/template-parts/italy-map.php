<?php
/**
 * Template part for displaying the interactive Italy map
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Check if a specific region is active
$active_region = isset( $args['active_region'] ) ? $args['active_region'] : '';

// Map style: simple or detailed (with pins)
$map_style = isset( $args['map_style'] ) ? $args['map_style'] : get_theme_mod( 'bella_italia_map_view', 'simple' );

// Whether to show destination pins
$show_pins = isset( $args['show_pins'] ) ? $args['show_pins'] : ($map_style === 'detailed');

// Whether to show region names
$show_region_names = isset( $args['show_region_names'] ) ? $args['show_region_names'] : true;

// Additional map classes
$map_classes = isset( $args['map_classes'] ) ? $args['map_classes'] : '';

// Get all regions
$regions = array(
    'valle-d-aosta' => array(
        'name' => __( 'Valle d\'Aosta', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'piemonte' => array(
        'name' => __( 'Piemonte', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'liguria' => array(
        'name' => __( 'Liguria', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'lombardia' => array(
        'name' => __( 'Lombardia', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'trentino-alto-adige' => array(
        'name' => __( 'Trentino-Alto Adige', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'veneto' => array(
        'name' => __( 'Veneto', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'friuli-venezia-giulia' => array(
        'name' => __( 'Friuli-Venezia Giulia', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'emilia-romagna' => array(
        'name' => __( 'Emilia-Romagna', 'bella-italia-journey' ),
        'area' => 'north',
    ),
    'toscana' => array(
        'name' => __( 'Toscana', 'bella-italia-journey' ),
        'area' => 'central',
    ),
    'umbria' => array(
        'name' => __( 'Umbria', 'bella-italia-journey' ),
        'area' => 'central',
    ),
    'marche' => array(
        'name' => __( 'Marche', 'bella-italia-journey' ),
        'area' => 'central',
    ),
    'lazio' => array(
        'name' => __( 'Lazio', 'bella-italia-journey' ),
        'area' => 'central',
    ),
    'abruzzo' => array(
        'name' => __( 'Abruzzo', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'molise' => array(
        'name' => __( 'Molise', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'campania' => array(
        'name' => __( 'Campania', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'puglia' => array(
        'name' => __( 'Puglia', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'basilicata' => array(
        'name' => __( 'Basilicata', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'calabria' => array(
        'name' => __( 'Calabria', 'bella-italia-journey' ),
        'area' => 'south',
    ),
    'sicilia' => array(
        'name' => __( 'Sicilia', 'bella-italia-journey' ),
        'area' => 'islands',
    ),
    'sardegna' => array(
        'name' => __( 'Sardegna', 'bella-italia-journey' ),
        'area' => 'islands',
    ),
);

// Get destination pins if needed
$pins = array();
if ( $show_pins ) {
    $pins_query = new WP_Query( array(
        'post_type'      => 'destination',
        'posts_per_page' => -1,
        'meta_query'     => array(
            'relation' => 'AND',
            array(
                'key'     => '_destination_map_lat',
                'value'   => '',
                'compare' => '!=',
            ),
            array(
                'key'     => '_destination_map_lng',
                'value'   => '',
                'compare' => '!=',
            ),
        ),
    ) );

    if ( $pins_query->have_posts() ) {
        while ( $pins_query->have_posts() ) {
            $pins_query->the_post();
            $lat = get_post_meta( get_the_ID(), '_destination_map_lat', true );
            $lng = get_post_meta( get_the_ID(), '_destination_map_lng', true );
            
            if ( $lat && $lng ) {
                $pins[] = array(
                    'id'        => get_the_ID(),
                    'title'     => get_the_title(),
                    'url'       => get_permalink(),
                    'lat'       => $lat,
                    'lng'       => $lng,
                    'thumbnail' => has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'thumbnail' ) : '',
                );
            }
        }
        wp_reset_postdata();
    }
}

?>

<div class="italy-map-container <?php echo esc_attr( $map_classes ); ?>">
    <div class="italy-map-wrapper">
        <div class="italy-map" id="italy-map">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 800 1000" preserveAspectRatio="xMinYMin meet">
                <!-- Base map outline -->
                <path class="italy-outline" d="M385.31,37.44c-0.45,1.52-0.76,3.1-0.93,4.71c-0.36,3.19-0.13,6.15,0.6,9.53c1.08,5.02,1.11,10.24,0.09,16.02c-1.02,5.78-1.2,10.83-0.54,15.16c0.55,3.57,1.56,6.77,3.03,9.61c1.47,2.84,3.4,5.4,5.79,7.68c2.39,2.28,5.18,4.38,8.38,6.31c3.2,1.93,6.8,3.78,10.8,5.54c4,1.76,7.14,3.67,9.44,5.74c2.3,2.07,3.84,4.27,4.64,6.58c0.8,2.31,0.88,4.83,0.23,7.54c-0.65,2.71-1.34,5.56-2.08,8.53c-0.74,2.97-1.1,5.74-1.09,8.32c0.01,2.58,0.38,4.95,1.12,7.12c0.74,2.17,1.85,4.13,3.32,5.9c1.47,1.77,3.85,3.34,7.13,4.73c3.28,1.39,5.94,2.8,7.96,4.22c2.02,1.42,3.57,3.02,4.66,4.79c1.09,1.77,1.73,3.79,1.92,6.05c0.19,2.26,0.05,4.81-0.42,7.65c-0.47,2.84-0.59,5.68-0.35,8.49c0.24,2.81,0.87,5.6,1.89,8.36c1.02,2.76,2.8,5.49,5.34,8.19c2.54,2.7,4.68,5.2,6.43,7.52c1.75,2.32,3.2,4.64,4.33,6.96c1.14,2.32,2.07,4.64,2.79,6.97c0.73,2.33,1.32,4.64,1.78,6.94c1.04,5.19,0.88,10.24-0.49,15.17c-1.37,4.93-2.52,9.74-3.45,14.44c-0.93,4.7-1.32,9.28-1.19,13.76c0.13,4.48,0.98,8.83,2.54,13.07c1.56,4.24,4.57,8.35,9.02,12.35c2.68,2.42,5.02,4.85,7.02,7.29c2,2.44,3.67,4.92,5.02,7.44c1.35,2.52,2.37,5.09,3.06,7.71c0.69,2.62,1.05,5.29,1.08,8.01c0.15,13.27-2.75,25.94-8.71,38.01c-5.96,12.07-11.03,24.8-15.22,38.18c-4.19,13.38-6.69,26.74-7.5,40.09c-0.45,7.43-0.15,14.91,0.92,22.45c1.07,7.54,2.27,15.04,3.61,22.49c1.34,7.45,2.5,14.85,3.47,22.22c0.97,7.37,1.16,14.68,0.57,21.95c-0.75,9.21-2.78,18.42-6.09,27.61c-3.31,9.19-6.42,18.38-9.33,27.57c-2.92,9.18-5.18,18.36-6.8,27.52c-1.62,9.16-1.83,18.31-0.62,27.44c1.66,12.53,6.11,24.43,13.35,35.69c7.24,11.26,15.78,21.9,25.63,31.93c9.85,10.03,20.33,19.47,31.46,28.32c11.13,8.85,22.09,17.1,32.88,24.75c10.79,7.65,21.11,14.71,30.96,21.19c9.85,6.48,18.69,12.36,26.52,17.66c8.83,6.01,16.52,11.83,23.07,17.46c6.55,5.63,11.96,11.07,16.23,16.32c4.27,5.25,7.4,10.32,9.37,15.19c1.97,4.87,2.8,9.54,2.49,14.01c-0.31,4.76-1.64,9.16-3.99,13.2c-2.35,4.04-5.47,7.71-9.36,11.01c-3.89,3.3-8.37,6.22-13.44,8.76c-5.07,2.54-10.59,4.69-16.57,6.46c-5.98,1.77-10.96,3.84-14.96,6.21c-4,2.37-7,4.99-9.01,7.85c-2.01,2.86-3.03,5.96-3.05,9.28c-0.02,3.32,0.96,6.85,2.94,10.57c1.98,3.72,3.2,7.01,3.67,9.87c0.47,2.86,0.31,5.32-0.48,7.38c-0.79,2.06-2.08,3.74-3.88,5.03c-1.8,1.29-4.33,2.33-7.58,3.12c-3.25,0.79-6.63,1.16-10.12,1.11c-3.49-0.05-7.06-0.51-10.7-1.38c-3.64-0.87-7.08-1.83-10.32-2.89c-3.24-1.06-6.21-2.2-8.9-3.43c-2.69-1.23-5.07-2.53-7.15-3.9c-10.03-6.69-17.14-15.88-21.32-27.59c-4.18-11.71-7.46-21.13-9.83-28.27c-2.37-7.14-5.05-12.9-8.04-17.28c-2.99-4.38-7.01-7.59-12.04-9.62c-5.03-2.03-12.37-3.37-22.01-4.01c-9.57-0.69-17.88-1.85-24.95-3.48c-7.07-1.63-13.01-3.7-17.82-6.21c-4.81-2.51-8.5-5.46-11.07-8.86c-2.57-3.4-4.04-7.24-4.39-11.54c-0.35-4.3,0.04-8.54,1.15-12.72c1.11-4.18,2.99-8.31,5.64-12.37c2.65-4.06,6.07-7.56,10.27-10.49c2.83-1.97,5.93-3.62,9.3-4.94c3.37-1.32,6.79-2.23,10.26-2.72c3.47-0.49,6.99-0.56,10.56-0.2c3.57,0.36,7.17,1.14,10.79,2.34c3.62,1.2,6.44,2.64,8.46,4.32c2.02,1.68,3.27,3.57,3.76,5.67c0.49,2.1,0.21,4.41-0.84,6.92c-1.05,2.51-2.87,5.22-5.46,8.12c-2.05,2.19-3.64,4.13-4.76,5.82c-1.12,1.69-1.78,3.28-1.98,4.76c-0.2,1.48,0.06,3.04,0.79,4.67c0.73,1.63,2.16,3.34,4.3,5.12c2.09,1.72,4.3,2.84,6.63,3.36c2.33,0.52,4.66,0.49,7-0.1c2.34-0.59,4.67-1.58,7-2.98c2.33-1.4,4.46-2.95,6.39-4.67c1.93-1.72,3.58-3.5,4.96-5.35c1.38-1.85,2.48-3.77,3.31-5.77c1.78-4.14,1.61-8.54-0.51-13.2c-2.12-4.66-4.38-9.32-6.8-13.96c-2.42-4.64-4.51-9.3-6.28-13.97c-1.77-4.67-2.5-9.33-2.19-13.99c0.42-6.34,2.25-12.09,5.51-17.25c3.26-5.16,7.27-9.74,12.04-13.76c4.77-4.02,10.1-7.46,15.99-10.33c5.89-2.87,11.61-5.17,17.16-6.9c5.55-1.73,10.67-2.91,15.37-3.52c4.7-0.61,8.56-0.69,11.59-0.23c2.87,0.45,5.32,1.39,7.33,2.8c2.01,1.41,3.63,3.16,4.86,5.24c1.23,2.08,2.08,4.5,2.55,7.25c0.47,2.75,0.6,5.67,0.38,8.75c-0.48,6.94-2.66,13.11-6.56,18.49c-3.9,5.38-8.5,10.02-13.8,13.94c-5.3,3.92-10.98,7.16-17.04,9.73c-6.06,2.57-11.61,4.45-16.66,5.65c-5.05,1.2-9.59,1.72-13.62,1.54c-4.03-0.18-7.36-1.11-9.98-2.8c-2.53-1.69-3.79-3.78-3.77-6.25c0.02-2.47,1.06-5.03,3.14-7.67c2.08-2.64,5.08-5.24,9.01-7.81c3.93-2.57,7.26-4.71,10-6.42c2.74-1.71,5.13-3.4,7.17-5.07c2.04-1.67,3.67-3.48,4.9-5.43c1.23-1.95,2.06-4.21,2.5-6.78c-0.16-2.69-0.66-5.2-1.49-7.53c-0.84-2.33-2.02-4.34-3.55-6.03c-1.53-1.69-3.43-3.06-5.7-4.1c-2.27-1.04-5.36-1.8-9.27-2.27c-3.91-0.47-7.13-0.02-9.66,1.35c-2.53,1.37-4.23,3.39-5.09,6.06c-0.86,2.67-0.89,5.98-0.09,9.93c0.8,3.95,2.43,8.54,4.89,13.77c1.93,4.14,3.11,7.33,3.53,9.59c0.42,2.26,0.27,4.05-0.45,5.38c-0.72,1.33-1.92,2.29-3.6,2.9c-1.68,0.61-3.74,0.96-6.19,1.05c-2.45,0.09-5.01,0.13-7.68,0.13c-2.82,0-5.7-0.14-8.64-0.41c-2.94-0.27-5.81-0.91-8.61-1.91c-2.8-1-5.42-2.46-7.87-4.37c-2.45-1.91-4.03-4.51-4.75-7.81c-0.3-1.39-0.17-2.89,0.37-4.51c0.54-1.62,1.28-3.18,2.21-4.69c0.93-1.51,1.95-2.97,3.06-4.38c1.11-1.41,2.03-2.58,2.78-3.52c0.75-0.94,0.93-1.63,0.55-2.07c-0.38-0.44-1.33-0.82-2.84-1.14c-1.51-0.32-3.02-0.57-4.53-0.77c-1.51-0.2-2.69-0.4-3.53-0.61c-3.21-0.75-6.06-2.06-8.56-3.95c-2.5-1.89-4.52-4.13-6.06-6.74c-1.54-2.61-2.59-5.56-3.17-8.85c-0.58-3.29-0.42-6.83,0.47-10.6c0.89-3.77,1.69-7.04,2.4-9.8c0.71-2.76,1.3-5.09,1.77-7c0.47-1.91,0.82-3.47,1.05-4.69c0.23-1.22,0.34-2.17,0.34-2.85c0-6.34-1.71-12.22-5.14-17.63c-3.43-5.41-7.57-10.83-12.44-16.27c-4.87-5.44-9.87-11.02-14.99-16.74c-5.12-5.72-9.18-12.08-12.17-19.07c-2.84-6.64-3.89-13.29-3.15-19.94c0.74-6.65,3-12.99,6.81-19.02c3.81-6.03,8.83-11.54,15.08-16.53c6.25-4.99,12.93-8.99,20.05-12.01c10.14-4.3,19.3-9.2,27.49-14.71c8.19-5.51,15.38-11.61,21.58-18.29c6.2-6.68,11.39-14.05,15.57-22.11c4.18-8.06,7.32-16.78,9.42-26.16c2.1-9.38,3.1-19.41,3.01-30.09c-0.09-10.68-1.83-21.89-5.2-33.63c-1.36-4.74-2.36-9.55-3.02-14.43c-0.66-4.88-0.96-9.82-0.89-14.84c0.07-5.02,0.5-10.1,1.3-15.25c0.8-5.15,2.08-10.36,3.85-15.63c1.77-5.27,3.04-10.41,3.82-15.4c0.78-4.99,0.95-9.84,0.5-14.55c-0.45-4.71-1.55-9.25-3.31-13.64c-1.76-4.39-4.17-8.6-7.24-12.63c-3.07-4.03-5.3-8.38-6.7-13.04c-1.4-4.66-1.98-9.4-1.74-14.21c0.24-4.81,1.31-9.64,3.21-14.47c1.9-4.83,4.5-9.4,7.81-13.7c3.31-4.3,7.6-8.15,12.87-11.54c5.27-3.39,10.09-5.91,14.47-7.57c4.38-1.66,8.11-2.69,11.18-3.1c3.07-0.41,5.33-0.35,6.79,0.17c1.46,0.52,2.09,1.35,1.91,2.48c-0.18,1.13-1.07,2.53-2.68,4.2c-4.3,4.14-8.13,8.65-11.51,13.52c-3.38,4.87-6.2,9.91-8.46,15.12c-2.26,5.21-3.71,10.43-4.34,15.66c-0.63,5.23-0.25,10.36,1.15,15.38c1.35,4.89,3.12,9.42,5.28,13.57c2.16,4.15,4.5,8.11,7.01,11.88c2.51,3.77,5.09,7.45,7.73,11.05c2.64,3.6,4.96,7.32,6.96,11.16c1.95,3.84,3.23,7.92,3.84,12.25c0.61,4.33,0.39,8.99-0.66,13.98c-1.05,4.99-2.04,9.66-2.97,14.01c-0.93,4.35-1.57,8.45-1.93,12.29c-0.36,3.84-0.34,7.52,0.06,11.04c0.4,3.52,1.35,7.01,2.85,10.47c1.5,3.46,3.82,7,6.96,10.62c3.39,3.91,6.11,8.02,8.17,12.33c2.06,4.31,3.3,8.73,3.72,13.25c0.42,4.52,0.01,9.04-1.23,13.57c-1.24,4.53-3.19,8.86-5.83,13.01c-2.64,4.15-6,7.81-10.08,10.98c-4.08,3.17-8.8,5.64-14.16,7.4c-5.36,1.76-10.15,2.82-14.39,3.17c-4.24,0.35-7.81,0.19-10.73-0.48c-2.92-0.67-5.08-1.7-6.5-3.08c-1.42-1.38-2.04-3.01-1.87-4.88c0.15-1.54,0.82-2.97,2.02-4.28c1.2-1.31,2.7-2.51,4.5-3.6c1.8-1.09,3.8-2.09,5.99-3.01c2.19-0.92,4.4-1.78,6.62-2.58c2.22-0.8,4.24-1.75,6.05-2.84c1.81-1.09,3.15-2.44,4.01-4.04c0.86-1.6,0.95-3.58,0.27-5.95c-0.68-2.37-2.06-4.66-4.15-6.87c-2.09-2.21-3.48-4.6-4.19-7.17c-0.71-2.57-0.59-5.23,0.35-7.97c0.94-2.74,2.52-5.47,4.73-8.19c2.21-2.72,4.61-5.03,7.19-6.94c2.58-1.91,5.2-3.41,7.85-4.52c2.65-1.11,5.3-1.85,7.94-2.23c0.9-0.14,1.79-0.29,2.68-0.45c0.89-0.16,1.81-0.31,2.74-0.46c0.93-0.15,1.88-0.29,2.86-0.44c0.98-0.15,1.94-0.28,2.88-0.39c0.82-0.11,1.62-0.22,2.4-0.33c0.78-0.11,1.54-0.21,2.26-0.31c0.72-0.1,1.41-0.17,2.06-0.2c0.65-0.03,1.25,0.01,1.81,0.13c0.71,0.15,1.3,0.59,1.77,1.32c0.47,0.73,0.82,1.62,1.05,2.67c0.23,1.05,0.34,2.18,0.35,3.38c0.01,1.2-0.12,2.37-0.38,3.51c-0.26,1.14-0.67,2.18-1.23,3.12c-0.56,0.94-1.27,1.7-2.13,2.28c-1.08,0.71-2.18,1.19-3.29,1.46c-1.11,0.27-2.25,0.34-3.4,0.22c-1.15-0.12-2.41-0.25-3.76-0.38c-1.35-0.13-2.8-0.3-4.32-0.5c-0.75-0.1-1.49-0.18-2.22-0.24c-0.73-0.06-1.45-0.09-2.15-0.07c-0.7,0.02-1.36,0.08-1.98,0.18c-0.62,0.1-1.19,0.27-1.7,0.5c-1.05,0.46-2.08,1.27-3.08,2.43c-1,1.16-1.98,2.42-2.92,3.79c-0.94,1.37-1.82,2.73-2.64,4.11c-0.82,1.38-1.54,2.59-2.16,3.63c-0.62,1.04-1.06,1.78-1.32,2.22c-0.26,0.44-0.23,0.59,0.09,0.45c0.32-0.14,0.92-0.54,1.81-1.19c0.89-0.65,1.99-1.42,3.3-2.31c1.31-0.89,2.73-1.81,4.26-2.77c1.53-0.96,3.15-1.88,4.86-2.76c1.71-0.88,3.5-1.65,5.37-2.31c1.87-0.66,3.8-1.12,5.8-1.38c3.24-0.45,6.09-0.23,8.53,0.67c2.44,0.9,4.46,2.3,6.06,4.19c1.6,1.89,2.75,4.24,3.44,7.04c0.69,2.8,0.92,5.91,0.69,9.32c-0.23,3.41-1.01,7.02-2.35,10.81c-1.34,3.79-3.24,7.28-5.72,10.47c-2.26,2.9-4.92,5.25-7.98,7.07c-3.06,1.82-6.26,3.22-9.6,4.2c-3.34,0.98-6.74,1.56-10.19,1.75c-3.45,0.19-6.72,0.15-9.81-0.12c-2.29-0.2-4.34-0.58-6.15-1.13c-1.81-0.55-3.37-1.28-4.67-2.19c-1.3-0.91-2.34-1.99-3.1-3.23c-0.76-1.24-1.24-2.64-1.43-4.2c-0.22-1.69-0.03-3.37,0.58-5.05c0.61-1.68,1.5-3.28,2.67-4.8c1.17-1.52,2.57-2.93,4.19-4.23c1.62-1.3,3.31-2.41,5.09-3.33c1.99-1.03,3.75-1.77,5.28-2.22c1.53-0.45,2.83-0.65,3.91-0.61c1.08,0.04,1.92,0.31,2.54,0.82c0.62,0.51,1.02,1.17,1.2,1.97c0.33,1.55,0.1,2.95-0.69,4.2c-0.79,1.25-1.85,2.35-3.17,3.29c-1.32,0.94-2.79,1.73-4.4,2.37c-1.61,0.64-3.17,1.12-4.69,1.43c-1.52,0.31-2.9,0.47-4.16,0.48c-1.26,0.01-2.1-0.11-2.53-0.37c-0.43-0.26-0.66-0.45-0.7-0.58c-0.04-0.13,0.12-0.21,0.48-0.24c1.93-0.14,3.79-0.68,5.57-1.61c1.78-0.93,3.28-2.08,4.49-3.45c1.21-1.37,2.05-2.83,2.52-4.37c0.47-1.54,0.4-3.02-0.22-4.45c-0.42-0.97-1.04-1.62-1.85-1.95c-0.81-0.33-1.73-0.36-2.76-0.09c-1.03,0.27-2.09,0.78-3.17,1.53c-1.08,0.75-2.11,1.65-3.09,2.71c-0.98,1.06-1.83,2.25-2.55,3.58c-0.72,1.33-1.3,2.79-1.72,4.39c-0.39,1.46-0.5,2.83-0.35,4.1c0.15,1.27,0.54,2.4,1.15,3.4c0.61,1,1.44,1.85,2.49,2.56c1.05,0.71,2.34,1.22,3.87,1.52c1.47,0.3,3.28,0.39,5.43,0.27c2.15-0.12,4.27-0.5,6.35-1.14c2.08-0.64,4.12-1.49,6.11-2.57c1.99-1.08,3.73-2.38,5.2-3.91c1.47-1.53,2.66-3.3,3.57-5.31c1.56-3.43,1.94-7.05,1.14-10.85c-0.8-3.8-2.43-6.99-4.87-9.55c-2.44-2.56-5.36-4.02-8.76-4.38c-3.4-0.36-7.16,0.29-11.28,1.96c-2.9,1.11-5.83,2.62-8.8,4.52c-2.97,1.9-5.9,3.87-8.78,5.89c-2.88,2.02-5.68,3.99-8.4,5.9c-2.72,1.91-5.29,3.56-7.7,4.95c-2.41,1.39-4.63,2.35-6.66,2.88c-2.03,0.53-3.71,0.51-5.04-0.08c-1.33-0.59-2.28-1.73-2.84-3.44c-0.56-1.71-0.73-3.82-0.51-6.33c0.22-2.51,0.83-5.42,1.84-8.73c1.01-3.31,1.59-6.23,1.73-8.76c0.14-2.53-0.18-4.67-0.97-6.42c-0.79-1.75-2.02-3.13-3.7-4.14c-1.68-1.01-3.96-1.64-6.83-1.9c-4.75-0.59-8.68-1.94-11.78-4.07c-3.1-2.13-5.4-4.79-6.9-7.98c-1.5-3.19-2.09-6.9-1.77-11.13c0.32-4.23,1.56-8.82,3.74-13.76c4.9-11.07,11.27-18.39,19.12-21.95c7.85-3.56,15.97-4.32,24.37-2.28c8.4,2.04,16.48,6.13,24.24,12.27c7.76,6.14,13.56,12.76,17.4,19.87"/>
                
                <!-- Region shapes -->
                <?php 
                // Loop through regions to create the clickable areas
                foreach ($regions as $slug => $region_data) : 
                    $region_class = 'region';
                    // Add area class (north, central, south, islands)
                    $region_class .= ' area-' . $region_data['area'];
                    // Add active class if this region is the active one
                    if ($active_region === $slug) {
                        $region_class .= ' active';
                    }
                    
                    // Get the path data for this region
                    $path_data = bella_italia_get_region_path($slug);
                ?>
                    <path id="region-<?php echo esc_attr($slug); ?>" 
                          class="<?php echo esc_attr($region_class); ?>" 
                          d="<?php echo $path_data; ?>" 
                          data-region="<?php echo esc_attr($slug); ?>" 
                          data-name="<?php echo esc_attr($region_data['name']); ?>" 
                          data-area="<?php echo esc_attr($region_data['area']); ?>">
                    </path>
                <?php endforeach; ?>
                
                <?php if ($show_region_names) : ?>
                    <!-- Region labels -->
                    <g class="region-labels">
                        <?php foreach ($regions as $slug => $region_data) : ?>
                            <text x="<?php echo bella_italia_get_region_label_position($slug, 'x'); ?>" 
                                  y="<?php echo bella_italia_get_region_label_position($slug, 'y'); ?>" 
                                  class="region-label"
                                  data-region="<?php echo esc_attr($slug); ?>">
                                <?php echo esc_html($region_data['name']); ?>
                            </text>
                        <?php endforeach; ?>
                    </g>
                <?php endif; ?>
                
                <?php if ($show_pins && !empty($pins)) : ?>
                    <!-- Destination pins -->
                    <g class="destination-pins">
                        <?php foreach ($pins as $pin) : 
                            // Convert lat/lng to SVG coordinates
                            list($x, $y) = bella_italia_convert_lat_lng_to_coordinates($pin['lat'], $pin['lng']);
                        ?>
                            <circle class="destination-pin" 
                                    cx="<?php echo esc_attr($x); ?>" 
                                    cy="<?php echo esc_attr($y); ?>" 
                                    r="5" 
                                    data-id="<?php echo esc_attr($pin['id']); ?>" 
                                    data-title="<?php echo esc_attr($pin['title']); ?>" 
                                    data-url="<?php echo esc_url($pin['url']); ?>"
                                    <?php if ($pin['thumbnail']) : ?>
                                    data-thumbnail="<?php echo esc_url($pin['thumbnail']); ?>"
                                    <?php endif; ?>>
                            </circle>
                        <?php endforeach; ?>
                    </g>
                <?php endif; ?>
            </svg>
            
            <?php if ($show_pins && !empty($pins)) : ?>
                <!-- Pin tooltip -->
                <div class="pin-tooltip" style="display: none;">
                    <div class="pin-tooltip-content">
                        <div class="pin-tooltip-image"></div>
                        <div class="pin-tooltip-title"></div>
                    </div>
                    <div class="pin-tooltip-arrow"></div>
                </div>
            <?php endif; ?>
            
            <!-- Region tooltip -->
            <div class="region-tooltip" style="display: none;">
                <div class="region-tooltip-content">
                    <div class="region-tooltip-title"></div>
                </div>
                <div class="region-tooltip-arrow"></div>
            </div>
        </div>
        
        <?php if (isset($args['show_legend']) && $args['show_legend']) : ?>
            <!-- Map legend -->
            <div class="italy-map-legend">
                <div class="legend-title"><?php _e('Italy Regions', 'bella-italia-journey'); ?></div>
                <div class="legend-areas">
                    <div class="legend-area">
                        <span class="area-color area-north"></span>
                        <span class="area-name"><?php _e('Northern Italy', 'bella-italia-journey'); ?></span>
                    </div>
                    <div class="legend-area">
                        <span class="area-color area-central"></span>
                        <span class="area-name"><?php _e('Central Italy', 'bella-italia-journey'); ?></span>
                    </div>
                    <div class="legend-area">
                        <span class="area-color area-south"></span>
                        <span class="area-name"><?php _e('Southern Italy', 'bella-italia-journey'); ?></span>
                    </div>
                    <div class="legend-area">
                        <span class="area-color area-islands"></span>
                        <span class="area-name"><?php _e('Islands', 'bella-italia-journey'); ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
/**
 * Helper function to get path data for a specific region
 */
function bella_italia_get_region_path($region_slug) {
    // This function should return the SVG path data for each region
    // In a real implementation, these would be carefully plotted path data
    // Simplified example for demonstration:
    $paths = array(
        'valle-d-aosta' => 'M100,120 L120,110 L130,130 L110,140 Z',
        'piemonte' => 'M80,130 L130,110 L150,160 L100,180 Z',
        'liguria' => 'M120,180 L150,160 L180,180 L140,190 Z',
        'lombardia' => 'M150,120 L200,110 L220,160 L170,170 Z',
        'trentino-alto-adige' => 'M230,100 L260,90 L280,120 L250,130 Z',
        'veneto' => 'M250,120 L290,110 L300,150 L260,160 Z',
        'friuli-venezia-giulia' => 'M310,110 L330,100 L340,130 L320,140 Z',
        'emilia-romagna' => 'M170,170 L250,160 L270,200 L190,210 Z',
        'toscana' => 'M190,210 L240,200 L250,250 L200,260 Z',
        'umbria' => 'M250,230 L270,220 L280,250 L260,260 Z',
        'marche' => 'M270,200 L300,190 L310,230 L280,240 Z',
        'lazio' => 'M220,260 L270,250 L280,300 L230,310 Z',
        'abruzzo' => 'M280,270 L310,260 L320,300 L290,310 Z',
        'molise' => 'M300,310 L320,300 L330,320 L310,330 Z',
        'campania' => 'M260,320 L300,310 L310,350 L270,360 Z',
        'puglia' => 'M330,320 L370,310 L390,360 L350,370 Z',
        'basilicata' => 'M310,350 L340,340 L350,380 L320,390 Z',
        'calabria' => 'M320,390 L350,380 L370,430 L340,440 Z',
        'sicilia' => 'M290,460 L350,450 L360,490 L300,500 Z',
        'sardegna' => 'M150,350 L190,340 L200,390 L160,400 Z',
    );
    
    return isset($paths[$region_slug]) ? $paths[$region_slug] : '';
}

/**
 * Helper function to get label position for a specific region
 */
function bella_italia_get_region_label_position($region_slug, $axis = 'x') {
    // This function should return the X or Y coordinate for region labels
    // In a real implementation, these would be carefully positioned
    $positions = array(
        'valle-d-aosta' => array('x' => 115, 'y' => 125),
        'piemonte' => array('x' => 115, 'y' => 145),
        'liguria' => array('x' => 145, 'y' => 178),
        'lombardia' => array('x' => 185, 'y' => 140),
        'trentino-alto-adige' => array('x' => 255, 'y' => 110),
        'veneto' => array('x' => 275, 'y' => 135),
        'friuli-venezia-giulia' => array('x' => 325, 'y' => 120),
        'emilia-romagna' => array('x' => 220, 'y' => 185),
        'toscana' => array('x' => 220, 'y' => 230),
        'umbria' => array('x' => 265, 'y' => 240),
        'marche' => array('x' => 290, 'y' => 215),
        'lazio' => array('x' => 250, 'y' => 280),
        'abruzzo' => array('x' => 300, 'y' => 290),
        'molise' => array('x' => 315, 'y' => 315),
        'campania' => array('x' => 285, 'y' => 335),
        'puglia' => array('x' => 360, 'y' => 340),
        'basilicata' => array('x' => 330, 'y' => 365),
        'calabria' => array('x' => 345, 'y' => 410),
        'sicilia' => array('x' => 325, 'y' => 475),
        'sardegna' => array('x' => 175, 'y' => 370),
    );
    
    return isset($positions[$region_slug][$axis]) ? $positions[$region_slug][$axis] : ($axis === 'x' ? 0 : 0);
}

/**
 * Helper function to convert latitude and longitude to SVG coordinates
 */
function bella_italia_convert_lat_lng_to_coordinates($lat, $lng) {
    // This function should convert geographic coordinates to SVG coordinates
    // This is a simplified example - real implementation would require proper projection
    
    // Define the bounding box of Italy in lat/lng
    $min_lat = 35.29; // Southern point of Sicily
    $max_lat = 47.09; // Northern point of Alps
    $min_lng = 6.63;  // Western point
    $max_lng = 18.52; // Eastern point
    
    // Define the bounding box in SVG coordinates
    $min_x = 80;
    $max_x = 390;
    $min_y = 90;
    $max_y = 500;
    
    // Convert coordinates
    $x = (($lng - $min_lng) / ($max_lng - $min_lng)) * ($max_x - $min_x) + $min_x;
    // Note: y coordinate is inverted (SVG has origin at top-left)
    $y = (1 - (($lat - $min_lat) / ($max_lat - $min_lat))) * ($max_y - $min_y) + $min_y;
    
    return array($x, $y);
}