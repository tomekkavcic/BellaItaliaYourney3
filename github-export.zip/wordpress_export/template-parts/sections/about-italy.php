<?php
/**
 * Template part for displaying the About Italy section on the front page
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get customizer options (if needed)
$section_title = __( 'About Italy', 'bella-italia-journey' );
$section_content = __( 
    '<p>Italy, a country in southern Europe, is known for its rich history, art, culture, and cuisine. 
    It is home to some of the world\'s most famous landmarks, including the Colosseum, the Leaning Tower of Pisa, 
    and the canals of Venice.</p>
    
    <p>With its diverse landscapes, from the snow-capped Alps in the north to the sunny beaches of the south, 
    Italy offers a wide range of experiences for travelers. The country is divided into 20 regions, each with its 
    own unique character and traditions.</p>
    
    <p>Italian cuisine is renowned worldwide and varies significantly by region. From the pasta and olive oil of the 
    south to the rice and butter of the north, Italian food is a celebration of fresh, local ingredients.</p>', 
    'bella-italia-journey' 
);

// Get custom fields if section is from a page
$about_page_id = get_theme_mod( 'bella_italia_about_page' );
if ( $about_page_id ) {
    $about_page = get_post( $about_page_id );
    if ( $about_page ) {
        $section_title = get_the_title( $about_page );
        $section_content = apply_filters( 'the_content', $about_page->post_content );
    }
}

// Get custom image if set
$section_image = get_theme_mod( 'bella_italia_about_image', get_template_directory_uri() . '/assets/images/about-italy.jpg' );

// Classes for alternating background
$section_class = 'about-italy-section';
$section_style = '';

// Check if background color is set in theme options
$bg_color = get_theme_mod( 'bella_italia_about_bg_color', '' );
if ( $bg_color ) {
    $section_style = 'background-color: ' . esc_attr( $bg_color ) . ';';
}
?>

<section class="<?php echo esc_attr( $section_class ); ?> py-5" <?php if ( $section_style ) echo 'style="' . $section_style . '"'; ?>>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="about-content-wrapper">
                    <?php if ( $section_title ) : ?>
                        <h2 class="section-title"><?php echo esc_html( $section_title ); ?></h2>
                    <?php endif; ?>
                    
                    <div class="section-content">
                        <?php echo $section_content; ?>
                    </div>
                    
                    <?php if ( $about_page_id ) : ?>
                        <div class="mt-4">
                            <a href="<?php echo esc_url( get_permalink( $about_page_id ) ); ?>" class="btn btn-outline-primary">
                                <?php _e( 'Read More', 'bella-italia-journey' ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="about-image-wrapper">
                    <?php if ( $section_image ) : ?>
                        <img src="<?php echo esc_url( $section_image ); ?>" alt="<?php echo esc_attr( $section_title ); ?>" class="img-fluid rounded shadow-lg">
                        
                        <div class="italy-regions-count">
                            <div class="region-count-box">
                                <span class="region-count">20</span>
                                <span class="region-label"><?php _e( 'Regions', 'bella-italia-journey' ); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="row mt-5">
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="italy-fact-box text-center">
                    <div class="fact-icon">
                        <i class="fa fa-utensils"></i>
                    </div>
                    <h3><?php _e( 'Cuisine', 'bella-italia-journey' ); ?></h3>
                    <p><?php _e( 'Italian cuisine is celebrated worldwide for its simplicity, quality ingredients, and regional diversity.', 'bella-italia-journey' ); ?></p>
                </div>
            </div>
            
            <div class="col-md-4 mb-4 mb-md-0">
                <div class="italy-fact-box text-center">
                    <div class="fact-icon">
                        <i class="fa fa-landmark"></i>
                    </div>
                    <h3><?php _e( 'Culture', 'bella-italia-journey' ); ?></h3>
                    <p><?php _e( 'Italy has been the birthplace of art movements, scientific breakthroughs, and architectural innovations.', 'bella-italia-journey' ); ?></p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="italy-fact-box text-center">
                    <div class="fact-icon">
                        <i class="fa fa-mountain"></i>
                    </div>
                    <h3><?php _e( 'Geography', 'bella-italia-journey' ); ?></h3>
                    <p><?php _e( 'From Alpine mountains to Mediterranean beaches, Italy offers diverse landscapes in a boot-shaped peninsula.', 'bella-italia-journey' ); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>