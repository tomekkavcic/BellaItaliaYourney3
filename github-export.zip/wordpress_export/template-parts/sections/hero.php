<?php
/**
 * Template part for displaying hero section on the front page
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get customizer options
$hero_title = get_theme_mod( 'bella_italia_hero_title', __( 'Discover the Beauty of Italy', 'bella-italia-journey' ) );
$hero_subtitle = get_theme_mod( 'bella_italia_hero_subtitle', __( 'Explore authentic experiences and hidden gems across the Italian peninsula', 'bella-italia-journey' ) );
$hero_cta_text = get_theme_mod( 'bella_italia_hero_cta_text', __( 'Explore Destinations', 'bella-italia-journey' ) );
$hero_cta_url = get_theme_mod( 'bella_italia_hero_cta_url', get_post_type_archive_link( 'destination' ) );
$hero_bg_image = get_theme_mod( 'bella_italia_hero_background' );
$enable_search = get_theme_mod( 'bella_italia_hero_enable_search', true );
$enable_map = get_theme_mod( 'bella_italia_hero_enable_map', true );

// Default background if none set
if ( empty( $hero_bg_image ) ) {
    $hero_bg_image = get_template_directory_uri() . '/assets/images/hero-default.jpg';
}

// Determine hero class based on features
$hero_class = 'hero-section';
if ( $enable_map ) {
    $hero_class .= ' with-map';
}
if ( $enable_search ) {
    $hero_class .= ' with-search';
}
?>

<section class="<?php echo esc_attr( $hero_class ); ?>" style="background-image: url('<?php echo esc_url( $hero_bg_image ); ?>');">
    <div class="hero-overlay"></div>
    
    <div class="container">
        <div class="hero-content">
            <?php if ( $hero_title ) : ?>
                <h1 class="hero-title"><?php echo esc_html( $hero_title ); ?></h1>
            <?php endif; ?>
            
            <?php if ( $hero_subtitle ) : ?>
                <p class="hero-subtitle"><?php echo esc_html( $hero_subtitle ); ?></p>
            <?php endif; ?>
            
            <?php if ( $enable_search ) : ?>
                <div class="hero-search-form">
                    <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <div class="input-group">
                            <input type="search" class="search-field form-control" placeholder="<?php echo esc_attr_x( 'Search for destinations, experiences...', 'placeholder', 'bella-italia-journey' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                            <input type="hidden" name="post_type" value="destination" />
                            <div class="input-group-append">
                                <button type="submit" class="search-submit btn btn-primary">
                                    <i class="fa fa-search"></i>
                                    <span class="screen-reader-text"><?php echo _x( 'Search', 'submit button', 'bella-italia-journey' ); ?></span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            
            <?php if ( $hero_cta_text && $hero_cta_url ) : ?>
                <div class="hero-cta">
                    <a href="<?php echo esc_url( $hero_cta_url ); ?>" class="btn btn-primary btn-lg">
                        <?php echo esc_html( $hero_cta_text ); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ( $enable_map ) : ?>
        <div class="hero-map-wrapper">
            <div class="hero-map-container">
                <div class="map-heading">
                    <h2><?php _e( 'Explore Italy by Region', 'bella-italia-journey' ); ?></h2>
                    <p><?php _e( 'Select a region to discover destinations', 'bella-italia-journey' ); ?></p>
                </div>
                
                <?php get_template_part( 'template-parts/italy-map' ); ?>
                
                <div class="region-legend">
                    <div class="region-legend-item north">
                        <span class="legend-color"></span>
                        <span class="legend-name"><?php _e( 'Northern Italy', 'bella-italia-journey' ); ?></span>
                    </div>
                    <div class="region-legend-item central">
                        <span class="legend-color"></span>
                        <span class="legend-name"><?php _e( 'Central Italy', 'bella-italia-journey' ); ?></span>
                    </div>
                    <div class="region-legend-item south">
                        <span class="legend-color"></span>
                        <span class="legend-name"><?php _e( 'Southern Italy', 'bella-italia-journey' ); ?></span>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="hero-scrolldown">
        <a href="#primary" class="scrolldown-link">
            <i class="fa fa-chevron-down"></i>
            <span class="screen-reader-text"><?php _e( 'Scroll Down', 'bella-italia-journey' ); ?></span>
        </a>
    </div>
</section>