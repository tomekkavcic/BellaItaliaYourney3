<?php
/**
 * Template part for displaying featured destinations on the front page
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get customizer options
$section_title = get_theme_mod( 'bella_italia_featured_destinations_title', __( 'Explore Italy', 'bella-italia-journey' ) );
$section_subtitle = get_theme_mod( 'bella_italia_featured_destinations_subtitle', __( 'Discover the most beautiful destinations in Italy', 'bella-italia-journey' ) );
$count = get_theme_mod( 'bella_italia_featured_destinations_count', 6 );

// Classes for alternating background
$section_class = 'featured-destinations-section';

// Check if background color is set in theme options
$bg_color = get_theme_mod( 'bella_italia_featured_destinations_bg_color', '' );
$section_style = '';
if ( $bg_color ) {
    $section_style = 'background-color: ' . esc_attr( $bg_color ) . ';';
}

// Query featured destinations
$args = array(
    'post_type'      => 'destination',
    'posts_per_page' => $count,
    'meta_query'     => array(
        array(
            'key'   => '_featured_destination',
            'value' => '1',
        ),
    ),
);

// If no featured destinations, get latest destinations
$featured_query = new WP_Query( $args );

if ( ! $featured_query->have_posts() ) {
    // If no featured destinations, get latest destinations
    $args = array(
        'post_type'      => 'destination',
        'posts_per_page' => $count,
    );
    $featured_query = new WP_Query( $args );
}

// Get regions for filtering
$regions = get_terms( array(
    'taxonomy'   => 'region',
    'hide_empty' => true,
) );

?>

<section class="<?php echo esc_attr( $section_class ); ?> py-5" <?php if ( $section_style ) echo 'style="' . $section_style . '"'; ?>>
    <div class="container">
        <div class="row mb-5">
            <div class="col-lg-8 mx-auto text-center">
                <?php if ( $section_title ) : ?>
                    <h2 class="section-title"><?php echo esc_html( $section_title ); ?></h2>
                <?php endif; ?>
                
                <?php if ( $section_subtitle ) : ?>
                    <p class="section-subtitle"><?php echo esc_html( $section_subtitle ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if ( ! empty( $regions ) && ! is_wp_error( $regions ) ) : ?>
            <div class="row mb-4">
                <div class="col-12">
                    <div class="region-filters text-center">
                        <div class="btn-group region-filter-buttons" role="group" aria-label="<?php esc_attr_e( 'Region filters', 'bella-italia-journey' ); ?>">
                            <button type="button" class="btn btn-outline-primary active" data-region="all"><?php _e( 'All Regions', 'bella-italia-journey' ); ?></button>
                            
                            <?php foreach ( $regions as $region ) : ?>
                                <button type="button" class="btn btn-outline-primary" data-region="<?php echo esc_attr( $region->slug ); ?>">
                                    <?php echo esc_html( $region->name ); ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if ( $featured_query->have_posts() ) : ?>
            <div class="row destinations-grid">
                <?php while ( $featured_query->have_posts() ) : $featured_query->the_post(); 
                    // Get destination details
                    $location = get_post_meta( get_the_ID(), '_destination_location', true );
                    
                    // Get region for filtering
                    $destination_regions = get_the_terms( get_the_ID(), 'region' );
                    $region_classes = '';
                    $region_names = array();
                    
                    if ( ! empty( $destination_regions ) && ! is_wp_error( $destination_regions ) ) {
                        foreach ( $destination_regions as $region ) {
                            $region_classes .= ' region-' . $region->slug;
                            $region_names[] = $region->name;
                        }
                    }
                ?>
                    <div class="col-md-6 col-lg-4 mb-4 destination-item<?php echo esc_attr( $region_classes ); ?>">
                        <div class="card destination-card h-100">
                            <div class="card-img-wrapper">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail( 'medium_large', array( 'class' => 'card-img-top' ) ); ?>
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ( ! empty( $region_names ) ) : ?>
                                    <div class="destination-region">
                                        <span class="badge bg-primary"><?php echo esc_html( implode( ', ', $region_names ) ); ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ( get_post_meta( get_the_ID(), '_featured_destination', true ) ) : ?>
                                    <div class="featured-badge">
                                        <span class="badge bg-warning text-dark">
                                            <i class="fa fa-star"></i> <?php _e( 'Featured', 'bella-italia-journey' ); ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-body">
                                <h3 class="card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                
                                <?php if ( $location ) : ?>
                                    <div class="destination-location mb-2">
                                        <i class="fa fa-map-marker-alt"></i> <?php echo esc_html( $location ); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="card-text">
                                    <?php the_excerpt(); ?>
                                </div>
                            </div>
                            
                            <div class="card-footer">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="destination-highlights">
                                            <?php
                                            // Show up to 3 highlights/features
                                            $highlights = array();
                                            
                                            if ( get_post_meta( get_the_ID(), '_destination_local_food', true ) ) {
                                                $highlights[] = '<span class="highlight-item"><i class="fa fa-utensils"></i></span>';
                                            }
                                            
                                            if ( get_post_meta( get_the_ID(), '_destination_local_drink', true ) ) {
                                                $highlights[] = '<span class="highlight-item"><i class="fa fa-glass-cheers"></i></span>';
                                            }
                                            
                                            if ( get_post_meta( get_the_ID(), '_destination_accommodation', true ) ) {
                                                $highlights[] = '<span class="highlight-item"><i class="fa fa-bed"></i></span>';
                                            }
                                            
                                            if ( get_post_meta( get_the_ID(), '_destination_must_see', true ) ) {
                                                $highlights[] = '<span class="highlight-item"><i class="fa fa-eye"></i></span>';
                                            }
                                            
                                            if ( get_post_meta( get_the_ID(), '_destination_best_experience', true ) ) {
                                                $highlights[] = '<span class="highlight-item"><i class="fa fa-star"></i></span>';
                                            }
                                            
                                            // Limit to 3 highlights
                                            $highlights = array_slice( $highlights, 0, 3 );
                                            
                                            // Output highlights
                                            echo implode( ' ', $highlights );
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <a href="<?php the_permalink(); ?>" class="btn btn-sm btn-primary">
                                            <?php _e( 'Explore', 'bella-italia-journey' ); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <?php wp_reset_postdata(); ?>
            
            <div class="row mt-4">
                <div class="col-12 text-center">
                    <a href="<?php echo esc_url( get_post_type_archive_link( 'destination' ) ); ?>" class="btn btn-lg btn-outline-primary">
                        <?php _e( 'View All Destinations', 'bella-italia-journey' ); ?>
                    </a>
                </div>
            </div>
        <?php else : ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-info" role="alert">
                        <?php _e( 'No destinations found. Please add some destinations first.', 'bella-italia-journey' ); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>