<?php
/**
 * Template part for displaying the newsletter section
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get customizer options
$show_newsletter = get_theme_mod( 'bella_italia_show_newsletter', true );

// Skip if newsletter section is disabled
if ( ! $show_newsletter ) {
    return;
}

$newsletter_title = get_theme_mod( 'bella_italia_newsletter_title', __( 'Subscribe to Our Newsletter', 'bella-italia-journey' ) );
$newsletter_subtitle = get_theme_mod( 'bella_italia_newsletter_subtitle', __( 'Get travel inspiration, tips and exclusive offers straight to your inbox', 'bella-italia-journey' ) );
$newsletter_shortcode = get_theme_mod( 'bella_italia_newsletter_shortcode', '' );
$newsletter_bg = get_theme_mod( 'bella_italia_newsletter_bg', get_template_directory_uri() . '/assets/images/newsletter-bg.jpg' );

// Section style 
$section_style = '';
if ( $newsletter_bg ) {
    $section_style = 'background-image: url(' . esc_url( $newsletter_bg ) . ');';
}
?>

<section class="newsletter-section py-5" <?php if ( $section_style ) echo 'style="' . $section_style . '"'; ?>>
    <div class="newsletter-overlay"></div>
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <?php if ( $newsletter_title ) : ?>
                    <h2 class="section-title text-white"><?php echo esc_html( $newsletter_title ); ?></h2>
                <?php endif; ?>
                
                <?php if ( $newsletter_subtitle ) : ?>
                    <p class="section-subtitle text-white mb-4"><?php echo esc_html( $newsletter_subtitle ); ?></p>
                <?php endif; ?>
                
                <div class="newsletter-form">
                    <?php 
                    if ( $newsletter_shortcode ) {
                        // Display newsletter form from shortcode
                        echo do_shortcode( $newsletter_shortcode );
                    } else {
                        // Display default form
                    ?>
                        <form class="newsletter-subscribe-form" action="#" method="post">
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="newsletterEmail" placeholder="<?php esc_attr_e( 'Your Email Address', 'bella-italia-journey' ); ?>" required>
                                        <label for="newsletterEmail"><?php esc_html_e( 'Your Email Address', 'bella-italia-journey' ); ?></label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary w-100 h-100">
                                        <?php esc_html_e( 'Subscribe', 'bella-italia-journey' ); ?>
                                    </button>
                                </div>
                            </div>
                            <div class="form-check mt-3 text-start">
                                <input class="form-check-input" type="checkbox" value="" id="privacyCheck" required>
                                <label class="form-check-label text-white small" for="privacyCheck">
                                    <?php 
                                    $privacy_page = get_privacy_policy_url();
                                    if ( $privacy_page ) {
                                        printf(
                                            __( 'I agree to the <a href="%s" target="_blank">privacy policy</a> and consent to receive email updates.', 'bella-italia-journey' ),
                                            esc_url( $privacy_page )
                                        );
                                    } else {
                                        esc_html_e( 'I consent to receive email updates from Bella Italia Journey.', 'bella-italia-journey' );
                                    }
                                    ?>
                                </label>
                            </div>
                        </form>
                        <div class="newsletter-message d-none">
                            <div class="alert alert-success">
                                <?php esc_html_e( 'Thank you for subscribing! Please check your email to confirm your subscription.', 'bella-italia-journey' ); ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                
                <div class="newsletter-benefits mt-4">
                    <div class="row text-white">
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="benefit-item">
                                <i class="fa fa-bell"></i>
                                <p><?php esc_html_e( 'Travel updates', 'bella-italia-journey' ); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3 mb-md-0">
                            <div class="benefit-item">
                                <i class="fa fa-tag"></i>
                                <p><?php esc_html_e( 'Exclusive offers', 'bella-italia-journey' ); ?></p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="benefit-item">
                                <i class="fa fa-map-marked-alt"></i>
                                <p><?php esc_html_e( 'Destination guides', 'bella-italia-journey' ); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="newsletter-flag mt-4">
                    <div class="italian-flag">
                        <span class="flag-green"></span>
                        <span class="flag-white"></span>
                        <span class="flag-red"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>