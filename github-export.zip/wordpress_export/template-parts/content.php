<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get blog layout from customizer
$blog_layout = get_theme_mod( 'bella_italia_blog_layout', 'grid' );

// Set layout specific classes
$article_class = 'blog-card';
if ( $blog_layout === 'list' ) {
    $article_class .= ' blog-card-list';
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $article_class ); ?>>
    <div class="blog-card-inner">
        <?php if ( has_post_thumbnail() ) : ?>
            <div class="blog-card-media">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail( 'medium_large', array( 'class' => 'img-fluid' ) ); ?>
                </a>
            </div>
        <?php endif; ?>
        
        <div class="blog-card-content">
            <header class="entry-header">
                <?php
                if ( is_singular() ) :
                    the_title( '<h1 class="entry-title">', '</h1>' );
                else :
                    the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
                endif;

                if ( 'post' === get_post_type() ) :
                ?>
                <div class="entry-meta">
                    <?php
                    bella_italia_posted_on();
                    bella_italia_posted_by();
                    ?>
                </div><!-- .entry-meta -->
                <?php endif; ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
                <?php
                if ( is_singular() ) :
                    the_content(
                        sprintf(
                            wp_kses(
                                /* translators: %s: Name of current post. Only visible to screen readers */
                                __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'bella-italia-journey' ),
                                array(
                                    'span' => array(
                                        'class' => array(),
                                    ),
                                )
                            ),
                            wp_kses_post( get_the_title() )
                        )
                    );

                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'bella-italia-journey' ),
                            'after'  => '</div>',
                        )
                    );
                else :
                    the_excerpt();
                    ?>
                    <div class="read-more-container">
                        <a href="<?php the_permalink(); ?>" class="read-more-link">
                            <?php echo esc_html__( 'Read more', 'bella-italia-journey' ); ?>
                            <i class="fa fa-arrow-right"></i>
                        </a>
                    </div>
                    <?php
                endif;
                ?>
            </div><!-- .entry-content -->

            <?php if ( is_singular() ) : ?>
                <footer class="entry-footer">
                    <?php bella_italia_entry_footer(); ?>
                </footer><!-- .entry-footer -->
            <?php endif; ?>
        </div>
    </div>
</article><!-- #post-<?php the_ID(); ?> -->