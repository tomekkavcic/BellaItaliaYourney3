<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Bella_Italia_Journey
 */

get_header();

// Determine sidebar position
$sidebar_position = get_theme_mod( 'bella_italia_sidebar_position', 'right' );
$content_class = 'content-area';

if ( is_active_sidebar( 'sidebar-1' ) ) {
	$content_class .= ' col-lg-9';
	if ( $sidebar_position === 'left' ) {
		$content_class .= ' order-lg-2';
	}
} else {
	$content_class .= ' col-lg-12';
}
?>

	<main id="primary" class="<?php echo esc_attr( $content_class ); ?>">

		<?php bella_italia_do_before_content(); ?>

		<?php
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) :
				?>
				<header class="page-header">
					<h1 class="page-title"><?php single_post_title(); ?></h1>
				</header>
				<?php
			endif;

			// Get blog layout
			$blog_layout = get_theme_mod( 'bella_italia_blog_layout', 'grid' );
			
			if ( $blog_layout === 'grid' || $blog_layout === 'masonry' ) {
				echo '<div class="row posts-row posts-' . esc_attr( $blog_layout ) . '">';
			}

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				if ( $blog_layout === 'grid' ) {
					echo '<div class="col-md-6 col-lg-4 post-column">';
					get_template_part( 'template-parts/content', 'grid' );
					echo '</div>';
				} elseif ( $blog_layout === 'masonry' ) {
					echo '<div class="col-md-6 col-lg-4 post-column">';
					get_template_part( 'template-parts/content', 'masonry' );
					echo '</div>';
				} else {
					get_template_part( 'template-parts/content', get_post_type() );
				}

			endwhile;

			if ( $blog_layout === 'grid' || $blog_layout === 'masonry' ) {
				echo '</div>';
			}

			// Display pagination
			bella_italia_pagination();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		<?php bella_italia_do_after_content(); ?>

	</main><!-- #main -->

<?php
// Display sidebar if it's active
if ( is_active_sidebar( 'sidebar-1' ) ) :
	$sidebar_class = 'col-lg-3';
	if ( $sidebar_position === 'left' ) {
		$sidebar_class .= ' order-lg-1';
	}
	echo '<div class="' . esc_attr( $sidebar_class ) . '">';
	get_sidebar();
	echo '</div>';
endif;

get_footer();