<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bella_Italia_Journey
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}

// Determine if we're on a destination page
if ( is_singular( 'destination' ) && is_active_sidebar( 'sidebar-destination' ) ) {
	$sidebar_id = 'sidebar-destination';
} else {
	$sidebar_id = 'sidebar-1';
}
?>

<aside id="secondary" class="widget-area" role="complementary">
	<?php dynamic_sidebar( $sidebar_id ); ?>
</aside><!-- #secondary -->